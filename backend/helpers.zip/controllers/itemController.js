

import db from "../config/db.js";
import { syncUnitIdsForItem } from "../helpers/unitSyncHelper.js";
import { recordItemLedger, reverseItemLedger } from "../utils/itemLedgerHelper.js";
import parseItemsExcel from "../utils/parseItemsExcel.js";
import { sanitizeObject } from "../utils/sanitizeInput.js";
import itemFormSchema from "../validators/itemSchema.js";
import PdfPrinter from "pdfmake";
const cleanValue = (value) => {
  if (value === undefined || value === null || value === "" || value === " ") {
    return null; // store as NULL in DB
  }
  return value;  // ✅ returns the original value for valid data
};
const normalizeNumber = (val) => {
  if (
    val === undefined ||
    val === null ||
    String(val).trim() === ""
  ) {
    return null;
  }

  const num = Number(val);

  return Number.isFinite(num) ? num : null;
};
const formatDateOnly = (date) => {
  if (!date) return null;
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};
const hasItemTransactions = async (connection, itemId) => {
  const [[{ transactionCount }]] = await connection.query(
    `
    SELECT
    (
        (SELECT COUNT(*) FROM add_purchase_items WHERE Item_Id = ?)
      + (SELECT COUNT(*) FROM add_sale_items WHERE Item_Id = ?)
      + (SELECT COUNT(*) FROM purchase_return_items WHERE Item_Id = ?)
      + (SELECT COUNT(*) FROM sale_return_items WHERE Item_Id = ?)
    ) AS transactionCount
    `,
    [itemId, itemId, itemId, itemId]
  );

  return Number(transactionCount) > 0;
};
{/* Add Item */ }

const getUsedUnits = async (connection, itemId) => {
  const [rows] = await connection.query(
    `
    SELECT Selected_Unit
    FROM add_purchase_items
    WHERE Item_Id = ?
      AND Selected_Unit IS NOT NULL
      AND TRIM(Selected_Unit) <> ''

    UNION

    SELECT Selected_Unit
    FROM add_sale_items
    WHERE Item_Id = ?
      AND Selected_Unit IS NOT NULL
      AND TRIM(Selected_Unit) <> ''

    UNION

    SELECT Selected_Unit
    FROM purchase_return_items
    WHERE Item_Id = ?
      AND Selected_Unit IS NOT NULL
      AND TRIM(Selected_Unit) <> ''

    UNION

    SELECT Selected_Unit
    FROM sale_return_items
    WHERE Item_Id = ?
      AND Selected_Unit IS NOT NULL
      AND TRIM(Selected_Unit) <> ''
    `,
    [itemId, itemId, itemId, itemId]
  );

  return new Set(
    rows
      .map(row => row.Selected_Unit?.trim())
      .filter(Boolean)
  );
};
const addItem = async (req, res, next) => {
  let connection;

  try {
    // =========================================================
    // 1. GET CONNECTION + START TRANSACTION
    // =========================================================

    connection = await db.getConnection();
    await connection.beginTransaction();

    // =========================================================
    // 2. SANITIZE + VALIDATE
    // =========================================================

    const cleanData = sanitizeObject(req.body);

    const validation = itemFormSchema.safeParse(cleanData);

    if (!validation.success) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        errors: validation.error.errors,
      });
    }

    // =========================================================
    // 3. GET VALIDATED DATA
    // =========================================================

    const {
      Item_Name,
      Item_Type,
      Item_HSN,
      Item_Category,
      Item_Unit,

      Item_Code,
      MRP,
      Discount_On_MRP_For_Sale,
      Sale_Price,
      Sale_Price_Type,
      Discount_On_Sale_Price,
      Discount_Type_On_Sale_Price,
      Purchase_Price,
      Purchase_Price_Type,
      // =======================================================
      // NEW UNIT SYSTEM
      // =======================================================

      Primary_Unit,
      Secondary_Unit,
      Conversion_Rate,

      // =======================================================
      // STOCK
      // =======================================================

      Opening_Quantity,
      At_Price,
      As_Of_Date,
      Min_Stock,
      Location,
    } = validation.data;

    // =========================================================
    // 4. DUPLICATE ITEM CHECK
    // =========================================================
    const isService = Item_Type === "Service";
    if (
      isService &&
      (
        Opening_Quantity ||
        At_Price ||
        As_Of_Date ||
        Min_Stock ||
        Location
      )
    ) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message:
          "Service items cannot have stock details.",
      });
    }
    const normalizedName =
      Item_Name.trim().toLowerCase();

    const [existingItems] = await connection.query(
      `
        SELECT Item_Id
        FROM add_item
        WHERE LOWER(TRIM(Item_Name)) = ?
        LIMIT 1
      `,
      [normalizedName]
    );

    if (existingItems.length > 0) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message:
          "Item already exists, please add a new item",
      });
    }

    if (Item_Code && Item_Code.trim() !== "") {
      const [existingCode] = await connection.query(
        `
        SELECT Item_Id
        FROM add_item
        WHERE Item_Code = ?
        LIMIT 1
        `,
        [Item_Code.trim()]
      );

      if (existingCode.length > 0) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message: "Item Code already exists, please use a different code",
        });
      }
    }

    // =========================================================
    // 5. GENERATE ITEM ID
    // =========================================================

    const [last] = await connection.query(
      `
        SELECT Item_Id
        FROM add_item
        ORDER BY id DESC
        LIMIT 1
      `
    );

    let itemId = "ITM001";

    if (last.length > 0) {
      const lastNumber = parseInt(
        last[0].Item_Id.replace("ITM", ""),
        10
      );

      const nextNumber =
        Number.isNaN(lastNumber)
          ? 1
          : lastNumber + 1;

      itemId =
        "ITM" +
        nextNumber
          .toString()
          .padStart(3, "0");
    }

    // =========================================================
    // 6. NORMALIZE UNIT DATA
    // =========================================================

    /*
      CASE 1
      ----------------------------
      No units selected

      Primary_Unit     = NULL
      Secondary_Unit   = NULL
      Conversion_Rate  = NULL


      CASE 2
      ----------------------------
      Only primary selected

      Primary_Unit     = Kg
      Secondary_Unit   = NULL
      Conversion_Rate  = NULL


      CASE 3
      ----------------------------
      Primary + Secondary

      Primary_Unit     = Kg
      Secondary_Unit   = Gm
      Conversion_Rate  = 1000
    */

    const primaryUnit = Primary_Unit || null;

    const secondaryUnit = Secondary_Unit || null;
    const itemUnit = Item_Unit ?? primaryUnit ?? "";
    // const itemUnit = Item_Unit || primaryUnit || null;

    const conversionRate = secondaryUnit
      ? Conversion_Rate ?? null
      : null;

    // =========================================================
    // 7. INITIAL STOCK
    // =========================================================

    /*
      Opening_Quantity is historical setup information.

      Stock_Quantity is LIVE stock.

      Example:

      Opening_Quantity = NULL
      Stock_Quantity   = 0

      Opening_Quantity = 0
      Stock_Quantity   = 0

      Opening_Quantity = 10
      Stock_Quantity   = 10


      If item currently has NO unit:

          Opening = 10
          Stock   = 10

      Later user assigns Primary Unit = Kg:

          Stock becomes conceptually 10 Kg

      Numeric Stock_Quantity does NOT need to change.
    */

    //const stockQuantity = Opening_Quantity ?? 0;

    // =========================================================
    // 8. LEGACY Item_Unit
    // =========================================================

    /*
      You said Item_Unit must remain in add_item because
      old items still use it.

      For NEW items we DON'T need to populate it.

      New unit system:

          Primary_Unit
          Secondary_Unit
          Conversion_Rate

      Therefore:

          Item_Unit = NULL

      Existing old database rows can still contain their
      previous Item_Unit values.
    */

    //const legacyItemUnit = null;

    // =========================================================
    // 9. INSERT ITEM
    // =========================================================
    const openingQuantity = isService
      ? null
      : (Opening_Quantity ?? null);

    const atPrice = isService
      ? null
      : (At_Price ?? null);

    const asOfDate = isService
      ? null
      : (As_Of_Date || null);

    const minStock = isService
      ? null
      : (Min_Stock ?? null);

    const location = isService
      ? null
      : (Location || null);

    const stockQuantity = isService
      ? 0
      : Number(Opening_Quantity ?? 0);

    //   const [result] = await connection.execute(
    //     `
    //   INSERT INTO add_item
    //   (
    //     Item_Id,
    //     Item_Name,
    //     Item_Type,
    //     Item_HSN,
    //     Item_Category,
    //     Item_Unit,
    //     Primary_Unit,
    //     Secondary_Unit,
    //     Conversion_Rate,
    //     Stock_Quantity,
    //     Opening_Quantity,
    //     At_Price,
    //     As_Of_Date,
    //     Min_Stock,
    //     Location,
    //     created_at,
    //     updated_at
    //   )
    //   VALUES
    //   (
    //     ?, ?, ?, ?,
    //     ?,?,
    //     ?, ?, ?,
    //     ?, ?, ?, ?, ?, ?,
    //     NOW(),
    //     NOW()
    //   )
    // `,
    //     [
    //       itemId,
    //       Item_Name,
    //       Item_Type || "Product",
    //       Item_HSN || null,
    //       Item_Category || "",

    //       // Item_Unit,
    //       itemUnit,

    //       primaryUnit,
    //       secondaryUnit,
    //       conversionRate,

    //       // stockQuantity,
    //       // Opening_Quantity ?? null,
    //       // At_Price ?? null,
    //       // As_Of_Date ?? null,
    //       // Min_Stock ?? null,
    //       // Location ?? null,
    //       stockQuantity,
    //       openingQuantity,
    //       atPrice,
    //       asOfDate,
    //       minStock,
    //       location,
    //     ]
    //   );
    const [result] = await connection.execute(
      `
    INSERT INTO add_item
    (
        Item_Id,
        Item_Name,
        Item_Type,
        Item_HSN,
        Item_Category,
        Item_Unit,
        Item_Code,
        MRP,
        Discount_On_MRP_For_Sale,
        Sale_Price,
        Sale_Price_Type,
        Discount_On_Sale_Price,
        Discount_Type_On_Sale_Price,
        Purchase_Price,
        Purchase_Price_Type,
        Primary_Unit,
        Secondary_Unit,
        Conversion_Rate,
        Stock_Quantity,
        Opening_Quantity,
        At_Price,
        As_Of_Date,
        Min_Stock,
        Location,
        created_at,
        updated_at
    )
    VALUES
    (
        ?, ?, ?, ?,
        ?, ?,
        ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?, ?, ?,
        NOW(),
        NOW()
    )
    `,
      [
        itemId,
        Item_Name,
        Item_Type || "Product",
        Item_HSN || null,
        Item_Category || "",

        itemUnit,

        Item_Code || null,
        //MRP ?? null,
        normalizeNumber(MRP) || null,
        normalizeNumber(Discount_On_MRP_For_Sale) || null,
        Sale_Price ?? null,
        Sale_Price_Type || "Without_Tax",
        Discount_On_Sale_Price ?? null,
        Discount_Type_On_Sale_Price || "Percentage",
        Purchase_Price ?? null,
        Purchase_Price_Type || "Without_Tax",

        primaryUnit,
        secondaryUnit,
        conversionRate,

        stockQuantity,
        openingQuantity,
        atPrice,
        asOfDate,
        minStock,
        location,
      ]
    );

    await syncUnitIdsForItem(connection, itemId);
    // =========================================================
    // 10. SAVE UNIT CONVERSION
    // =========================================================




    if (
      primaryUnit &&
      secondaryUnit &&
      conversionRate !== null &&
      Number(conversionRate) > 0
    ) {
      await connection.execute(
        `
      INSERT IGNORE INTO item_unit_conversions
      (
        
        Primary_Unit,
        Secondary_Unit,
        Conversion_Rate
      )
      VALUES ( ?, ?, ?)
    `,
        [

          primaryUnit,
          secondaryUnit,
          conversionRate,
        ]
      );
    }
    // =========================================================
    // 11. OPENING STOCK LEDGER ENTRY
    // =========================================================

    if (stockQuantity > 0) {
      await recordItemLedger({
        connection,

        itemId,
        txnType: "Opening_Stock",

        // Same source id used to identify this opening stock entry
        referenceId: result.insertId,

        billId: itemId,
        billNumber: null,
        partyName: null,

        // User-entered opening quantity
        quantity: Number(stockQuantity),

        // Opening stock is always stored in the primary unit
        // (or null if no unit is configured)
        selectedUnit: primaryUnit || null,

        // No conversion needed for opening stock
        baseQty: Number(stockQuantity),

        rate: At_Price ?? null,

        txnDate: As_Of_Date || new Date().toISOString().slice(0, 10),
      });
    }

    // =========================================================
    // 12. COMMIT
    // =========================================================

    await connection.commit();



    // =========================================================
    // 13. RESPONSE
    // =========================================================

    return res.status(201).json({
      success: true,
      message: "Item added successfully",

      id: result.insertId,
      itemId,

      item: {
        Item_Id: itemId,
        Item_Name,
        Item_HSN: Item_HSN || null,
        Item_Category,

        // New units
        Primary_Unit: primaryUnit,
        Secondary_Unit: secondaryUnit,
        Conversion_Rate: conversionRate,

        // Stock
        Stock_Quantity: stockQuantity,
        Opening_Quantity:
          Opening_Quantity ?? null,

        At_Price:
          At_Price ?? null,

        As_Of_Date:
          As_Of_Date || null,

        Min_Stock:
          Min_Stock ?? null,

        Location:
          Location || null,
      },
    });

  } catch (err) {
    // =========================================================
    // 12. ROLLBACK
    // =========================================================

    if (connection) {
      await connection.rollback();
    }

    console.error(
      "❌ Error adding item:",
      err
    );

    next(err);

  } finally {
    // =========================================================
    // 13. RELEASE CONNECTION
    // =========================================================

    if (connection) {
      connection.release();
    }
  }
};
const MAX_IMPORT_ROWS = 5000;

// local date (IST safe) — never toISOString() for dates
const toYMD = (d = new Date()) => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
};

// "Discount %" / "Discount Amount" / "Percentage" / "Amount"  ->  "Percentage" | "Amount" | "" | null(invalid)
const normalizeDiscountType = (v) => {
  const s = String(v ?? "").trim().toLowerCase();
  if (!s) return "";
  if (["percentage", "discount %", "%", "percent"].includes(s)) return "Percentage";
  if (["amount", "discount amount", "flat"].includes(s)) return "Amount";
  return null;
};
const normalizeUnit = (value) =>
  String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "");


const UNIT_ALIASES = {
  // Kilogram
  kg: "kgs",
  kilo: "kgs",
  kilos: "kgs",
  kilogram: "kgs",
  kilograms: "kgs",

  // Gram
  g: "gm",
  gram: "gm",
  grams: "gm",

  // Litre
  l: "ltr",
  liter: "ltr",
  litre: "ltr",
  liters: "ltr",
  litres: "ltr",

  // Millilitre
  ml: "ml",
  milliliter: "ml",
  millilitre: "ml",

  // Piece
  pc: "pcs",
  piece: "pcs",
  pieces: "pcs",

  // Dozen
  dz: "dzn",
  dozen: "dzn",

  // Bag
  bag: "bag",
  bags: "bag",

  // Box
  box: "box",
  boxes: "box",

  // Packet
  packet: "pckt",
  packets: "pckt",

  // Plates
  plate: "plts",
  plates: "plts",
};


const findUnit = (value, units) => {
  const input = normalizeUnit(value);

  // Excel cell is empty
  if (!input) {
    return null;
  }

  // Convert common user input to database shorthand
  const normalizedInput = UNIT_ALIASES[input] || input;

  return units.find((unit) => {
    const unitName = normalizeUnit(unit.Unit_Name);
    const unitShorthand = normalizeUnit(unit.Unit_Shorthand);

    return (
      normalizedInput === unitName ||
      normalizedInput === unitShorthand
    );
  });
};


const importItemsExcel = async (req, res, next) => {
  let connection;
  let inTransaction = false;

  try {
    // =========================================================
    // 1. BASIC FILE VALIDATION
    // =========================================================

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Please upload an Excel file.",
      });
    }

    // =========================================================
    // 2. DRY RUN
    // =========================================================

    const dryRun =
      String(req.body?.dryRun || "").toLowerCase() === "true";

    // =========================================================
    // 3. PARSE EXCEL
    // =========================================================

    let excelRows;

    try {
      excelRows = parseItemsExcel(req.file.path);
    } catch (excelError) {
      return res.status(400).json({
        success: false,
        message: excelError.message || "Could not read Excel file.",
      });
    }

    if (!Array.isArray(excelRows) || excelRows.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No items found in the Excel file.",
      });
    }

    // =========================================================
    // 4. MAX ROW LIMIT
    // =========================================================

    if (excelRows.length > MAX_IMPORT_ROWS) {
      return res.status(400).json({
        success: false,
        message: `Too many rows. Maximum ${MAX_IMPORT_ROWS} items per import.`,
      });
    }

    // =========================================================
    // 5. DB CONNECTION
    // =========================================================

    connection = await db.getConnection();
    const [units] = await connection.query(`
  SELECT Unit_Name, Unit_Shorthand
  FROM units
  WHERE Is_Used = 1
`);

    // =========================================================
    // 6. LOAD UNITS
    // =========================================================

    // const [unitRows] = await connection.query(
    //   `SELECT Unit_Shorthand FROM units`
    // );

    // const unitMap = new Map(
    //   unitRows.map((u) => [
    //     String(u.Unit_Shorthand).trim().toLowerCase(),
    //     u.Unit_Shorthand,
    //   ])
    // );

    // =========================================================
    // 7. PER-ROW VALIDATION
    // =========================================================

    const rows = excelRows.map((excelRow) => {
      const rowNo = excelRow.rowNo;
      const raw = excelRow.raw || {};

      const errors = [];
      const fieldErrors = {};
      const addFieldError = (field, message) => {
  errors.push(message);

  if (!fieldErrors[field]) {
    fieldErrors[field] = [];
  }

  fieldErrors[field].push(message);
};

      // -------------------------------------------------------
      // Clone raw object
      // -------------------------------------------------------

      const rest = {
        ...raw,
      };
      // -------------------------------------------------------
// Resolve units
// -------------------------------------------------------
// -------------------------------------------------------
// Resolve units
// Keep original Excel value for UI
// -------------------------------------------------------

let primaryUnit = null;
let secondaryUnit = null;




if (rest.Primary_Unit) {
  primaryUnit = findUnit(
    rest.Primary_Unit,
    units
  );
}

if (rest.Secondary_Unit) {
  secondaryUnit = findUnit(
    rest.Secondary_Unit,
    units
  );
}
      // -------------------------------------------------------
      // Discount type
      // -------------------------------------------------------

      
//       const dt = normalizeDiscountType(
//   rest.Discount_Type_On_Sale_Price
// );

// if (
//   rest.Discount_Type_On_Sale_Price !== undefined &&
//   rest.Discount_Type_On_Sale_Price !== "" &&
//   dt === null
// ) {
//   addFieldError(
//     "Discount_Type_On_Sale_Price",
//     'Discount Type: use "Discount %" or "Discount Amount"'
//   );
// }

// // Discount % cannot be greater than 100
// if (
//   dt === "Percentage" &&
//   rest.Discount_On_Sale_Price !== undefined &&
//   rest.Discount_On_Sale_Price !== "" &&
//   Number(rest.Discount_On_Sale_Price) > 100
// ) {
//   addFieldError(
//     "Discount_On_Sale_Price",
//     "Discount percentage cannot be greater than 100"
//   );
// }

//       rest.Discount_Type_On_Sale_Price = dt || "";
// -------------------------------------------------------
// Discount type
// -------------------------------------------------------

const rawDiscountType = String(
  rest.Discount_Type_On_Sale_Price ?? ""
).trim();

let dt = normalizeDiscountType(rawDiscountType);

// Invalid / empty Discount Type
// → silently treat it as Amount
if (dt !== "Percentage" && dt !== "Amount") {
  dt = "Amount";
}

// Keep the normalized value so it is sent to the UI
rest.Discount_Type_On_Sale_Price = dt;


// -------------------------------------------------------
// Discount validation
// -------------------------------------------------------

const discountValue = Number(
  rest.Discount_On_Sale_Price
);

if (
  rest.Discount_On_Sale_Price !== undefined &&
  rest.Discount_On_Sale_Price !== "" &&
  !Number.isNaN(discountValue)
) {
  // Percentage must be 0–100
  if (dt === "Percentage") {
    if (discountValue < 0) {
      addFieldError(
        "Discount_On_Sale_Price",
        "Discount percentage cannot be negative"
      );
    } else if (discountValue > 100) {
      addFieldError(
        "Discount_On_Sale_Price",
        "Discount percentage cannot be greater than 100"
      );
    }
  }

  // Amount remains Amount
  // No Discount Type error
}
      // -------------------------------------------------------
      // Sanitize input
      // -------------------------------------------------------

      const input = Object.fromEntries(
        Object.entries(
          sanitizeObject({
            ...rest,
            Item_Type: "Product",
          })
        ).filter(([, value]) => value !== null && value !== "")
      );

      // -------------------------------------------------------
      // Zod validation
      // -------------------------------------------------------

      const parsed = itemFormSchema.safeParse(input);

      // if (!parsed.success) {
      //   parsed.error.errors.forEach((error) => {
      //     errors.push(
      //       `${error.path.join(".") || "Row"}: ${error.message}`
      //     );
      //   });
      // }
      if (!parsed.success) {
  parsed.error.issues.forEach((error) => {
    const field = error.path[0] || "Row";
    const message = `${error.path.join(".") || "Row"}: ${error.message}`;

    addFieldError(field, message);
  });
}

      // const data = parsed.success
      //   ? {
      //       ...parsed.data,
      //     }
      //   : null;
  const data = parsed.success
  ? {
      ...parsed.data,

      // Database stores Unit_Shorthand
      Primary_Unit: primaryUnit
        ? primaryUnit.Unit_Shorthand
        : null,

      Secondary_Unit: secondaryUnit
        ? secondaryUnit.Unit_Shorthand
        : null,
    }
  : null;

     

      return {
        rowNo,
        input,
        data,
        errors: [...new Set(errors)],
          fieldErrors
      };
    });

    // =========================================================
    // 8. DUPLICATES INSIDE EXCEL FILE
    // =========================================================

    const seenNames = new Map();
    const seenCodes = new Map();

    rows.forEach((row) => {
      const name = String(
        row.input.Item_Name || ""
      )
        .trim()
        .toLowerCase();

      const code = String(
        row.input.Item_Code || ""
      )
        .trim()
        .toLowerCase();

      // -------------------------------------------------------
      // Duplicate item name
      // -------------------------------------------------------

      // if (name) {
      //   if (seenNames.has(name)) {
      //     row.errors.push(
      //       `Duplicate item name (also in row ${seenNames.get(name)})`
      //     );
      //   } else {
      //     seenNames.set(name, row.rowNo);
      //   }
      // }
      if (name) {
  if (seenNames.has(name)) {
    const message = `Duplicate item name (also in row ${seenNames.get(name)})`;

    row.errors.push(message);

    if (!row.fieldErrors.Item_Name) {
      row.fieldErrors.Item_Name = [];
    }

    row.fieldErrors.Item_Name.push(message);
  } else {
    seenNames.set(name, row.rowNo);
  }
}

      // -------------------------------------------------------
      // Duplicate item code
      // -------------------------------------------------------

      if (code) {
        if (seenCodes.has(code)) {
          const message = `Duplicate item code (also in row ${seenCodes.get(code)})`;

          row.errors.push(message);

          if (!row.fieldErrors.Item_Code) {
            row.fieldErrors.Item_Code = [];
          }

          row.fieldErrors.Item_Code.push(message);
        } else {
          seenCodes.set(code, row.rowNo);
        }
      }
    });

    // =========================================================
    // 9. CHECK DUPLICATES AGAINST DATABASE
    // =========================================================

    const names = [...seenNames.keys()];
    const codes = [...seenCodes.keys()];

    const dbNames = new Set();
    const dbCodes = new Set();

    // ---------------------------------------------------------
    // Existing item names
    // ---------------------------------------------------------

    if (names.length) {
      const [existingNames] = await connection.query(
        `
        SELECT LOWER(TRIM(Item_Name)) AS n
        FROM add_item
        WHERE LOWER(TRIM(Item_Name)) IN (?)
        `,
        [names]
      );

      existingNames.forEach((item) => {
        dbNames.add(item.n);
      });
    }

    // ---------------------------------------------------------
    // Existing item codes
    // ---------------------------------------------------------

    if (codes.length) {
      const [existingCodes] = await connection.query(
        `
        SELECT LOWER(TRIM(Item_Code)) AS c
        FROM add_item
        WHERE LOWER(TRIM(Item_Code)) IN (?)
        `,
        [codes]
      );

      existingCodes.forEach((item) => {
        dbCodes.add(item.c);
      });
    }

    // ---------------------------------------------------------
    // Add DB errors to rows
    // ---------------------------------------------------------

    rows.forEach((row) => {
      const name = String(
        row.input.Item_Name || ""
      )
        .trim()
        .toLowerCase();

      const code = String(
        row.input.Item_Code || ""
      )
        .trim()
        .toLowerCase();

      // if (name && dbNames.has(name)) {
      //   row.errors.push("Item already exists");
      // }

      // if (code && dbCodes.has(code)) {
      //   row.errors.push("Item Code already exists");
      // }
      if (name && dbNames.has(name)) {
  row.errors.push("Item already exists");

  if (!row.fieldErrors.Item_Name) {
    row.fieldErrors.Item_Name = [];
  }

  row.fieldErrors.Item_Name.push("Item already exists");
}

if (code && dbCodes.has(code)) {
  row.errors.push("Item Code already exists");

  if (!row.fieldErrors.Item_Code) {
    row.fieldErrors.Item_Code = [];
  }

  row.fieldErrors.Item_Code.push("Item Code already exists");
}

      row.errors = [...new Set(row.errors)];
      Object.keys(row.fieldErrors).forEach((field) => {
  row.fieldErrors[field] = [...new Set(row.fieldErrors[field])];
});
    });

    // =========================================================
    // 10. SUMMARY
    // =========================================================

    const failed = rows.filter(
      (row) => row.errors.length > 0
    );

    const valid = rows.filter(
      (row) => row.errors.length === 0
    );

    const errorList = failed.map((row) => ({
      rowNo: row.rowNo,
      messages: row.errors,
    }));

    // =========================================================
    // 11. DRY RUN
    // =========================================================

    if (dryRun) {
      return res.status(200).json({
        success: true,
        dryRun: true,

        summary: {
          total: rows.length,
          valid: valid.length,
          invalid: failed.length,
        },

        // This is important for your frontend preview
        rows: rows.map((row) => ({
          rowNo: row.rowNo,

          //data: row.data || row.input,
          data: row.input,

          errors: row.errors,
          fieldErrors: row.fieldErrors
        })),

        errors: errorList,
      });
    }

    // =========================================================
    // 12. NOTHING VALID
    // =========================================================

    if (valid.length === 0) {
      return res.status(200).json({
        success: true,

        imported: 0,

        message: "No valid items to import.",

        errors: errorList,
      });
    }

    // =========================================================
    // 13. BEGIN TRANSACTION
    // =========================================================

    await connection.beginTransaction();

    inTransaction = true;
    const getOrCreateUnit = async (unitValue) => {
  if (!unitValue || String(unitValue).trim() === "") {
    return null;
  }

  const input = String(unitValue).trim();

  const normalized = normalizeUnit(input);

  // Convert alias to canonical shorthand
  const canonicalShorthand =
    UNIT_ALIASES[normalized] || normalized;

  // Check if unit already exists
  const [existing] = await connection.query(
    `
    SELECT
      Unit_Name,
      Unit_Shorthand
    FROM units
    WHERE Is_Used = 1
      AND (
        LOWER(TRIM(Unit_Name)) = ?
        OR LOWER(TRIM(Unit_Shorthand)) = ?
      )
    LIMIT 1
    `,
    [
      canonicalShorthand,
      canonicalShorthand,
    ]
  );

  // Existing unit → use it
  if (existing.length > 0) {
    return existing[0].Unit_Shorthand;
  }

  // Unit does not exist → create it
  await connection.execute(
    `
    INSERT INTO units
    (
      Unit_Name,
      Unit_Shorthand,
      Is_Used
    )
    VALUES (?, ?, 1)
    `,
    [
      input,
      canonicalShorthand,
    ]
  );

  return canonicalShorthand;
};

    // =========================================================
    // 14. GET NEXT ITEM ID
    // =========================================================

    const [last] = await connection.query(
      `
      SELECT Item_Id
      FROM add_item
      ORDER BY id DESC
      LIMIT 1
      FOR UPDATE
      `
    );

    let nextNumber = 1;

    if (last.length > 0) {
      const n = parseInt(
        String(last[0].Item_Id).replace("ITM", ""),
        10
      );

      nextNumber = Number.isNaN(n)
        ? 1
        : n + 1;
    }

    // =========================================================
    // 15. COMMON VALUES
    // =========================================================

    const today = toYMD();

    const conversionPairs = new Map();

    let imported = 0;

    // =========================================================
    // 16. INSERT VALID ITEMS
    // =========================================================

    for (const row of valid) {
      try {
        const d = row.data;

        // -----------------------------------------------------
        // Generate Item ID
        // -----------------------------------------------------

        const itemId =
          "ITM" +
          String(nextNumber++).padStart(3, "0");

        // -----------------------------------------------------
        // Units
        // -----------------------------------------------------

        // const primaryUnit =
        //   d.Primary_Unit || null;

        // const secondaryUnit =
        //   d.Secondary_Unit || null;

        // const itemUnit =
        //   primaryUnit ?? "";

        // const conversionRate =
        //   secondaryUnit
        //     ? d.Conversion_Rate ?? null
        //     : null;
        const primaryUnit = await getOrCreateUnit(
  d.Primary_Unit
);

const secondaryUnit = await getOrCreateUnit(
  d.Secondary_Unit
);

const itemUnit = primaryUnit ?? "";

const conversionRate = secondaryUnit
  ? d.Conversion_Rate ?? null
  : null;

        // -----------------------------------------------------
        // Opening stock
        // -----------------------------------------------------

        const hasOpening =
          d.Opening_Quantity !== undefined &&
          d.Opening_Quantity !== null &&
          d.Opening_Quantity !== "";

        const stockQuantity =
          Number(d.Opening_Quantity ?? 0);

        const openingQuantity =
          hasOpening
            ? stockQuantity
            : null;

        // -----------------------------------------------------
        // Opening stock valuation
        // -----------------------------------------------------

        const atPrice =
          stockQuantity > 0
            ? d.Purchase_Price ?? null
            : null;

        const asOfDate =
          hasOpening
            ? today
            : null;

        // -----------------------------------------------------
        // INSERT ITEM
        // -----------------------------------------------------

        const [result] =
          await connection.execute(
            `
            INSERT INTO add_item
            (
              Item_Id,
              Item_Name,
              Item_Type,
              Item_HSN,
              Item_Category,
              Item_Unit,

              Item_Code,
              MRP,
              Discount_On_MRP_For_Sale,

              Sale_Price,
              Sale_Price_Type,
              Discount_On_Sale_Price,
              Discount_Type_On_Sale_Price,

              Purchase_Price,
              Purchase_Price_Type,

              Primary_Unit,
              Secondary_Unit,
              Conversion_Rate,

              Stock_Quantity,
              Opening_Quantity,
              At_Price,
              As_Of_Date,
              Min_Stock,
              Location,

              created_at,
              updated_at
            )
            VALUES
            (
              ?, ?, ?, ?, ?, ?,

              ?, ?, ?,

              ?, ?, ?, ?,

              ?, ?,

              ?, ?, ?,

              ?, ?, ?, ?, ?, ?,

              NOW(),
              NOW()
            )
            `,
            [
              // ------------------------------------------------
              // BASIC
              // ------------------------------------------------

              itemId,

              d.Item_Name,

              "Product",

              d.Item_HSN || null,

              d.Item_Category || "",

              itemUnit,

              // ------------------------------------------------
              // CODE / PRICES
              // ------------------------------------------------

              d.Item_Code || null,

              normalizeNumber(d.MRP) || null,

              null,

              d.Sale_Price ?? null,

              "Without_Tax",

              d.Discount_On_Sale_Price ?? null,

              d.Discount_Type_On_Sale_Price ||
                "Percentage",

              d.Purchase_Price ?? null,

              "Without_Tax",

              // ------------------------------------------------
              // UNITS
              // ------------------------------------------------

              primaryUnit,

              secondaryUnit,

              conversionRate,

              // ------------------------------------------------
              // STOCK
              // ------------------------------------------------

              stockQuantity,

              openingQuantity,

              atPrice,

              asOfDate,

              d.Min_Stock ?? null,

              d.Location || null,
            ]
          );

        // =====================================================
        // SYNC UNIT IDS
        // =====================================================

        await syncUnitIdsForItem(
          connection,
          itemId
        );

        // =====================================================
        // SAVE CONVERSION PAIR
        // =====================================================

        if (
          primaryUnit &&
          secondaryUnit &&
          Number(conversionRate) > 0
        ) {
          conversionPairs.set(
            `${primaryUnit}|${secondaryUnit}|${conversionRate}`,
            [
              primaryUnit,
              secondaryUnit,
              conversionRate,
            ]
          );
        }

        // =====================================================
        // OPENING STOCK LEDGER
        // =====================================================

        if (stockQuantity > 0) {
          await recordItemLedger({
            connection,

            itemId,

            txnType: "Opening_Stock",

            referenceId:
              result.insertId,

            billId: itemId,

            billNumber: null,

            partyName: null,

            quantity: stockQuantity,

            selectedUnit: primaryUnit,

            baseQty: stockQuantity,

            rate: atPrice,

            txnDate: asOfDate,
          });
        }

        imported++;
      } catch (rowError) {
        rowError.importRowNo = row.rowNo;

        throw rowError;
      }
    }

    // =========================================================
    // 17. SAVE UNIT CONVERSION PAIRS
    // =========================================================

    for (const [
      primaryUnit,
      secondaryUnit,
      rate,
    ] of conversionPairs.values()) {
      await connection.execute(
        `
        INSERT IGNORE INTO item_unit_conversions
        (
          Primary_Unit,
          Secondary_Unit,
          Conversion_Rate
        )
        VALUES (?, ?, ?)
        `,
        [
          primaryUnit,
          secondaryUnit,
          rate,
        ]
      );
    }

    // =========================================================
    // 18. COMMIT
    // =========================================================

    await connection.commit();

    inTransaction = false;

    // =========================================================
    // 19. RESPONSE
    // =========================================================

    return res.status(201).json({
      success: true,

      imported,

      skipped: failed.length,

      message: `${imported} item${
        imported === 1 ? "" : "s"
      } imported`,

      errors: errorList,
    });
  } catch (err) {
    // =========================================================
    // ROLLBACK
    // =========================================================

    if (connection && inTransaction) {
      await connection.rollback();
    }

    console.error(
      "❌ Error importing items:",
      err
    );

    // =========================================================
    // ROW-SPECIFIC ERROR
    // =========================================================

    if (err?.importRowNo) {
      return res.status(500).json({
        success: false,

        message:
          `Import failed at row ${err.importRowNo}. ` +
          `No items were saved.`,
      });
    }

    next(err);
  } finally {
    if (connection) {
      connection.release();
    }
  }
};
const validateImportItemRow = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const cleanData = sanitizeObject(req.body.data || {});

    const errors = [];
    const fieldErrors = {};

    const addFieldError = (field, message) => {
      errors.push(message);

      if (!fieldErrors[field]) {
        fieldErrors[field] = [];
      }

      fieldErrors[field].push(message);
    };

    // =========================================================
    // 1. BASIC VALUES
    // =========================================================

    const {
      Item_Name,
      Item_Type,
      Item_Code,

      Primary_Unit,
      Secondary_Unit,
      Conversion_Rate,

      Opening_Quantity,
      At_Price,
      As_Of_Date,
      Min_Stock,
      Location,
    } = cleanData;

    // =========================================================
    // 2. ITEM NAME VALIDATION
    // =========================================================

    if (!Item_Name || String(Item_Name).trim() === "") {
      addFieldError(
        "Item_Name",
        "Item Name is required."
      );
    } else {
      const normalizedName = String(Item_Name)
        .trim()
        .toLowerCase();

      const [existingItems] = await connection.query(
        `
        SELECT Item_Id
        FROM add_item
        WHERE LOWER(TRIM(Item_Name)) = ?
        LIMIT 1
        `,
        [normalizedName]
      );

      if (existingItems.length > 0) {
        addFieldError(
          "Item_Name",
          "Item already exists, please add a new item."
        );
      }
    }

    // =========================================================
    // 3. ITEM CODE DUPLICATE
    // =========================================================

    if (
      Item_Code !== undefined &&
      Item_Code !== null &&
      String(Item_Code).trim() !== ""
    ) {
      const itemCode = String(Item_Code).trim();

      const [existingCode] = await connection.query(
        `
        SELECT Item_Id
        FROM add_item
        WHERE Item_Code = ?
        LIMIT 1
        `,
        [itemCode]
      );

      if (existingCode.length > 0) {
        addFieldError(
          "Item_Code",
          "Item Code already exists, please use a different code."
        );
      }
    }

   

    // =========================================================
    // 5. SECONDARY UNIT → CONVERSION RATE REQUIRED
    // =========================================================

    if (
      Secondary_Unit !== undefined &&
      Secondary_Unit !== null &&
      String(Secondary_Unit).trim() !== ""
    ) {
      if (
        Conversion_Rate === undefined ||
        Conversion_Rate === null ||
        Conversion_Rate === "" ||
        Number(Conversion_Rate) <= 0
      ) {
        addFieldError(
          "Conversion_Rate",
          "Conversion Rate is required when Secondary Unit is provided."
        );
      }
    }

    // =========================================================
    // 6. CONVERSION RATE WITHOUT SECONDARY UNIT
    // =========================================================

    if (
      (!Secondary_Unit ||
        String(Secondary_Unit).trim() === "") &&
      Conversion_Rate !== undefined &&
      Conversion_Rate !== null &&
      Conversion_Rate !== ""
    ) {
      addFieldError(
        "Conversion_Rate",
        "Conversion Rate cannot be provided without Secondary Unit."
      );
    }

    // =========================================================
    // 7. PRIMARY + SECONDARY SAME UNIT
    // =========================================================

    if (
      Primary_Unit &&
      Secondary_Unit &&
      String(Primary_Unit).trim().toLowerCase() ===
        String(Secondary_Unit).trim().toLowerCase()
    ) {
      addFieldError(
        "Secondary_Unit",
        "Primary Unit and Secondary Unit cannot be the same."
      );
    }

    // =========================================================
    // 8. RESPONSE
    // =========================================================

    return res.status(200).json({
      success: true,
      errors,
      fieldErrors,
    });

  } catch (err) {
    console.error(
      "❌ validateImportItemRow:",
      err
    );

    next(err);

  } finally {
    if (connection) {
      connection.release();
    }
  }
};
const importItemRows = async (req, res, next) => {
  let connection;
  let inTransaction = false;

  try {
    // =========================================================
    // 1. RECEIVE ROWS
    // =========================================================

    const { items } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No items were provided for import.",
      });
    }

    // =========================================================
    // 2. MAX ROW LIMIT
    // =========================================================

    if (items.length > MAX_IMPORT_ROWS) {
      return res.status(400).json({
        success: false,
        message: `Too many rows. Maximum ${MAX_IMPORT_ROWS} items per import.`,
      });
    }

    // =========================================================
    // 3. DB CONNECTION
    // =========================================================

    connection = await db.getConnection();

    // =========================================================
    // 4. NORMALIZE INPUT
    //
    // IMPORTANT:
    // Frontend validation is NOT trusted.
    // We validate again here.
    // =========================================================

    const rows = items.map((item, index) => {
      const rowNo = item?.rowNo ?? index + 1;

      const data = sanitizeObject({
        ...item,
      });

      // rowNo is metadata, not an add_item column
      delete data.rowNo;

      return {
        rowNo,
        data,
        errors: [],
        fieldErrors: {},
      };
    });

    // =========================================================
    // HELPER
    // =========================================================

    const addFieldError = (row, field, message) => {
      row.errors.push(message);

      if (!row.fieldErrors[field]) {
        row.fieldErrors[field] = [];
      }

      row.fieldErrors[field].push(message);
    };

    // =========================================================
    // 5. BASIC / BUSINESS VALIDATION
    // =========================================================

    for (const row of rows) {
      const d = row.data;

      // -------------------------------------------------------
      // ITEM NAME
      // -------------------------------------------------------

      if (
        !d.Item_Name ||
        String(d.Item_Name).trim() === ""
      ) {
        addFieldError(
          row,
          "Item_Name",
          "Item Name is required."
        );
      }

      // -------------------------------------------------------
      // ITEM CODE
      // -------------------------------------------------------

      if (
        d.Item_Code !== undefined &&
        d.Item_Code !== null &&
        String(d.Item_Code).trim() !== ""
      ) {
        d.Item_Code = String(d.Item_Code).trim();
      }

      // -------------------------------------------------------
      // DISCOUNT TYPE
      // -------------------------------------------------------

      const dt = normalizeDiscountType(
        d.Discount_Type_On_Sale_Price
      );

      if (
        d.Discount_Type_On_Sale_Price !== undefined &&
        d.Discount_Type_On_Sale_Price !== null &&
        d.Discount_Type_On_Sale_Price !== "" &&
        dt === null
      ) {
        addFieldError(
          row,
          "Discount_Type_On_Sale_Price",
          'Discount Type: use "Discount %" or "Discount Amount"'
        );
      }

      d.Discount_Type_On_Sale_Price =
        dt || d.Discount_Type_On_Sale_Price || "";

      // -------------------------------------------------------
      // DISCOUNT %
      // -------------------------------------------------------

      if (
        dt === "Percentage" &&
        d.Discount_On_Sale_Price !== undefined &&
        d.Discount_On_Sale_Price !== null &&
        d.Discount_On_Sale_Price !== "" &&
        Number(d.Discount_On_Sale_Price) > 100
      ) {
        addFieldError(
          row,
          "Discount_On_Sale_Price",
          "Discount percentage cannot be greater than 100"
        );
      }

      // -------------------------------------------------------
      // SECONDARY UNIT → CONVERSION REQUIRED
      // -------------------------------------------------------

      const hasSecondary =
        d.Secondary_Unit !== undefined &&
        d.Secondary_Unit !== null &&
        String(d.Secondary_Unit).trim() !== "";

      if (hasSecondary) {
        if (
          d.Conversion_Rate === undefined ||
          d.Conversion_Rate === null ||
          d.Conversion_Rate === "" ||
          Number(d.Conversion_Rate) <= 0
        ) {
          addFieldError(
            row,
            "Conversion_Rate",
            "Conversion Rate is required when Secondary Unit is provided."
          );
        }
      }

      // -------------------------------------------------------
      // CONVERSION WITHOUT SECONDARY UNIT
      // -------------------------------------------------------

      if (
        !hasSecondary &&
        d.Conversion_Rate !== undefined &&
        d.Conversion_Rate !== null &&
        d.Conversion_Rate !== ""
      ) {
        addFieldError(
          row,
          "Conversion_Rate",
          "Conversion Rate cannot be provided without Secondary Unit."
        );
      }

      // -------------------------------------------------------
      // PRIMARY + SECONDARY CANNOT BE SAME
      // -------------------------------------------------------

      if (
        d.Primary_Unit &&
        d.Secondary_Unit &&
        normalizeUnit(d.Primary_Unit) ===
          normalizeUnit(d.Secondary_Unit)
      ) {
        addFieldError(
          row,
          "Secondary_Unit",
          "Primary Unit and Secondary Unit cannot be the same."
        );
      }

      // -------------------------------------------------------
      // ZOD VALIDATION
      // -------------------------------------------------------

      const input = Object.fromEntries(
        Object.entries(
          sanitizeObject({
            ...d,
            Item_Type: "Product",
          })
        ).filter(
          ([, value]) =>
            value !== null &&
            value !== ""
        )
      );

      const parsed = itemFormSchema.safeParse(input);

      if (!parsed.success) {
        parsed.error.issues.forEach((error) => {
          const field =
            error.path[0] || "Row";

          const message =
            `${error.path.join(".") || "Row"}: ${error.message}`;

          addFieldError(
            row,
            field,
            message
          );
        });
      }

      // Use sanitized data going forward
      row.data = input;
    }

    // =========================================================
    // 6. DUPLICATES INSIDE CURRENT IMPORT
    // =========================================================

    const seenNames = new Map();
    const seenCodes = new Map();

    for (const row of rows) {
      const name = String(
        row.data.Item_Name || ""
      )
        .trim()
        .toLowerCase();

      const code = String(
        row.data.Item_Code || ""
      )
        .trim()
        .toLowerCase();

      // -------------------------------------------------------
      // ITEM NAME
      // -------------------------------------------------------

      if (name) {
        if (seenNames.has(name)) {
          const message =
            `Duplicate item name (also in row ${seenNames.get(name)})`;

          addFieldError(
            row,
            "Item_Name",
            message
          );
        } else {
          seenNames.set(
            name,
            row.rowNo
          );
        }
      }

      // -------------------------------------------------------
      // ITEM CODE
      // -------------------------------------------------------

      if (code) {
        if (seenCodes.has(code)) {
          const message =
            `Duplicate item code (also in row ${seenCodes.get(code)})`;

          addFieldError(
            row,
            "Item_Code",
            message
          );
        } else {
          seenCodes.set(
            code,
            row.rowNo
          );
        }
      }
    }

    // =========================================================
    // 7. CHECK DATABASE DUPLICATES
    // =========================================================

    const names = [...seenNames.keys()];
    const codes = [...seenCodes.keys()];

    const dbNames = new Set();
    const dbCodes = new Set();

    // ---------------------------------------------------------
    // EXISTING ITEM NAMES
    // ---------------------------------------------------------

    if (names.length > 0) {
      const [existingNames] =
        await connection.query(
          `
          SELECT LOWER(TRIM(Item_Name)) AS n
          FROM add_item
          WHERE LOWER(TRIM(Item_Name)) IN (?)
          `,
          [names]
        );

      existingNames.forEach((item) => {
        dbNames.add(item.n);
      });
    }

    // ---------------------------------------------------------
    // EXISTING ITEM CODES
    // ---------------------------------------------------------

    if (codes.length > 0) {
      const [existingCodes] =
        await connection.query(
          `
          SELECT LOWER(TRIM(Item_Code)) AS c
          FROM add_item
          WHERE LOWER(TRIM(Item_Code)) IN (?)
          `,
          [codes]
        );

      existingCodes.forEach((item) => {
        dbCodes.add(item.c);
      });
    }

    // ---------------------------------------------------------
    // APPLY DB ERRORS
    // ---------------------------------------------------------

    for (const row of rows) {
      const name = String(
        row.data.Item_Name || ""
      )
        .trim()
        .toLowerCase();

      const code = String(
        row.data.Item_Code || ""
      )
        .trim()
        .toLowerCase();

      if (name && dbNames.has(name)) {
        addFieldError(
          row,
          "Item_Name",
          "Item already exists."
        );
      }

      if (code && dbCodes.has(code)) {
        addFieldError(
          row,
          "Item_Code",
          "Item Code already exists."
        );
      }
    }

    // =========================================================
    // 8. REMOVE DUPLICATE ERROR MESSAGES
    // =========================================================

    rows.forEach((row) => {
      row.errors = [
        ...new Set(row.errors),
      ];

      Object.keys(row.fieldErrors).forEach(
        (field) => {
          row.fieldErrors[field] = [
            ...new Set(
              row.fieldErrors[field]
            ),
          ];
        }
      );
    });

    // =========================================================
    // 9. FIND VALID ROWS
    // =========================================================

    const failed = rows.filter(
      (row) => row.errors.length > 0
    );

    const valid = rows.filter(
      (row) => row.errors.length === 0
    );

    // =========================================================
    // 10. IF ANY INVALID ROW EXISTS
    //
    // Do NOT start transaction.
    // Do NOT insert anything.
    // =========================================================

    if (failed.length > 0) {
      return res.status(400).json({
        success: false,
        message:
          "Some rows failed final validation.",
        imported: 0,
        errors: failed.map((row) => ({
          rowNo: row.rowNo,
          messages: row.errors,
          fieldErrors: row.fieldErrors,
        })),
      });
    }

    // =========================================================
    // 11. BEGIN TRANSACTION
    // =========================================================

    await connection.beginTransaction();

    inTransaction = true;

    // =========================================================
    // 12. GET / CREATE UNIT
    //
    // Missing units are created ONLY during actual import.
    //
    // Excel value:
    //      kG
    //
    // DB:
    //      Kgs
    // =========================================================

    const getOrCreateUnit = async (
      unitValue
    ) => {
      if (
        !unitValue ||
        String(unitValue).trim() === ""
      ) {
        return null;
      }

      const input =
        String(unitValue).trim();

      const normalized =
        normalizeUnit(input);

      const canonicalShorthand =
        UNIT_ALIASES[normalized] ||
        normalized;

      // -------------------------------------------------------
      // CHECK EXISTING UNIT
      // -------------------------------------------------------

      const [existing] =
        await connection.query(
          `
          SELECT
            Unit_Name,
            Unit_Shorthand
          FROM units
          WHERE Is_Used = 1
            AND (
              LOWER(TRIM(Unit_Name)) = ?
              OR LOWER(TRIM(Unit_Shorthand)) = ?
            )
          LIMIT 1
          `,
          [
            canonicalShorthand,
            canonicalShorthand,
          ]
        );

      if (existing.length > 0) {
        return existing[0].Unit_Shorthand;
      }

      // -------------------------------------------------------
      // CREATE MISSING UNIT
      // -------------------------------------------------------

      await connection.execute(
        `
        INSERT INTO units
        (
          Unit_Name,
          Unit_Shorthand,
          Is_Used
        )
        VALUES (?, ?, 1)
        `,
        [
          input,
          canonicalShorthand,
        ]
      );

      return canonicalShorthand;
    };

    // =========================================================
    // 13. GET NEXT ITEM ID
    // =========================================================

    const [last] =
      await connection.query(
        `
        SELECT Item_Id
        FROM add_item
        ORDER BY id DESC
        LIMIT 1
        FOR UPDATE
        `
      );

    let nextNumber = 1;

    if (last.length > 0) {
      const n = parseInt(
        String(last[0].Item_Id)
          .replace("ITM", ""),
        10
      );

      nextNumber =
        Number.isNaN(n)
          ? 1
          : n + 1;
    }

    // =========================================================
    // 14. COMMON VALUES
    // =========================================================

    const today = toYMD();

    const conversionPairs =
      new Map();

    let imported = 0;

    // =========================================================
    // 15. INSERT ITEMS
    // =========================================================

    for (const row of valid) {
      try {
        const d = row.data;

        // -----------------------------------------------------
        // ITEM ID
        // -----------------------------------------------------

        const itemId =
          "ITM" +
          String(nextNumber++)
            .padStart(3, "0");

        // -----------------------------------------------------
        // UNITS
        // -----------------------------------------------------

        const primaryUnit =
          await getOrCreateUnit(
            d.Primary_Unit
          );

        const secondaryUnit =
          await getOrCreateUnit(
            d.Secondary_Unit
          );

        const itemUnit =
          primaryUnit ?? "";

        const conversionRate =
          secondaryUnit
            ? d.Conversion_Rate ?? null
            : null;

        // -----------------------------------------------------
        // OPENING STOCK
        // -----------------------------------------------------

        const hasOpening =
          d.Opening_Quantity !== undefined &&
          d.Opening_Quantity !== null &&
          d.Opening_Quantity !== "";

        const stockQuantity =
          Number(
            d.Opening_Quantity ?? 0
          );

        const openingQuantity =
          hasOpening
            ? stockQuantity
            : null;

        // -----------------------------------------------------
        // OPENING STOCK PRICE
        // -----------------------------------------------------

        const atPrice =
          stockQuantity > 0
            ? d.Purchase_Price ?? null
            : null;

        const asOfDate =
          hasOpening
            ? today
            : null;

        // =====================================================
        // INSERT ITEM
        // =====================================================

        const [result] =
          await connection.execute(
            `
            INSERT INTO add_item
            (
              Item_Id,
              Item_Name,
              Item_Type,
              Item_HSN,
              Item_Category,
              Item_Unit,

              Item_Code,
              MRP,
              Discount_On_MRP_For_Sale,

              Sale_Price,
              Sale_Price_Type,
              Discount_On_Sale_Price,
              Discount_Type_On_Sale_Price,

              Purchase_Price,
              Purchase_Price_Type,

              Primary_Unit,
              Secondary_Unit,
              Conversion_Rate,

              Stock_Quantity,
              Opening_Quantity,
              At_Price,
              As_Of_Date,
              Min_Stock,
              Location,

              created_at,
              updated_at
            )
            VALUES
            (
              ?, ?, ?, ?, ?, ?,

              ?, ?, ?,

              ?, ?, ?, ?,

              ?, ?,

              ?, ?, ?,

              ?, ?, ?, ?, ?, ?,

              NOW(),
              NOW()
            )
            `,
            [
              // ------------------------------------------------
              // BASIC
              // ------------------------------------------------

              itemId,

              d.Item_Name,

              "Product",

              d.Item_HSN || null,

              d.Item_Category || "",

              itemUnit,

              // ------------------------------------------------
              // CODE / PRICES
              // ------------------------------------------------

              d.Item_Code || null,

              normalizeNumber(d.MRP) || null,

              null,

              d.Sale_Price ?? null,

              "Without_Tax",

              d.Discount_On_Sale_Price ?? null,

              d.Discount_Type_On_Sale_Price ||
                "Percentage",

              d.Purchase_Price ?? null,

              "Without_Tax",

              // ------------------------------------------------
              // UNITS
              // ------------------------------------------------

              primaryUnit,

              secondaryUnit,

              conversionRate,

              // ------------------------------------------------
              // STOCK
              // ------------------------------------------------

              stockQuantity,

              openingQuantity,

              atPrice,

              asOfDate,

              d.Min_Stock ?? null,

              d.Location || null,
            ]
          );

        // =====================================================
        // SYNC UNIT IDS
        // =====================================================

        await syncUnitIdsForItem(
          connection,
          itemId
        );

        // =====================================================
        // SAVE CONVERSION PAIR
        // =====================================================

        if (
          primaryUnit &&
          secondaryUnit &&
          Number(conversionRate) > 0
        ) {
          conversionPairs.set(
            `${primaryUnit}|${secondaryUnit}|${conversionRate}`,
            [
              primaryUnit,
              secondaryUnit,
              conversionRate,
            ]
          );
        }

        // =====================================================
        // OPENING STOCK LEDGER
        // =====================================================

        if (stockQuantity > 0) {
          await recordItemLedger({
            connection,

            itemId,

            txnType:
              "Opening_Stock",

            referenceId:
              result.insertId,

            billId:
              itemId,

            billNumber:
              null,

            partyName:
              null,

            quantity:
              stockQuantity,

            selectedUnit:
              primaryUnit,

            baseQty:
              stockQuantity,

            rate:
              atPrice,

            txnDate:
              asOfDate,
          });
        }

        imported++;

      } catch (rowError) {
        rowError.importRowNo =
          row.rowNo;

        throw rowError;
      }
    }

    // =========================================================
    // 16. SAVE UNIT CONVERSION PAIRS
    // =========================================================

    for (const [
      primaryUnit,
      secondaryUnit,
      rate,
    ] of conversionPairs.values()) {
      await connection.execute(
        `
        INSERT IGNORE INTO item_unit_conversions
        (
          Primary_Unit,
          Secondary_Unit,
          Conversion_Rate
        )
        VALUES (?, ?, ?)
        `,
        [
          primaryUnit,
          secondaryUnit,
          rate,
        ]
      );
    }

    // =========================================================
    // 17. COMMIT
    // =========================================================

    await connection.commit();

    inTransaction = false;

    // =========================================================
    // 18. SUCCESS RESPONSE
    // =========================================================

    return res.status(201).json({
      success: true,

      imported,

      skipped: 0,

      message:
        `${imported} item${
          imported === 1
            ? ""
            : "s"
        } imported`,

      errors: [],
    });

  } catch (err) {

    // =========================================================
    // ROLLBACK
    // =========================================================

    if (
      connection &&
      inTransaction
    ) {
      await connection.rollback();
    }

    console.error(
      "❌ Error importing item rows:",
      err
    );

    // =========================================================
    // ROW-SPECIFIC ERROR
    // =========================================================

    if (err?.importRowNo) {
      return res.status(500).json({
        success: false,

        message:
          `Import failed at row ${err.importRowNo}. ` +
          `No items were saved.`,

        errors: [
          {
            rowNo: err.importRowNo,
            messages: [
              err.message ||
                "Unexpected import error.",
            ],
          },
        ],
      });
    }

    return next(err);

  } finally {

    if (connection) {
      connection.release();
    }
  }
};

const addItemConversion = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const {

      Primary_Unit,
      Secondary_Unit,
      Conversion_Rate,
    } = req.body;

    // if (
    //   !Item_Id ||
    //   !Primary_Unit ||
    //   !Secondary_Unit ||
    //   !Number(Conversion_Rate)
    // ) {
    //   return res.status(400).json({
    //     success: false,
    //     message: "Invalid conversion data.",
    //   });
    // }
    if (
      !Primary_Unit ||
      !Secondary_Unit ||
      !Number(Conversion_Rate)
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid conversion data.",
      });
    }
    // if (await hasItemTransactions(connection, Item_Id)) {
    //   return res.status(400).json({
    //     success: false,
    //     message:
    //       "This item has already been used in transactions. Unit configuration cannot be changed.",
    //   });
    // }
    // await connection.execute(
    //   `
    //   INSERT IGNORE INTO item_unit_conversions
    //   (
    //     Item_Id,
    //     Primary_Unit,
    //     Secondary_Unit,
    //     Conversion_Rate
    //   )
    //   VALUES (?, ?, ?, ?)
    //   `,
    //   [
    //     Item_Id,
    //     Primary_Unit,
    //     Secondary_Unit,
    //     Conversion_Rate,
    //   ]
    // );
    await connection.execute(
      `
  INSERT IGNORE INTO item_unit_conversions
  (
    Primary_Unit,
    Secondary_Unit,
    Conversion_Rate
  )
  VALUES (?, ?, ?)
  `,
      [
        Primary_Unit,
        Secondary_Unit,
        Conversion_Rate,
      ]
    );
    // const [conversions] = await connection.query(
    //   `
    //   SELECT
    //     id,
    //     Primary_Unit,
    //     Secondary_Unit,
    //     Conversion_Rate
    //   FROM item_unit_conversions
    //   WHERE Item_Id = ?
    //   ORDER BY id DESC
    //   `,
    //   [Item_Id]
    // );
    const [conversions] = await connection.query(
      `
  SELECT
    id,
    Primary_Unit,
    Secondary_Unit,
    Conversion_Rate
  FROM item_unit_conversions
  ORDER BY id DESC
  `
    );
    return res.status(200).json({
      success: true,
      message: "Conversion saved successfully.",
      conversions,
    });
  } catch (err) {
    console.error("❌ addItemConversion:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};

// WHERE Item_Id = ?
const getItemConversions = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    //const { Item_Id } = req.params;

    // const [conversions] = await connection.query(
    //   `
    //   SELECT
    //     id,
    //     Primary_Unit,
    //     Secondary_Unit,
    //     Conversion_Rate
    //   FROM item_unit_conversions

    //   ORDER BY id DESC
    //   `,

    // );
    const [conversions] = await connection.query(
      `
  SELECT DISTINCT
  id,
    Primary_Unit,
    Secondary_Unit,
    Conversion_Rate
  FROM item_unit_conversions
  ORDER BY Primary_Unit, Secondary_Unit
  `
    );

    return res.status(200).json({
      success: true,
      conversions,
    });
  } catch (err) {
    console.error("❌ getItemConversions:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};

const editItem = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    // =========================================================
    // 1. GET ITEM ID
    // =========================================================

    const { Item_Id } = req.params;

    if (!Item_Id) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Item ID is required.",
      });
    }

    // =========================================================
    // 2. SANITIZE + VALIDATE
    // =========================================================

    const cleanData = sanitizeObject(req.body);

    const validation = itemFormSchema.safeParse(cleanData);

    if (!validation.success) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        errors: validation.error.errors,
      });
    }

    // =========================================================
    // 3. GET VALIDATED DATA
    // =========================================================

    const {
      Item_Name,
      Item_Type,
      Item_HSN,
      Item_Unit, // legacy
      Item_Category,

      // NEW FIELDS
      Item_Code,

      // PRICING
      MRP,
      Discount_On_MRP_For_Sale,
      Sale_Price,
      Sale_Price_Type,
      Discount_On_Sale_Price,
      Discount_Type_On_Sale_Price,
      Purchase_Price,
      Purchase_Price_Type,

      // NEW UNIT SYSTEM
      Primary_Unit,
      Secondary_Unit,
      Conversion_Rate,

      // STOCK
      Opening_Quantity,
      At_Price,
      As_Of_Date,
      Min_Stock,
      Location,
    } = validation.data;
    console.log("EDIT ITEM VALIDATED DATA:", {
      Item_Id,
      MRP,
      Discount_On_MRP_For_Sale,
    });
    // =========================================================
    // 4. GET EXISTING ITEM
    // =========================================================

    const [[existingItem]] = await connection.query(
      `
      SELECT
        id,
        Item_Id,
        Item_Name,
        Item_Type,
        Item_Code,

        Item_HSN,
        Item_Category,
        Item_Unit,

        MRP,
        Discount_On_MRP_For_Sale,
        Sale_Price,
        Sale_Price_Type,
        Discount_On_Sale_Price,
        Discount_Type_On_Sale_Price,
        Purchase_Price,
        Purchase_Price_Type,

        Opening_Quantity,
        At_Price,
        As_Of_Date,
        Min_Stock,
        Location,

        Primary_Unit,
        Secondary_Unit,
        Conversion_Rate,
        Stock_Quantity

      FROM add_item
      WHERE Item_Id = ?
      LIMIT 1
      `,
      [Item_Id]
    );

    if (!existingItem) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "Item not found.",
      });
    }

    // =========================================================
    // 5. DUPLICATE ITEM NAME CHECK
    // =========================================================

    const normalizedName = Item_Name.trim().toLowerCase();

    const [duplicate] = await connection.query(
      `
      SELECT Item_Id
      FROM add_item
      WHERE LOWER(TRIM(Item_Name)) = ?
        AND Item_Id <> ?
      LIMIT 1
      `,
      [normalizedName, Item_Id]
    );

    if (duplicate.length > 0) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Another item with this name already exists.",
      });
    }

    // =========================================================
    // 6. DUPLICATE ITEM CODE CHECK
    // =========================================================

    if (Item_Code && Item_Code.trim() !== "") {
      const [duplicateCode] = await connection.query(
        `
        SELECT Item_Id
        FROM add_item
        WHERE Item_Code = ?
          AND Item_Id <> ?
        LIMIT 1
        `,
        [Item_Code.trim(), Item_Id]
      );

      if (duplicateCode.length > 0) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message:
            "Item Code already exists, please use a different code.",
        });
      }
    }

    // =========================================================
    // 7. SERVICE STOCK VALIDATION
    // =========================================================

    const isService = Item_Type === "Service";

    if (
      isService &&
      (
        Number(Opening_Quantity) > 0 ||
        Number(At_Price) > 0 ||
        As_Of_Date ||
        Number(Min_Stock) > 0 ||
        Location
      )
    ) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Service items cannot have stock details.",
      });
    }

    // =========================================================
    // 8. NORMALIZE UNITS
    // =========================================================

    const oldPrimary = existingItem.Primary_Unit || null;
    const oldSecondary = existingItem.Secondary_Unit || null;

    const oldConversion =
      existingItem.Conversion_Rate == null
        ? null
        : Number(existingItem.Conversion_Rate);

    const newPrimary = Primary_Unit || null;
    const newSecondary = Secondary_Unit || null;

    const newConversion = Secondary_Unit
      ? (
        Conversion_Rate == null
          ? null
          : Number(Conversion_Rate)
      )
      : null;

    // =========================================================
    // 9. CHECK USED UNITS
    // =========================================================

    const usedUnits = await getUsedUnits(
      connection,
      Item_Id
    );

    const primaryUsed =
      oldPrimary &&
      usedUnits.has(oldPrimary);

    const secondaryUsed =
      oldSecondary &&
      usedUnits.has(oldSecondary);

    // =========================================================
    // 10. PRIMARY UNIT LOCK
    // =========================================================

    if (
      primaryUsed &&
      oldPrimary !== newPrimary
    ) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message:
          `Primary Unit "${oldPrimary}" cannot be changed because it has already been used in a transaction.`,
      });
    }

    // =========================================================
    // 11. SECONDARY UNIT LOCK
    // =========================================================

    if (
      secondaryUsed &&
      (
        oldSecondary !== newSecondary ||
        oldConversion !== newConversion
      )
    ) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message:
          `Secondary Unit "${oldSecondary}" and its Conversion Rate cannot be changed because it has already been used in a transaction.`,
      });
    }

    // =========================================================
    // 12. SERVICE STOCK VALUES
    // =========================================================

    const openingQuantity = isService
      ? existingItem.Opening_Quantity
      : (Opening_Quantity ?? null);

    const atPrice = isService
      ? existingItem.At_Price
      : (At_Price ?? null);

    const asOfDate = isService
      ? existingItem.As_Of_Date
      : (As_Of_Date || null);

    const minStock = isService
      ? existingItem.Min_Stock
      : (Min_Stock ?? null);

    const location = isService
      ? existingItem.Location
      : (Location || null);

    // =========================================================
    // 13. UPDATE ITEM
    // =========================================================

    const [result] = await connection.execute(
      `
      UPDATE add_item
      SET
        Item_Name = ?,
        Item_Type = ?,
        Item_HSN = ?,
        Item_Category = ?,
        Item_Unit = ?,
        Item_Code = ?,

        MRP = ?,
        Discount_On_MRP_For_Sale = ?,

        Sale_Price = ?,
        Sale_Price_Type = ?,
        Discount_On_Sale_Price = ?,
        Discount_Type_On_Sale_Price = ?,

        Purchase_Price = ?,
        Purchase_Price_Type = ?,

        Primary_Unit = ?,
        Secondary_Unit = ?,
        Conversion_Rate = ?,

        Opening_Quantity = ?,
        At_Price = ?,
        As_Of_Date = ?,
        Min_Stock = ?,
        Location = ?,

        updated_at = NOW()

      WHERE Item_Id = ?
      `,
      [
        Item_Name,
        Item_Type || "Product",
        Item_HSN || null,
        Item_Category || "",

        // Legacy unit
        Item_Unit || "",

        // Item code
        Item_Code || null,

        // =====================================================
        // PRICING
        // =====================================================

        //MRP ?? null,
        normalizeNumber(MRP) || null,
        //Discount_On_MRP_For_Sale ?? null,
        normalizeNumber(Discount_On_MRP_For_Sale) || null,

        Sale_Price ?? null,
        Sale_Price_Type || "Without_Tax",

        Discount_On_Sale_Price ?? null,
        Discount_Type_On_Sale_Price || "Percentage",

        Purchase_Price ?? null,
        Purchase_Price_Type || "Without_Tax",

        // =====================================================
        // UNITS
        // =====================================================

        newPrimary,
        newSecondary,
        newSecondary
          ? newConversion
          : null,

        // =====================================================
        // STOCK
        // =====================================================

        openingQuantity,
        atPrice,
        asOfDate,
        minStock,
        location,

        Item_Id,
      ]
    );
    console.log("MASTER UPDATE VALUES:", {
      Item_Id,
      MRP,
      normalizedMRP: normalizeNumber(MRP),
      finalMRP: normalizeNumber(MRP) || null,
      Discount_On_MRP_For_Sale,
      finalDiscount: normalizeNumber(Discount_On_MRP_For_Sale) || null,
    });

    if (result.affectedRows === 0) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "Item not found.",
      });
    }

    // =========================================================
    // 14. SYNC UNIT IDS
    // =========================================================

    await syncUnitIdsForItem(
      connection,
      Item_Id
    );

    // =========================================================
    // 15. UPDATE OPENING STOCK LEDGER
    // =========================================================

    /*
      IMPORTANT:

      This preserves your existing behavior:
      only create an opening-stock ledger entry when the
      submitted Opening_Quantity is greater than zero.
    */

    if (
      Opening_Quantity !== null &&
      Opening_Quantity !== undefined &&
      Number(Opening_Quantity) > 0
    ) {
      await recordItemLedger({
        connection,

        itemId: Item_Id,

        txnType: "Opening_Stock",

        referenceId: existingItem.id,

        billId: null,
        billNumber: null,
        partyName: null,

        quantity: Number(Opening_Quantity),

        selectedUnit:
          newPrimary || null,

        baseQty:
          Number(Opening_Quantity),

        rate:
          At_Price ?? null,

        txnDate:
          As_Of_Date ||
          new Date()
            .toISOString()
            .slice(0, 10),
      });
    }

    // =========================================================
    // 16. UPDATE LIVE STOCK FROM LATEST LEDGER
    // =========================================================

    const [[latestLedger]] = await connection.query(
      `
      SELECT Running_Stock
      FROM item_ledger
      WHERE Item_Id = ?
      ORDER BY id DESC
      LIMIT 1
      `,
      [Item_Id]
    );

    await connection.query(
      `
      UPDATE add_item
      SET Stock_Quantity = ?
      WHERE Item_Id = ?
      `,
      [
        latestLedger
          ? Number(latestLedger.Running_Stock)
          : 0,

        Item_Id,
      ]
    );

    // =========================================================
    // 17. SAVE UNIT CONVERSION HISTORY
    // =========================================================

    if (
      newPrimary &&
      newSecondary &&
      newConversion !== null &&
      Number(newConversion) > 0
    ) {
      await connection.execute(
        `
        INSERT INTO item_unit_conversions
        (
          Primary_Unit,
          Secondary_Unit,
          Conversion_Rate
        )
        SELECT ?, ?, ?
        WHERE NOT EXISTS (
          SELECT 1
          FROM item_unit_conversions
          WHERE Primary_Unit = ?
            AND Secondary_Unit = ?
            AND Conversion_Rate = ?
        )
        `,
        [
          newPrimary,
          newSecondary,
          newConversion,

          newPrimary,
          newSecondary,
          newConversion,
        ]
      );
    }

    // =========================================================
    // 18. COMMIT
    // =========================================================

    await connection.commit();

    // =========================================================
    // 19. RESPONSE
    // =========================================================

    return res.status(200).json({
      success: true,
      message: "Item updated successfully",

      item: {
        Item_Id,

        Item_Name,

        Item_Type:
          Item_Type || "Product",

        Item_HSN:
          Item_HSN || null,

        Item_Category,

        Item_Unit:
          Item_Unit || "",

        Item_Code:
          Item_Code || null,

        // =====================================================
        // PRICING
        // =====================================================

        MRP: MRP ?? null,

        Discount_On_MRP_For_Sale: Discount_On_MRP_For_Sale ?? null,

        Sale_Price:
          Sale_Price ?? null,

        Sale_Price_Type:
          Sale_Price_Type || "Without_Tax",

        Discount_On_Sale_Price:
          Discount_On_Sale_Price ?? null,

        Discount_Type_On_Sale_Price:
          Discount_Type_On_Sale_Price || "Percentage",

        Purchase_Price:
          Purchase_Price ?? null,

        Purchase_Price_Type:
          Purchase_Price_Type || "Without_Tax",

        // =====================================================
        // UNITS
        // =====================================================

        Primary_Unit:
          newPrimary,

        Secondary_Unit:
          newSecondary,

        Conversion_Rate:
          newConversion,

        // =====================================================
        // STOCK
        // =====================================================

        Stock_Quantity:
          latestLedger
            ? Number(latestLedger.Running_Stock)
            : 0,

        Opening_Quantity:
          openingQuantity,

        At_Price:
          atPrice,

        As_Of_Date:
          asOfDate,

        Min_Stock:
          minStock,

        Location:
          location,
      },
    });

  } catch (err) {
    if (connection) {
      await connection.rollback();
    }

    console.error(
      "❌ Error editing item:",
      err
    );

    next(err);

  } finally {
    if (connection) {
      connection.release();
    }
  }
};

const deleteItem = async (req, res, next) => {
  let connection;

  try {
    const { Item_Id } = req.params;

    if (!Item_Id) {
      return res.status(400).json({
        success: false,
        message: "Item ID is required.",
      });
    }

    connection = await db.getConnection();

    await connection.beginTransaction();

    // =========================================================
    // 1. CHECK ITEM EXISTS
    // =========================================================

    const [[item]] = await connection.query(
      `
      SELECT
        id,
        Item_Id,
        Item_Name
      FROM add_item
      WHERE Item_Id = ?
      LIMIT 1
      `,
      [Item_Id]
    );

    if (!item) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "Item not found.",
      });
    }

    // =========================================================
    // 2. CHECK ITEM LEDGER
    //
    // If ANY transaction exists for this item,
    // item cannot be deleted.
    // =========================================================

    // const [[ledgerCount]] = await connection.query(
    //   `
    //   SELECT COUNT(*) AS count
    //   FROM item_ledger
    //   WHERE Item_Id = ?
    //   `,
    //   [Item_Id]
    // );

    // if (Number(ledgerCount.count) > 0) {
    //   await connection.rollback();

    //   return res.status(400).json({
    //     success: false,
    //     canDelete: false,
    //     message:
    //       "This item cannot be deleted because transactions exist for this item. Delete the related sales, purchases, returns, stock adjustments, or opening stock transaction first.",
    //   });
    // }
    const [[ledgerCount]] = await connection.query(
      `
  SELECT COUNT(*) AS count
  FROM item_ledger
  WHERE Item_Id = ?
    AND Txn_Type <> 'Opening_Stock'
  `,
      [Item_Id]
    );

    if (Number(ledgerCount.count) > 0) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        canDelete: false,
        message:
          "This item cannot be deleted because transactions exist for this item. Delete related purchases, sales, returns, or stock adjustments first.",
      });
    }

    // DELETE OPENING STOCK ENTRIES
    await connection.query(
      `
  DELETE FROM item_ledger
  WHERE Item_Id = ?
    AND Txn_Type = 'Opening_Stock'
  `,
      [Item_Id]
    );

    // =========================================================
    // DELETE ITEM UNIT CONVERSIONS
    // =========================================================
    // await connection.query(
    //   `
    //   DELETE FROM item_unit_conversions
    //   WHERE Item_Id = ?
    //   `,
    //   [Item_Id]
    // );

    // =========================================================
    //  DELETE STOCK ADJUSTMENTS
    //
    // Normally there should be none because any adjustment
    // should have an item_ledger row.
    //
    // This is just cleanup / FK safety.
    // =========================================================

    await connection.query(
      `
      DELETE FROM item_stock_adjustments
      WHERE Item_Id = ?
      `,
      [Item_Id]
    );

    // =========================================================
    //  DELETE ITEM
    // =========================================================

    await connection.query(
      `
      DELETE FROM add_item
      WHERE Item_Id = ?
      `,
      [Item_Id]
    );

    // =========================================================
    //  COMMIT
    // =========================================================

    await connection.commit();

    return res.status(200).json({
      success: true,
      canDelete: true,
      message: "Item deleted successfully.",
      Item_Id,
    });

  } catch (err) {

    if (connection) {
      await connection.rollback();
    }

    console.error("❌ Error deleting item:", err);

    next(err);

  } finally {

    if (connection) {
      connection.release();
    }
  }
};

const eachItemBillAndInvoiceNumbers = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();

    const { Item_Id } = req.params;
    if (!Item_Id) {
      return res.status(400).json({ message: "Item Id is required" });
    }

    // 1️⃣ Fetch purchase & sale references
    const [purchases] = await connection.query(
      "SELECT Purchase_Id FROM add_purchase_items WHERE Item_Id = ?",
      [Item_Id]
    );

    const [sales] = await connection.query(
      "SELECT Sale_Id FROM add_sale_items WHERE Item_Id = ?",
      [Item_Id]
    );

    const purchaseIds = purchases.map((p) => p.Purchase_Id);
    const saleIds = sales.map((s) => s.Sale_Id);

    let purchaseDetails = [];
    let saleDetails = [];

    // 2️⃣ Fetch purchase bill numbers (only if exists)
    if (purchaseIds.length > 0) {
      [purchaseDetails] = await connection.query(
        `SELECT  Purchase_Id,Bill_Number, Bill_Date 
         FROM add_purchase 
         WHERE Purchase_Id IN (?)`,
        [purchaseIds]
      );
    }

    // 3️⃣ Fetch sale invoice numbers (only if exists)
    if (saleIds.length > 0) {
      [saleDetails] = await connection.query(
        `SELECT Sale_Id, Invoice_Number, Invoice_Date 
         FROM add_sale 
         WHERE Sale_Id IN (?)`,
        [saleIds]
      );
    }

    // 4️⃣ Final output format
    const billAndInvoiceNumbers = {
      purchaseDetails: {
        type: "Purchase",
        count: purchaseDetails.length,
        details: purchaseDetails,
      },
      saleDetails: {
        type: "Sale",
        count: saleDetails.length,
        details: saleDetails,
      },
    };

    return res.status(200).json({
      success: true,
      message: "Bill and Invoice Numbers fetched successfully",
      billAndInvoiceNumbers,
    });

  } catch (err) {
    console.error("❌ Error:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};




//WORKED
// const getAllItems = async (req, res, next) => {
//   let connection;

//   try {
//     connection = await db.getConnection();

//     const page = req.query.page
//       ? parseInt(req.query.page, 10)
//       : null;

//     const search = req.query.search
//       ? req.query.search.trim().toLowerCase()
//       : "";

//     const fromDate = req.query.fromDate || null;
//     const toDate = req.query.toDate || null;

//     const limit = 10;
//     const offset = page ? (page - 1) * limit : 0;

//     // =========================================================
//     // 1. BUILD WHERE
//     // =========================================================

//     const whereClauses = [];
//     const params = [];

//     if (search) {
//       whereClauses.push(`
//         (
//           LOWER(Item_Name) LIKE ?
//           OR LOWER(Item_Category) LIKE ?
//           OR LOWER(Item_HSN) LIKE ?
//           OR LOWER(Item_Id) LIKE ?
//           OR LOWER(Item_Unit) LIKE ?
//           OR LOWER(Primary_Unit) LIKE ?
//           OR LOWER(Secondary_Unit) LIKE ?
//         )
//       `);

//       const like = `%${search}%`;

//       params.push(
//         like,
//         like,
//         like,
//         like,
//         like,
//         like,
//         like
//       );
//     }

//     // =========================================================
//     // 2. DATE FILTER
//     // =========================================================

//     if (fromDate && toDate) {
//       whereClauses.push(`DATE(created_at) BETWEEN ? AND ?`);
//       params.push(fromDate, toDate);

//     } else if (fromDate) {
//       whereClauses.push(`DATE(created_at) >= ?`);
//       params.push(fromDate);

//     } else if (toDate) {
//       whereClauses.push(`DATE(created_at) <= ?`);
//       params.push(toDate);
//     }

//     const whereSQL = whereClauses.length
//       ? `WHERE ${whereClauses.join(" AND ")}`
//       : "";

//     // Keep params without pagination for COUNT query
//     const filterParams = [...params];

//     // =========================================================
//     // 3. GET ITEMS
//     // =========================================================

//     // let query = `
//     //   SELECT *
//     //   FROM add_item
//     //   ${whereSQL}
//     //   ORDER BY created_at DESC
//     // `;
//     let query = `
//   SELECT
//     ai.*,


//     pu.Unit_Name      AS Primary_Unit_Name,
//     pu.Unit_Shorthand AS Primary_Unit_Shorthand,

//     su.Unit_Name      AS Secondary_Unit_Name,
//     su.Unit_Shorthand AS Secondary_Unit_Shorthand

//   FROM add_item ai

//   LEFT JOIN units pu
//     ON ai.Primary_Unit_Id = pu.id

//   LEFT JOIN units su
//     ON ai.Secondary_Unit_Id = su.id

//   ${whereSQL}

//   ORDER BY ai.created_at DESC
// `;

//     if (page) {
//       query += ` LIMIT ? OFFSET ?`;
//       params.push(limit, offset);
//     }

//     const [items] = await connection.query(
//       query,
//       params
//     );

//     // =========================================================
//     // 4. COUNT
//     // =========================================================

//     const [totalItems] = await connection.query(
//       `
//         SELECT COUNT(*) AS total
//         FROM add_item
//         ${whereSQL}
//       `,
//       filterParams
//     );

//     // =========================================================
//     // 5. PURCHASE HISTORY
//     // =========================================================

//     // const [purchaseItems] = await connection.query(`
//     //   SELECT
//     //     Item_Id,
//     //     Purchase_Price,
//     //     Tax_Type
//     //   FROM add_purchase_items
//     //   ORDER BY created_at DESC
//     // `);

//     // =========================================================
//     // 6. SALES HISTORY
//     // =========================================================

//     // const [salesItems] = await connection.query(`
//     //   SELECT
//     //     Item_Id,
//     //     Sale_Price
//     //   FROM add_sale_items
//     //   ORDER BY created_at DESC
//     // `);

//     // =========================================================
//     // 7. UNIT CONVERSION HISTORY
//     // =========================================================

//     // const [unitConversions] = await connection.query(`
//     //   SELECT
//     //     id,
//     //     Item_Id,
//     //     Primary_Unit,
//     //     Secondary_Unit,
//     //     Conversion_Rate,
//     //     created_at
//     //   FROM item_unit_conversions
//     //   ORDER BY created_at DESC, id DESC
//     // `);
//     const [unitConversions] = await connection.query(`
//       SELECT
//         id,

//         Primary_Unit,
//         Secondary_Unit,
//         Conversion_Rate,
//         created_at
//       FROM item_unit_conversions
//       ORDER BY created_at DESC, id DESC
//     `);
//     // =========================================================
//     // 7A. ITEMS USED IN TRANSACTIONS
//     // =========================================================

//     const [usedItems] = await connection.query(`
// SELECT DISTINCT Item_Id
// FROM (
//     SELECT Item_Id FROM add_purchase_items

//     UNION

//     SELECT Item_Id FROM add_sale_items

//     UNION

//     SELECT Item_Id FROM purchase_return_items

//     UNION

//     SELECT Item_Id FROM sale_return_items
// ) t
// `);

//     const usedItemSet = new Set(
//       usedItems.map((row) => row.Item_Id)
//     );

//     // =========================================================
//     // 8. LATEST PURCHASE PRICE + TAX
//     // =========================================================

//     // const latestPurchasePrice = {};
//     // const latestTaxType = {};

//     // purchaseItems.forEach((row) => {
//     //   if (latestPurchasePrice[row.Item_Id] === undefined) {
//     //     latestPurchasePrice[row.Item_Id] =
//     //       row.Purchase_Price;

//     //     latestTaxType[row.Item_Id] =
//     //       row.Tax_Type;
//     //   }
//     // });

//     // =========================================================
//     // 9. LATEST SALE PRICE
//     // =========================================================

//     // const latestSalePrice = {};

//     // salesItems.forEach((row) => {
//     //   if (latestSalePrice[row.Item_Id] === undefined) {
//     //     latestSalePrice[row.Item_Id] =
//     //       row.Sale_Price;
//     //   }
//     // });

//     // =========================================================
//     // 10. GROUP CONVERSIONS BY ITEM
//     // =========================================================

//     const conversionsByItem = {};

//     unitConversions.forEach((conversion) => {
//       if (!conversionsByItem[conversion.Item_Id]) {
//         conversionsByItem[conversion.Item_Id] = [];
//       }

//       conversionsByItem[conversion.Item_Id].push({
//         id: conversion.id,

//         Primary_Unit:
//           conversion.Primary_Unit,

//         Secondary_Unit:
//           conversion.Secondary_Unit,

//         Conversion_Rate:
//           Number(conversion.Conversion_Rate),
//       });
//     });

//     // =========================================================
//     // 11. MERGE EVERYTHING
//     // =========================================================

//     // const combined = items.map((item) => ({
//     //   ...item,

//     //   Purchase_Price:
//     //     latestPurchasePrice[item.Item_Id] ?? 0,

//     //   Tax_Type:
//     //     latestTaxType[item.Item_Id] ?? null,

//     //   Sale_Price:
//     //     latestSalePrice[item.Item_Id] ?? 0,

//     //   // All previously saved conversions
//     //   unitConversions:
//     //     conversionsByItem[item.Item_Id] || [],
//     // }));
//     // =========================================================
//     // 11. MERGE EVERYTHING
//     // =========================================================
// //     const [unitMaster] = await connection.query(`
// //   SELECT
// //     Unit_Name,
// //     Unit_Shorthand
// //   FROM units
// // `);
// //     const unitLookup = {};

// //     unitMaster.forEach((unit) => {
// //       unitLookup[unit.Unit_Shorthand] = unit.Unit_Name;
// //     });
// const combined = items.map((item) => {
//   const availableUnits = [];

//   // PRIMARY
//   if (item.Primary_Unit_Id) {
//     availableUnits.push({
//       Unit_Id: item.Primary_Unit_Id,
//       Unit_Shorthand:
//         item.Primary_Unit_Shorthand,

//       Unit_Name:
//         item.Primary_Unit_Name,
//     });
//   }

//   // SECONDARY
//   if (
//     item.Secondary_Unit_Id &&
//     item.Secondary_Unit_Id !== item.Primary_Unit_Id
//   ) {
//     availableUnits.push({
//       Unit_Id: item.Secondary_Unit_Id,

//       Unit_Shorthand:
//         item.Secondary_Unit_Shorthand,

//       Unit_Name:
//         item.Secondary_Unit_Name,
//     });
//   }

//   const hasTransactions =
//     usedItemSet.has(item.Item_Id);

//   const canEditUnits =
//     !item.Primary_Unit_Id
//       ? true
//       : !item.Secondary_Unit_Id
//       ? true
//       : !hasTransactions;

//   const isService =
//     item.Item_Type === "Service";

//   return {
//     ...item,
//  //Item_Unit:item.Item_Unit_Shorthand || item.Item_Unit,

//   // Primary_Unit:
//   //   item.Primary_Unit_Shorthand || item.Primary_Unit,

//   // Secondary_Unit:
//   //   item.Secondary_Unit_Shorthand || item.Secondary_Unit,
//     Purchase_Price: isService
//       ? null
//       : (item.Purchase_Price ?? 0),

//     Stock_Quantity: isService
//       ? null
//       : (item.Stock_Quantity ?? 0),

//     Sale_Price:item.Sale_Price ?? 0,

//     Available_Units:availableUnits,

//     unitConversions:conversionsByItem[item.Item_Id] || [],

//     Can_Edit_Units:canEditUnits,
//   };
// });
//     // const combined = items.map((item) => {
//     //   // =======================================================
//     //   // AVAILABLE UNITS = CURRENT ITEM MASTER ONLY
//     //   //
//     //   // Example:
//     //   // Current master:
//     //   // Primary   = Kgs
//     //   // Secondary = BOX
//     //   //
//     //   // Available_Units:
//     //   // Kgs + BOX
//     //   //
//     //   // OLD Kgs/gm conversions are NOT included here.
//     //   // =======================================================

//     //   const availableUnits = [];

//     //   // PRIMARY
//     //   if (item.Primary_Unit) {
//     //     availableUnits.push({
//     //       Unit_Shorthand: item.Primary_Unit,

//     //       Unit_Name:
//     //         unitLookup[item.Primary_Unit] ||
//     //         item.Primary_Unit,
//     //     });
//     //   }

//     //   // SECONDARY
//     //   if (
//     //     item.Secondary_Unit &&
//     //     item.Secondary_Unit !== item.Primary_Unit
//     //   ) {
//     //     availableUnits.push({
//     //       Unit_Shorthand: item.Secondary_Unit,

//     //       Unit_Name:
//     //         unitLookup[item.Secondary_Unit] ||
//     //         item.Secondary_Unit,
//     //     });
//     //   }
//     //   const hasTransactions = usedItemSet.has(item.Item_Id);

//     //   const canEditUnits =
//     //     !item.Primary_Unit
//     //       ? true
//     //       : !item.Secondary_Unit
//     //         ? true
//     //         : !hasTransactions;

//     //   const isService = item.Item_Type === "Service";
//     //   return {
//     //     ...item,

//     //     // Prices now come directly from add_item
//     //     Purchase_Price: isService
//     //       ? null
//     //       : (item.Purchase_Price ?? 0),
//     //     //Purchase_Price: item.Purchase_Price ?? 0,

//     //     Stock_Quantity: isService
//     //       ? null
//     //       : (item.Stock_Quantity ?? 0),
//     //     Sale_Price: item.Sale_Price ?? 0,

//     //     Available_Units: availableUnits,

//     //     unitConversions: conversionsByItem[item.Item_Id] || [],

//     //     Can_Edit_Units: canEditUnits,
//     //   };

//     // });

//     // =========================================================
//     // 12. RESPONSE
//     // =========================================================

//     return res.status(200).json({
//       success: true,

//       currentPage: page || 1,

//       totalPages: page
//         ? Math.ceil(totalItems[0].total / limit)
//         : 1,

//       totalItems: totalItems[0].total,

//       items: combined,
//     });

//   } catch (err) {
//     console.error("❌ Error fetching items:", err);
//     next(err);

//   } finally {
//     if (connection) {
//       connection.release();
//     }
//   }
// };

const getAllItems = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const page = req.query.page
      ? parseInt(req.query.page, 10)
      : null;

    const search = req.query.search
      ? req.query.search.trim().toLowerCase()
      : "";

    const fromDate = req.query.fromDate || null;
    const toDate = req.query.toDate || null;

    const limit = 10;
    const offset = page ? (page - 1) * limit : 0;

    // =========================================================
    // 1. BUILD WHERE
    // =========================================================

    const whereClauses = [];
    const params = [];

    if (search) {
      whereClauses.push(`
    (
      LOWER(ai.Item_Name) LIKE ?
      OR LOWER(ai.Item_Category) LIKE ?
      OR LOWER(ai.Item_HSN) LIKE ?

    )
  `);
      // OR LOWER(ai.Item_Id) LIKE ?
      // OR LOWER(iu.Unit_Shorthand) LIKE ?
      // OR LOWER(pu.Unit_Shorthand) LIKE ?
      // OR LOWER(su.Unit_Shorthand) LIKE ?
      const like = `%${search}%`;

      params.push(
        like,
        like,
        like
      );
    }

    // =========================================================
    // 2. DATE FILTER
    // =========================================================

    if (fromDate && toDate) {
      whereClauses.push(`DATE(created_at) BETWEEN ? AND ?`);
      params.push(fromDate, toDate);

    } else if (fromDate) {
      whereClauses.push(`DATE(created_at) >= ?`);
      params.push(fromDate);

    } else if (toDate) {
      whereClauses.push(`DATE(created_at) <= ?`);
      params.push(toDate);
    }

    const whereSQL = whereClauses.length
      ? `WHERE ${whereClauses.join(" AND ")}`
      : "";

    // Keep params without pagination for COUNT query
    const filterParams = [...params];

    // =========================================================
    // 3. GET ITEMS
    // =========================================================


    let query = `
  SELECT
    ai.id,
    ai.Item_Id,
    ai.Item_Type,
    ai.Item_Name,
    ai.Item_HSN,

    -- CURRENT ITEM UNIT FROM units
    iu.Unit_Shorthand AS Item_Unit,
    ai.Item_Unit_Id,

    ai.Item_Category,
      -- =====================================================
    -- ITEM CODE
    -- =====================================================

    ai.Item_Code,

    -- =====================================================
    -- PRICING
    -- =====================================================

    ai.MRP,
    ai.Discount_On_MRP_For_Sale,

    ai.Sale_Price,
    ai.Sale_Price_Type,

    ai.Discount_On_Sale_Price,
    ai.Discount_Type_On_Sale_Price,

    ai.Purchase_Price,
    ai.Purchase_Price_Type,

    -- CURRENT PRIMARY UNIT FROM units
    pu.Unit_Shorthand AS Primary_Unit,
    ai.Primary_Unit_Id,

    -- CURRENT SECONDARY UNIT FROM units
    su.Unit_Shorthand AS Secondary_Unit,
    ai.Secondary_Unit_Id,

    ai.Conversion_Rate,
    ai.Sale_Price,
    ai.Purchase_Price,
    ai.Stock_Quantity,
    ai.Opening_Quantity,
    ai.At_Price,
    ai.As_Of_Date,
    ai.Min_Stock,
    ai.Location,
    ai.created_at,
    ai.updated_at,

    -- UNIT DISPLAY NAMES
    iu.Unit_Name AS Item_Unit_Name,
    pu.Unit_Name AS Primary_Unit_Name,
    su.Unit_Name AS Secondary_Unit_Name,

    -- SHORTHANDS
    iu.Unit_Shorthand AS Item_Unit_Shorthand,
    pu.Unit_Shorthand AS Primary_Unit_Shorthand,
    su.Unit_Shorthand AS Secondary_Unit_Shorthand

  FROM add_item ai

  LEFT JOIN units iu
    ON ai.Item_Unit_Id = iu.id

  LEFT JOIN units pu
    ON ai.Primary_Unit_Id = pu.id

  LEFT JOIN units su
    ON ai.Secondary_Unit_Id = su.id

  ${whereSQL}

  ORDER BY ai.created_at DESC
`;

    if (page) {
      query += ` LIMIT ? OFFSET ?`;
      params.push(limit, offset);
    }

    const [items] = await connection.query(
      query,
      params
    );

    // =========================================================
    // 4. COUNT
    // =========================================================

    const [totalItems] = await connection.query(
      `
  SELECT COUNT(*) AS total
  FROM add_item ai

  LEFT JOIN units iu
    ON ai.Item_Unit_Id = iu.id

  LEFT JOIN units pu
    ON ai.Primary_Unit_Id = pu.id

  LEFT JOIN units su
    ON ai.Secondary_Unit_Id = su.id

  ${whereSQL}
  `,
      filterParams
    );


    const [unitConversions] = await connection.query(`
      SELECT
        id,
        
        Primary_Unit,
        Secondary_Unit,
        Conversion_Rate,
        created_at
      FROM item_unit_conversions
      ORDER BY created_at DESC, id DESC
    `);
    // =========================================================
    // 7A. ITEMS USED IN TRANSACTIONS
    // =========================================================

    const [usedItems] = await connection.query(`
SELECT DISTINCT Item_Id
FROM (
    SELECT Item_Id FROM add_purchase_items

    UNION

    SELECT Item_Id FROM add_sale_items

    UNION

    SELECT Item_Id FROM purchase_return_items

    UNION

    SELECT Item_Id FROM sale_return_items
) t
`);

    const usedItemSet = new Set(
      usedItems.map((row) => row.Item_Id)
    );

    // =========================================================
    // 8. LATEST PURCHASE PRICE + TAX
    // =========================================================

    // const latestPurchasePrice = {};
    // const latestTaxType = {};

    // purchaseItems.forEach((row) => {
    //   if (latestPurchasePrice[row.Item_Id] === undefined) {
    //     latestPurchasePrice[row.Item_Id] =
    //       row.Purchase_Price;

    //     latestTaxType[row.Item_Id] =
    //       row.Tax_Type;
    //   }
    // });

    // =========================================================
    // 9. LATEST SALE PRICE
    // =========================================================

    // const latestSalePrice = {};

    // salesItems.forEach((row) => {
    //   if (latestSalePrice[row.Item_Id] === undefined) {
    //     latestSalePrice[row.Item_Id] =
    //       row.Sale_Price;
    //   }
    // });

    // =========================================================
    // 10. GROUP CONVERSIONS BY ITEM
    // =========================================================

    const conversionsByItem = {};

    unitConversions.forEach((conversion) => {
      if (!conversionsByItem[conversion.Item_Id]) {
        conversionsByItem[conversion.Item_Id] = [];
      }

      conversionsByItem[conversion.Item_Id].push({
        id: conversion.id,

        Primary_Unit:
          conversion.Primary_Unit,

        Secondary_Unit:
          conversion.Secondary_Unit,

        Conversion_Rate:
          Number(conversion.Conversion_Rate),
      });
    });

    // =========================================================
    // 11. MERGE EVERYTHING
    // =========================================================

    const combined = items.map((item) => {
      const availableUnits = [];

      // PRIMARY
      if (item.Primary_Unit_Id) {
        availableUnits.push({
          Unit_Id: item.Primary_Unit_Id,
          Unit_Shorthand:
            item.Primary_Unit_Shorthand,

          Unit_Name:
            item.Primary_Unit_Name,
        });
      }

      // SECONDARY
      if (
        item.Secondary_Unit_Id &&
        item.Secondary_Unit_Id !== item.Primary_Unit_Id
      ) {
        availableUnits.push({
          Unit_Id: item.Secondary_Unit_Id,

          Unit_Shorthand:
            item.Secondary_Unit_Shorthand,

          Unit_Name:
            item.Secondary_Unit_Name,
        });
      }

      const hasTransactions =
        usedItemSet.has(item.Item_Id);

      const canEditUnits =
        !item.Primary_Unit_Id
          ? true
          : !item.Secondary_Unit_Id
            ? true
            : !hasTransactions;

      const isService =
        item.Item_Type === "Service";

      return {
        ...item,
        //Item_Unit:item.Item_Unit_Shorthand || item.Item_Unit,

        // Primary_Unit:
        //   item.Primary_Unit_Shorthand || item.Primary_Unit,

        // Secondary_Unit:
        //   item.Secondary_Unit_Shorthand || item.Secondary_Unit,
        Purchase_Price: isService
          ? null
          : (item.Purchase_Price ?? 0),

        Stock_Quantity: isService
          ? null
          : (item.Stock_Quantity ?? 0),

        Sale_Price: item.Sale_Price ?? 0,
        MRP:
          item.MRP !== null
            ? Number(item.MRP)
            : null,

        Discount_On_MRP_For_Sale:
          item.Discount_On_MRP_For_Sale !== null
            ? Number(item.Discount_On_MRP_For_Sale)
            : null,

        Sale_Price_Type:
          item.Sale_Price_Type || "Without_Tax",

        Discount_On_Sale_Price:
          item.Discount_On_Sale_Price !== null
            ? Number(item.Discount_On_Sale_Price)
            : null,

        Discount_Type_On_Sale_Price:
          item.Discount_Type_On_Sale_Price || "Percentage",

        Purchase_Price_Type:
          item.Purchase_Price_Type || "Without_Tax",

        Available_Units: availableUnits,

        unitConversions: conversionsByItem[item.Item_Id] || [],

        Can_Edit_Units: canEditUnits,
      };
    });

    // =========================================================
    // 12. RESPONSE
    // =========================================================

    return res.status(200).json({
      success: true,

      currentPage: page || 1,

      totalPages: page
        ? Math.ceil(totalItems[0].total / limit)
        : 1,

      totalItems: totalItems[0].total,

      items: combined,
    });

  } catch (err) {
    console.error("❌ Error fetching items:", err);
    next(err);

  } finally {
    if (connection) {
      connection.release();
    }
  }
};

const getItemsForDropdown = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const search = req.query.search?.trim() || "";
    const cursor = req.query.cursor
      ? Number(req.query.cursor)
      : null;

    const limit = Math.min(
      Number(req.query.limit) || 20,
      50
    );

    const params = [];
    const whereClauses = [];

    // =====================================================
    // SEARCH ENTIRE ITEM TABLE
    // =====================================================

    if (search) {
      const like = `%${search}%`;

      whereClauses.push(`
        (
          LOWER(ai.Item_Name) LIKE LOWER(?)
          OR LOWER(ai.Item_Code) LIKE LOWER(?)
          OR LOWER(ai.Item_Id) LIKE LOWER(?)
          OR LOWER(ai.Item_Category) LIKE LOWER(?)
          OR LOWER(ai.Item_HSN) LIKE LOWER(?)
        )
      `);

      params.push(
        like,
        like,
        like,
        like,
        like
      );
    }

    // =====================================================
    // CURSOR
    // =====================================================

    if (cursor) {
      whereClauses.push(`ai.id < ?`);
      params.push(cursor);
    }

    const whereSQL = whereClauses.length
      ? `WHERE ${whereClauses.join(" AND ")}`
      : "";

    // =====================================================
    // FETCH ONE EXTRA
    // =====================================================

    const [rows] = await connection.query(
      `
 SELECT
  ai.id,
  ai.Item_Id,
  ai.Item_Type,

  ai.Item_Name,
  ai.Item_HSN,
  ai.Item_Category,
  ai.Item_Code,

  ai.MRP,
  ai.Discount_On_MRP_For_Sale,

  ai.Sale_Price,
  ai.Sale_Price_Type,
  ai.Discount_On_Sale_Price,
  ai.Discount_Type_On_Sale_Price,

  ai.Purchase_Price,
  ai.Purchase_Price_Type,

  ai.Item_Unit_Id,
  iu.Unit_Shorthand AS Item_Unit,
  iu.Unit_Name AS Item_Unit_Name,

  ai.Primary_Unit_Id,
  pu.Unit_Shorthand AS Primary_Unit,
  pu.Unit_Name AS Primary_Unit_Name,

  ai.Secondary_Unit_Id,
  su.Unit_Shorthand AS Secondary_Unit,
  su.Unit_Name AS Secondary_Unit_Name,

  ai.Conversion_Rate,
  ai.Stock_Quantity

FROM add_item ai

LEFT JOIN units iu
  ON ai.Item_Unit_Id = iu.id

LEFT JOIN units pu
  ON ai.Primary_Unit_Id = pu.id

LEFT JOIN units su
  ON ai.Secondary_Unit_Id = su.id

${whereSQL}

ORDER BY ai.id DESC

LIMIT ?
  `,
      [...params, limit + 1]
    );
    // =====================================================
    // HAS MORE
    // =====================================================

    const hasMore = rows.length > limit;

    // =====================================================
    // GET ONLY THE ACTUAL PAGE ITEMS
    // AND FORMAT THEM
    // =====================================================

    const items = rows
      .slice(0, limit)
      .map((item) => {

        const availableUnits = [];

        // -------------------------------------------------
        // PRIMARY UNIT
        // -------------------------------------------------

        if (item.Primary_Unit_Id) {
          availableUnits.push({
            Unit_Id: item.Primary_Unit_Id,
            Unit_Shorthand: item.Primary_Unit,
            Unit_Name: item.Primary_Unit_Name,
          });
        }

        // -------------------------------------------------
        // SECONDARY UNIT
        // -------------------------------------------------

        if (
          item.Secondary_Unit_Id &&
          item.Secondary_Unit_Id !== item.Primary_Unit_Id
        ) {
          availableUnits.push({
            Unit_Id: item.Secondary_Unit_Id,
            Unit_Shorthand: item.Secondary_Unit,
            Unit_Name: item.Secondary_Unit_Name,
          });
        }

        // -------------------------------------------------
        // RETURN FORMATTED ITEM
        // -------------------------------------------------

        return {
          ...item,

          Sale_Price:
            item.Sale_Price !== null
              ? Number(item.Sale_Price)
              : 0,

          Purchase_Price:
            item.Purchase_Price !== null
              ? Number(item.Purchase_Price)
              : 0,

          MRP:
            item.MRP !== null
              ? Number(item.MRP)
              : null,

          Discount_On_MRP_For_Sale:
            item.Discount_On_MRP_For_Sale !== null
              ? Number(item.Discount_On_MRP_For_Sale)
              : null,

          Discount_On_Sale_Price:
            item.Discount_On_Sale_Price !== null
              ? Number(item.Discount_On_Sale_Price)
              : null,

          Conversion_Rate:
            item.Conversion_Rate !== null
              ? Number(item.Conversion_Rate)
              : null,

          Stock_Quantity:
            Number(item.Stock_Quantity || 0),

          Available_Units: availableUnits,
        };
      });

    // =====================================================
    // NEXT CURSOR
    // =====================================================

    const nextCursor =
      hasMore && items.length > 0
        ? items[items.length - 1].id
        : null;

    // =====================================================
    // RESPONSE
    // =====================================================

    return res.status(200).json({
      success: true,
      items,
      hasMore,
      nextCursor,
    });

  } catch (err) {
    console.error(
      "❌ Error fetching items for dropdown:",
      err
    );

    next(err);

  } finally {
    if (connection) {
      connection.release();
    }
  }
};

const getItemByName = async (req, res, next) => {
  try {
    const name = req.query.name?.trim();

    if (!name) {
      return res.status(400).json({
        success: false,
        message: "Item name is required.",
      });
    }

    const [rows] = await db.query(
      `
      SELECT
        ai.id,
        ai.Item_Id,
        ai.Item_Type,

        ai.Item_Name,
        ai.Item_HSN,
        ai.Item_Category,
        ai.Item_Code,

        ai.MRP,
        ai.Discount_On_MRP_For_Sale,

        ai.Sale_Price,
        ai.Sale_Price_Type,
        ai.Discount_On_Sale_Price,
        ai.Discount_Type_On_Sale_Price,

        ai.Purchase_Price,
        ai.Purchase_Price_Type,

        ai.Item_Unit_Id,
        iu.Unit_Shorthand AS Item_Unit,
        iu.Unit_Name AS Item_Unit_Name,

        ai.Primary_Unit_Id,
        pu.Unit_Shorthand AS Primary_Unit,
        pu.Unit_Name AS Primary_Unit_Name,

        ai.Secondary_Unit_Id,
        su.Unit_Shorthand AS Secondary_Unit,
        su.Unit_Name AS Secondary_Unit_Name,

        ai.Conversion_Rate,

        ai.Stock_Quantity

      FROM add_item ai

      LEFT JOIN units iu
        ON ai.Item_Unit_Id = iu.id

      LEFT JOIN units pu
        ON ai.Primary_Unit_Id = pu.id

      LEFT JOIN units su
        ON ai.Secondary_Unit_Id = su.id

      WHERE ai.Item_Name = ?

      LIMIT 1
      `,
      [name]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No item found with name "${name}".`,
      });
    }

    const item = rows[0];

    // =====================================================
    // AVAILABLE UNITS
    // =====================================================

    const availableUnits = [];

    if (item.Primary_Unit_Id) {
      availableUnits.push({
        Unit_Id: item.Primary_Unit_Id,
        Unit_Shorthand: item.Primary_Unit,
        Unit_Name: item.Primary_Unit_Name,
      });
    }

    if (
      item.Secondary_Unit_Id &&
      item.Secondary_Unit_Id !== item.Primary_Unit_Id
    ) {
      availableUnits.push({
        Unit_Id: item.Secondary_Unit_Id,
        Unit_Shorthand: item.Secondary_Unit,
        Unit_Name: item.Secondary_Unit_Name,
      });
    }

    // =====================================================
    // RESPONSE
    // =====================================================

    return res.status(200).json({
      success: true,

      item: {
        ...item,

        Sale_Price:
          item.Sale_Price !== null
            ? Number(item.Sale_Price)
            : 0,

        Purchase_Price:
          item.Purchase_Price !== null
            ? Number(item.Purchase_Price)
            : 0,

        MRP:
          item.MRP !== null
            ? Number(item.MRP)
            : null,

        Discount_On_MRP_For_Sale:
          item.Discount_On_MRP_For_Sale !== null
            ? Number(item.Discount_On_MRP_For_Sale)
            : null,

        Discount_On_Sale_Price:
          item.Discount_On_Sale_Price !== null
            ? Number(item.Discount_On_Sale_Price)
            : null,

        Conversion_Rate:
          item.Conversion_Rate !== null
            ? Number(item.Conversion_Rate)
            : null,

        Stock_Quantity:
          Number(item.Stock_Quantity || 0),

        Available_Units: availableUnits,
      },
    });

  } catch (err) {
    console.error(
      "❌ Error fetching item by name:",
      err
    );

    next(err);
  }
};
//PREVIOUS
// const getAllItemsForLedger = async (req, res, next) => {
//   let connection;

//   try {
//     connection = await db.getConnection();

//     // =========================================================
//     // 1. SEARCH
//     // =========================================================

//     const search = req.query.search
//       ? req.query.search.trim().toLowerCase()
//       : "";
//     const limit = parseInt(req.query.limit, 10) || 10;
//     const cursorId = req.query.cursor ? Number(req.query.cursor) : null;
//     const type = req.query.type?.trim();


//     const whereParts = [];
//     const params = [];


//   //   if (search) {
//   //     const like = `%${search}%`;

//   //     whereParts.push(`(
//   //   LOWER(Item_Name) LIKE ?
//   //   OR LOWER(Item_Category) LIKE ?
//   //   OR LOWER(Item_HSN) LIKE ?
//   //   OR LOWER(Item_Id) LIKE ?
//   //   OR LOWER(Item_Unit) LIKE ?
//   //   OR LOWER(Primary_Unit) LIKE ?
//   //   OR LOWER(Secondary_Unit) LIKE ?
//   // )`);

//   //     params.push(like, like, like, like, like, like, like);
//   //   }

//   //   if (type === "Product") {
//   //     whereParts.push(`Item_Type = 'Product'`);
//   //   }

//   //   if (type === "Service") {
//   //     whereParts.push(`Item_Type = 'Service'`);
//   //   }

//   //   if (cursorId) {
//   //     whereParts.push(`id < ?`);
//   //     params.push(cursorId);
//   //   }
// if (search) {
//   const like = `%${search}%`;

//   whereParts.push(`(
//     LOWER(ai.Item_Name) LIKE ?
//     OR LOWER(ai.Item_Category) LIKE ?
//     OR LOWER(ai.Item_HSN) LIKE ?
//     OR LOWER(ai.Item_Id) LIKE ?
//     OR LOWER(ai.Item_Unit) LIKE ?
//     OR LOWER(ai.Primary_Unit) LIKE ?
//     OR LOWER(ai.Secondary_Unit) LIKE ?
//   )`);

//   params.push(like, like, like, like, like, like, like);
// }

// if (type === "Product") {
//   whereParts.push(`ai.Item_Type = 'Product'`);
// }

// if (type === "Service") {
//   whereParts.push(`ai.Item_Type = 'Service'`);
// }

// if (cursorId) {
//   whereParts.push(`ai.id < ?`);
//   params.push(cursorId);
// }
//     const whereSQL =
//       whereParts.length
//         ? `WHERE ${whereParts.join(" AND ")}`
//         : "";

//     // =========================================================
//     // 2. GET ALL ITEMS
//     //
//     // Same important fields as getAllItems
//     // =========================================================

//     // const [items] = await connection.query(
//     //   `
//     //   SELECT
//     //     id,
//     //     Item_Id,
//     //     Item_Name,
//     //     Item_HSN,
//     //     Item_Category,
//     //     Item_Unit,

//     //     Primary_Unit,
//     //     Secondary_Unit,
//     //     Conversion_Rate,

//     //     Stock_Quantity,
//     //     Opening_Quantity,
//     //     At_Price,
//     //     As_Of_Date,
//     //     Min_Stock,
//     //     Location,

//     //     created_at,
//     //     updated_at

//     //   FROM add_item

//     //   ${whereSQL}

//     // ORDER BY id DESC
//     //   `,
//     //   [...params, limit + 1]
//     // );

//     // =========================================================
//     // 3. PURCHASE HISTORY
//     //
//     // Used to get latest purchase price + tax type
//     // =========================================================

//     const [purchaseItems] = await connection.query(
//       `
//       SELECT
//         Item_Id,
//         Purchase_Price,
//         Tax_Type,
//         created_at
//       FROM add_purchase_items
//       ORDER BY created_at DESC
//       `
//     );

//     // =========================================================
//     // 4. SALES HISTORY
//     //
//     // Used to get latest sale price
//     // =========================================================

//     const [salesItems] = await connection.query(
//       `
//       SELECT
//         Item_Id,
//         Sale_Price,
//         created_at
//       FROM add_sale_items
//       ORDER BY created_at DESC
//       `
//     );

//     // =========================================================
//     // 5. UNIT CONVERSION HISTORY
//     // =========================================================

//     // const [unitConversions] = await connection.query(
//     //   `
//     //   SELECT
//     //     id,
//     //     Item_Id,
//     //     Primary_Unit,
//     //     Secondary_Unit,
//     //     Conversion_Rate,
//     //     created_at
//     //   FROM item_unit_conversions
//     //   ORDER BY created_at DESC, id DESC
//     //   `
//     // );
//     const [unitConversions] = await connection.query(
//       `
//       SELECT
//         id,

//         Primary_Unit,
//         Secondary_Unit,
//         Conversion_Rate,
//         created_at
//       FROM item_unit_conversions
//       ORDER BY created_at DESC, id DESC
//       `
//     );

//     // =========================================================
//     // 6. ITEMS USED IN TRANSACTIONS
//     //
//     // Needed for Can_Edit_Units
//     //
//     // If an item already has transactions and both
//     // Primary + Secondary units exist, don't allow
//     // changing the unit configuration.
//     // =========================================================

//     // const [usedItems] = await connection.query(
//     //   `
//     //   SELECT DISTINCT Item_Id
//     //   FROM (
//     //     SELECT Item_Id
//     //     FROM add_purchase_items

//     //     UNION

//     //     SELECT Item_Id
//     //     FROM add_sale_items

//     //     UNION

//     //     SELECT Item_Id
//     //     FROM purchase_return_items

//     //     UNION

//     //     SELECT Item_Id
//     //     FROM sale_return_items
//     //   ) t
//     //   `
//     // );
//     const [usedUnitsRows] = await connection.query(`
//   SELECT Item_Id, Selected_Unit
//   FROM add_purchase_items
//   WHERE Selected_Unit IS NOT NULL
//     AND TRIM(Selected_Unit) <> ''

//   UNION

//   SELECT Item_Id, Selected_Unit
//   FROM add_sale_items
//   WHERE Selected_Unit IS NOT NULL
//     AND TRIM(Selected_Unit) <> ''

//   UNION

//   SELECT Item_Id, Selected_Unit
//   FROM purchase_return_items
//   WHERE Selected_Unit IS NOT NULL
//     AND TRIM(Selected_Unit) <> ''

//   UNION

//   SELECT Item_Id, Selected_Unit
//   FROM sale_return_items
//   WHERE Selected_Unit IS NOT NULL
//     AND TRIM(Selected_Unit) <> ''
// `);

//     // const usedItemSet = new Set(
//     //   usedItems.map((row) => row.Item_Id)
//     // );
//     const usedUnitsByItem = {};

//     usedUnitsRows.forEach((row) => {
//       if (!usedUnitsByItem[row.Item_Id]) {
//         usedUnitsByItem[row.Item_Id] = new Set();
//       }

//       usedUnitsByItem[row.Item_Id].add(
//         row.Selected_Unit.trim()
//       );
//     });

//     // =========================================================
//     // 7. LATEST PURCHASE PRICE + TAX
//     //
//     // purchaseItems are already ordered DESC,
//     // so first occurrence is latest.
//     // =========================================================

//     const latestPurchasePrice = {};
//     const latestTaxType = {};

//     purchaseItems.forEach((row) => {
//       if (latestPurchasePrice[row.Item_Id] === undefined) {
//         latestPurchasePrice[row.Item_Id] =
//           row.Purchase_Price;

//         latestTaxType[row.Item_Id] =
//           row.Tax_Type;
//       }
//     });

//     // =========================================================
//     // 8. LATEST SALE PRICE
//     // =========================================================

//     const latestSalePrice = {};

//     salesItems.forEach((row) => {
//       if (latestSalePrice[row.Item_Id] === undefined) {
//         latestSalePrice[row.Item_Id] =
//           row.Sale_Price;
//       }
//     });

//     // =========================================================
//     // 9. GROUP CONVERSION HISTORY BY ITEM
//     // =========================================================

//     const conversionsByItem = {};

//     unitConversions.forEach((conversion) => {
//       if (!conversionsByItem[conversion.Item_Id]) {
//         conversionsByItem[conversion.Item_Id] = [];
//       }

//       conversionsByItem[conversion.Item_Id].push({
//         id: conversion.id,

//         Primary_Unit: conversion.Primary_Unit,

//         Secondary_Unit: conversion.Secondary_Unit,

//         Conversion_Rate:
//           conversion.Conversion_Rate !== null
//             ? Number(conversion.Conversion_Rate)
//             : null,

//         created_at:
//           conversion.created_at,
//       });
//     });

//     // =========================================================
//     // 10. UNIT MASTER
//     //
//     // Used to show unit name + shorthand
//     // =========================================================

//     // const [unitMaster] = await connection.query(
//     //   `
//     //   SELECT
//     //     Unit_Name,
//     //     Unit_Shorthand
//     //   FROM units
//     //   `
//     // );

//     // const unitLookup = {};

//     // unitMaster.forEach((unit) => {
//     //   unitLookup[unit.Unit_Shorthand] =
//     //     unit.Unit_Name;
//     // });


//   //   const [[{ totalItems }]] = await db.query(
//   //     `
//   // SELECT COUNT(*) AS totalItems
//   // FROM add_item
//   // ${whereSQL}
//   // `,
//   //     params
//   //   );
//   const [[{ totalItems }]] = await connection.query(
//   `
//   SELECT COUNT(*) AS totalItems
//   FROM add_item ai
//   ${whereSQL}
//   `,
//   params
// );

//   //   const [rows] = await db.query(
//   //     `
//   // SELECT *
//   // FROM add_item
//   // ${whereSQL}
//   // ORDER BY id DESC
//   // LIMIT ?
//   // `,
//   //     [...params, limit + 1]
//   //   );
//   const [rows]= await db.query(
//     `SELECT
//   ai.*,

//   pu.Unit_Name      AS Primary_Unit_Name,
//   pu.Unit_Shorthand AS Primary_Unit_Shorthand,

//   su.Unit_Name      AS Secondary_Unit_Name,
//   su.Unit_Shorthand AS Secondary_Unit_Shorthand

// FROM add_item ai

// LEFT JOIN units pu
//   ON ai.Primary_Unit_Id = pu.id

// LEFT JOIN units su
//   ON ai.Secondary_Unit_Id = su.id

// ${whereSQL}

// ORDER BY ai.id DESC
// LIMIT ?`
//     ,
//     [...params, limit + 1]
//   )

//     const hasMore = rows.length > limit;
//     const pageItems = hasMore ? rows.slice(0, limit) : rows;

//     // const result = pageItems.map((item) => {

//     //   // -------------------------------------------------------
//     //   // CURRENT AVAILABLE UNITS
//     //   //
//     //   // Only current item master units.
//     //   // Historical conversions are kept separately.
//     //   // -------------------------------------------------------

//     //   const availableUnits = [];

//     //   // PRIMARY UNIT
//     //   if (item.Primary_Unit) {
//     //     availableUnits.push({
//     //       Unit_Shorthand:
//     //         item.Primary_Unit,

//     //       Unit_Name:
//     //         unitLookup[item.Primary_Unit] ||
//     //         item.Primary_Unit,
//     //     });
//     //   }

//     //   // SECONDARY UNIT
//     //   if (
//     //     item.Secondary_Unit &&
//     //     item.Secondary_Unit !== item.Primary_Unit
//     //   ) {
//     //     availableUnits.push({
//     //       Unit_Shorthand:
//     //         item.Secondary_Unit,

//     //       Unit_Name:
//     //         unitLookup[item.Secondary_Unit] ||
//     //         item.Secondary_Unit,
//     //     });
//     //   }

//     //   // =======================================================
//     //   // UNIT USAGE / EDIT PERMISSION
//     //   // =======================================================

//     //   // const hasTransactions =usedItemSet.has(item.Item_Id);




//     //   const usedUnits =
//     //     usedUnitsByItem[item.Item_Id] || new Set();

//     //   const primaryUsed =
//     //     item.Primary_Unit
//     //       ? usedUnits.has(item.Primary_Unit)
//     //       : false;

//     //   const secondaryUsed =
//     //     item.Secondary_Unit
//     //       ? usedUnits.has(item.Secondary_Unit)
//     //       : false;

//     //   //    const canEditUnits =
//     //   // !item.Secondary_Unit
//     //   //   ? true
//     //   //   : !primaryUsed;
//     //   const canEditUnits = {
//     //     Primary: !primaryUsed,

//     //     // If there is no secondary yet, it can be added.
//     //     // If secondary exists, it can only be changed if it has NOT been used.
//     //     Secondary: !secondaryUsed,
//     //   };

//     //   // -------------------------------------------------------
//     //   // RETURN ITEM
//     //   // -------------------------------------------------------

//     //   return {
//     //     ...item,

//     //     // Latest transaction information
//     //     Purchase_Price:
//     //       latestPurchasePrice[item.Item_Id] ?? 0,

//     //     Tax_Type:
//     //       latestTaxType[item.Item_Id] ?? null,

//     //     Sale_Price:
//     //       latestSalePrice[item.Item_Id] ?? 0,

//     //     // Current configured units
//     //     Available_Units: availableUnits,

//     //     // Historical conversion records
//     //     unitConversions:
//     //       conversionsByItem[item.Item_Id] || [],

//     //     // Unit editing permission
//     //     Can_Edit_Units:
//     //       canEditUnits,

//     //     // Numeric values
//     //     Conversion_Rate:
//     //       item.Conversion_Rate !== null
//     //         ? Number(item.Conversion_Rate)
//     //         : null,

//     //     Stock_Quantity:
//     //       Number(item.Stock_Quantity || 0),

//     //     Opening_Quantity:
//     //       item.Opening_Quantity !== null
//     //         ? Number(item.Opening_Quantity)
//     //         : null,

//     //     At_Price:
//     //       item.At_Price !== null
//     //         ? Number(item.At_Price)
//     //         : null,

//     //     Min_Stock:
//     //       item.Min_Stock !== null
//     //         ? Number(item.Min_Stock)
//     //         : null,
//     //   };
//     // });

//     // =========================================================
//     // 12. RESPONSE
//     // =========================================================

// const result = pageItems.map((item) => {
//   // =======================================================
//   // AVAILABLE UNITS
//   // =======================================================

//   const availableUnits = [];

//   if (item.Primary_Unit_Id) {
//     availableUnits.push({
//       Unit_Id: item.Primary_Unit_Id,
//       Unit_Shorthand: item.Primary_Unit_Shorthand,
//       Unit_Name: item.Primary_Unit_Name,
//     });
//   }

//   if (
//     item.Secondary_Unit_Id &&
//     item.Secondary_Unit_Id !== item.Primary_Unit_Id
//   ) {
//     availableUnits.push({
//       Unit_Id: item.Secondary_Unit_Id,
//       Unit_Shorthand: item.Secondary_Unit_Shorthand,
//       Unit_Name: item.Secondary_Unit_Name,
//     });
//   }

//   // =======================================================
//   // UNIT USAGE / EDIT PERMISSION
//   // =======================================================

//   const usedUnits =
//     usedUnitsByItem[item.Item_Id] || new Set();

//   const primaryUsed =
//     item.Primary_Unit_Shorthand
//       ? usedUnits.has(item.Primary_Unit_Shorthand)
//       : false;

//   const secondaryUsed =
//     item.Secondary_Unit_Shorthand
//       ? usedUnits.has(item.Secondary_Unit_Shorthand)
//       : false;

//   const canEditUnits = {
//     Primary: !primaryUsed,
//     Secondary: !secondaryUsed,
//   };

//   // =======================================================
//   // RETURN ITEM
//   // =======================================================

//   return {
//     ...item,

//     Purchase_Price:
//       latestPurchasePrice[item.Item_Id] ?? 0,

//     Tax_Type:
//       latestTaxType[item.Item_Id] ?? null,

//     Sale_Price:
//       latestSalePrice[item.Item_Id] ?? 0,

//     Available_Units: availableUnits,

//     unitConversions:
//       conversionsByItem[item.Item_Id] || [],

//     Can_Edit_Units: canEditUnits,

//     Conversion_Rate:
//       item.Conversion_Rate !== null
//         ? Number(item.Conversion_Rate)
//         : null,

//     Stock_Quantity:
//       Number(item.Stock_Quantity || 0),

//     Opening_Quantity:
//       item.Opening_Quantity !== null
//         ? Number(item.Opening_Quantity)
//         : null,

//     At_Price:
//       item.At_Price !== null
//         ? Number(item.At_Price)
//         : null,

//     Min_Stock:
//       item.Min_Stock !== null
//         ? Number(item.Min_Stock)
//         : null,
//   };
// });
//     return res.status(200).json({
//       success: true,
//       totalItems,
//       //totalItems: result.length,

//       items: result,
//       hasMore,
//       nextCursor: hasMore ? pageItems[pageItems.length - 1].id : null,
//     });

//   } catch (err) {

//     console.error(
//       "❌ Error fetching items for ledger:",
//       err
//     );

//     next(err);

//   } finally {

//     if (connection) {
//       connection.release();
//     }
//   }
// };
const getAllItemsForLedger = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    // =========================================================
    // 1. SEARCH / PAGINATION
    // =========================================================

    const search = req.query.search
      ? req.query.search.trim().toLowerCase()
      : "";

    //const limit = parseInt(req.query.limit, 10) || 10;
    const limit = Math.min(parseInt(req.query.limit, 10) || 10, 200);

    const cursorId = req.query.cursor
      ? Number(req.query.cursor)
      : null;

    const type = req.query.type?.trim();

    const whereParts = [];
    const params = [];

    // =========================================================
    // SEARCH
    // =========================================================

    if (search) {
      const like = `%${search}%`;

      whereParts.push(`(
        LOWER(ai.Item_Name) LIKE ?
        OR LOWER(ai.Item_Category) LIKE ?
        OR LOWER(ai.Item_HSN) LIKE ?
        OR LOWER(ai.Item_Id) LIKE ?

        -- UNIT SEARCH NOW COMES FROM units TABLE
        OR LOWER(iu.Unit_Shorthand) LIKE ?
        OR LOWER(pu.Unit_Shorthand) LIKE ?
        OR LOWER(su.Unit_Shorthand) LIKE ?
      )`);

      params.push(
        like,
        like,
        like,
        like,
        like,
        like,
        like
      );
    }

    // =========================================================
    // ITEM TYPE
    // =========================================================

    if (type === "Product") {
      whereParts.push(`ai.Item_Type = 'Product'`);
    }

    if (type === "Service") {
      whereParts.push(`ai.Item_Type = 'Service'`);
    }

    // =========================================================
    // CURSOR
    // =========================================================

    if (cursorId) {
      whereParts.push(`ai.id < ?`);
      params.push(cursorId);
    }

    const whereSQL =
      whereParts.length
        ? `WHERE ${whereParts.join(" AND ")}`
        : "";

    // =========================================================
    // 2. PURCHASE HISTORY
    // =========================================================
    //
    // Used to get latest purchase price + tax type
    //
    // =========================================================

    // const [purchaseItems] = await connection.query(
    //   `
    //   SELECT
    //     Item_Id,
    //     Purchase_Price,
    //     Tax_Type,
    //     created_at
    //   FROM add_purchase_items
    //   ORDER BY created_at DESC
    //   `
    // );

    // =========================================================
    // 3. SALES HISTORY
    // =========================================================
    //
    // Used to get latest sale price
    //
    // =========================================================

    // const [salesItems] = await connection.query(
    //   `
    //   SELECT
    //     Item_Id,
    //     Sale_Price,
    //     created_at
    //   FROM add_sale_items
    //   ORDER BY created_at DESC
    //   `
    // );

    // =========================================================
    // 4. UNIT CONVERSION HISTORY
    // =========================================================
    //
    // LEFT AS-IS because these columns have not been migrated
    // to IDs yet.
    //
    // =========================================================

    const [unitConversions] = await connection.query(
      `
      SELECT
        id,
        
        Primary_Unit,
        Secondary_Unit,
        Conversion_Rate,
        created_at
      FROM item_unit_conversions
      ORDER BY created_at DESC, id DESC
      `
    );

    // =========================================================
    // 5. ITEMS / UNITS USED IN TRANSACTIONS
    // =========================================================
    //
    // IMPORTANT:
    // We now use Selected_Unit_Id instead of Selected_Unit text.
    //
    // This means unit locking continues to work even if the
    // Unit_Shorthand is renamed in the units table.
    //
    // =========================================================

    const [usedUnitsRows] = await connection.query(`
      SELECT
        Item_Id,
        Selected_Unit_Id
      FROM add_purchase_items
      WHERE Selected_Unit_Id IS NOT NULL

      UNION

      SELECT
        Item_Id,
        Selected_Unit_Id
      FROM add_sale_items
      WHERE Selected_Unit_Id IS NOT NULL

      UNION

      SELECT
        Item_Id,
        Selected_Unit_Id
      FROM purchase_return_items
      WHERE Selected_Unit_Id IS NOT NULL

      UNION

      SELECT
        Item_Id,
        Selected_Unit_Id
      FROM sale_return_items
      WHERE Selected_Unit_Id IS NOT NULL
    `);

    const usedUnitsByItem = {};

    usedUnitsRows.forEach((row) => {
      if (!usedUnitsByItem[row.Item_Id]) {
        usedUnitsByItem[row.Item_Id] = new Set();
      }

      usedUnitsByItem[row.Item_Id].add(
        Number(row.Selected_Unit_Id)
      );
    });

    // =========================================================
    // 6. LATEST PURCHASE PRICE + TAX
    // =========================================================

    // const latestPurchasePrice = {};
    // const latestTaxType = {};

    // purchaseItems.forEach((row) => {
    //   if (
    //     latestPurchasePrice[row.Item_Id] === undefined
    //   ) {
    //     latestPurchasePrice[row.Item_Id] =
    //       row.Purchase_Price;

    //     latestTaxType[row.Item_Id] =
    //       row.Tax_Type;
    //   }
    // });

    // // =========================================================
    // // 7. LATEST SALE PRICE
    // // =========================================================

    // const latestSalePrice = {};

    // salesItems.forEach((row) => {
    //   if (
    //     latestSalePrice[row.Item_Id] === undefined
    //   ) {
    //     latestSalePrice[row.Item_Id] =
    //       row.Sale_Price;
    //   }
    // });

    // =========================================================
    // 8. GROUP CONVERSION HISTORY BY ITEM
    // =========================================================

    const conversionsByItem = {};

    unitConversions.forEach((conversion) => {
      if (!conversionsByItem[conversion.Item_Id]) {
        conversionsByItem[conversion.Item_Id] = [];
      }

      conversionsByItem[conversion.Item_Id].push({
        id: conversion.id,

        Primary_Unit:
          conversion.Primary_Unit,

        Secondary_Unit:
          conversion.Secondary_Unit,

        Conversion_Rate:
          conversion.Conversion_Rate !== null
            ? Number(conversion.Conversion_Rate)
            : null,

        created_at:
          conversion.created_at,
      });
    });

    // =========================================================
    // 9. COUNT
    // =========================================================
    //
    // IMPORTANT:
    // Search conditions now reference iu / pu / su,
    // so the COUNT query must also JOIN those tables.
    //
    // =========================================================

    const [[{ totalItems }]] =
      await connection.query(
        `
        SELECT
          COUNT(*) AS totalItems

        FROM add_item ai

        LEFT JOIN units iu
          ON ai.Item_Unit_Id = iu.id

        LEFT JOIN units pu
          ON ai.Primary_Unit_Id = pu.id

        LEFT JOIN units su
          ON ai.Secondary_Unit_Id = su.id

        ${whereSQL}
        `,
        params
      );

    // =========================================================
    // 10. GET ITEMS
    // =========================================================
    //
    // IMPORTANT:
    // We are keeping ai.* so the existing response structure
    // does not break.
    //
    // But unit display names/shorthands are now obtained
    // from units using the *_Unit_Id columns.
    //
    // =========================================================

    //    const [rows] = await connection.query(
    //   `
    //   SELECT
    //     ai.id,
    //     ai.Item_Id,
    //     ai.Item_Type,
    //     ai.Item_Name,
    //     ai.Item_HSN,

    //     -- CURRENT UNIT VALUES FROM units TABLE
    //     iu.Unit_Shorthand AS Item_Unit,
    //     ai.Item_Unit_Id,

    //     pu.Unit_Shorthand AS Primary_Unit,
    //     ai.Primary_Unit_Id,

    //     su.Unit_Shorthand AS Secondary_Unit,
    //     ai.Secondary_Unit_Id,

    //     ai.Conversion_Rate,
    //     ai.Item_Category,
    //     ai.Sale_Price,
    //     ai.Purchase_Price,
    //     ai.Stock_Quantity,
    //     ai.Opening_Quantity,
    //     ai.At_Price,
    //     ai.As_Of_Date,
    //     ai.Min_Stock,
    //     ai.Location,
    //     ai.created_at,
    //     ai.updated_at,

    //     -- OPTIONAL: names from units master
    //     iu.Unit_Name AS Item_Unit_Name,
    //     pu.Unit_Name AS Primary_Unit_Name,
    //     su.Unit_Name AS Secondary_Unit_Name,

    //     -- Keep shorthand fields if your frontend uses them
    //     iu.Unit_Shorthand AS Item_Unit_Shorthand,
    //     pu.Unit_Shorthand AS Primary_Unit_Shorthand,
    //     su.Unit_Shorthand AS Secondary_Unit_Shorthand

    //   FROM add_item ai

    //   LEFT JOIN units iu
    //     ON ai.Item_Unit_Id = iu.id

    //   LEFT JOIN units pu
    //     ON ai.Primary_Unit_Id = pu.id

    //   LEFT JOIN units su
    //     ON ai.Secondary_Unit_Id = su.id

    //   ${whereSQL}

    //   ORDER BY ai.id DESC

    //   LIMIT ?
    //   `,
    //   [...params, limit + 1]
    // );
    const [rows] = await connection.query(
      `
  SELECT 
    ai.id, 
    ai.Item_Id, 
    ai.Item_Type, 
    ai.Item_Name, 
    ai.Item_HSN, 

    -- CURRENT UNIT VALUES FROM units TABLE 
    iu.Unit_Shorthand AS Item_Unit, 
    ai.Item_Unit_Id, 

    pu.Unit_Shorthand AS Primary_Unit, 
    ai.Primary_Unit_Id, 

    su.Unit_Shorthand AS Secondary_Unit, 
    ai.Secondary_Unit_Id, 

    ai.Conversion_Rate, 
    ai.Item_Category,

    -- =====================================================
    -- ITEM CODE
    -- =====================================================

    ai.Item_Code,

    -- =====================================================
    -- PRICING
    -- =====================================================

    ai.MRP,
    ai.Discount_On_MRP_For_Sale,

    ai.Sale_Price,
    ai.Sale_Price_Type,

    ai.Discount_On_Sale_Price,
    ai.Discount_Type_On_Sale_Price,

    ai.Purchase_Price,
    ai.Purchase_Price_Type,

    -- =====================================================
    -- STOCK
    -- =====================================================

    ai.Stock_Quantity, 
    ai.Opening_Quantity, 
    ai.At_Price, 
    ai.As_Of_Date, 
    ai.Min_Stock, 
    ai.Location, 

    ai.created_at, 
    ai.updated_at, 

    -- =====================================================
    -- OPTIONAL: NAMES FROM UNITS MASTER
    -- =====================================================

    iu.Unit_Name AS Item_Unit_Name, 
    pu.Unit_Name AS Primary_Unit_Name, 
    su.Unit_Name AS Secondary_Unit_Name, 

    -- =====================================================
    -- SHORTHAND FIELDS
    -- =====================================================

    iu.Unit_Shorthand AS Item_Unit_Shorthand, 
    pu.Unit_Shorthand AS Primary_Unit_Shorthand, 
    su.Unit_Shorthand AS Secondary_Unit_Shorthand 

  FROM add_item ai 

  LEFT JOIN units iu 
    ON ai.Item_Unit_Id = iu.id 

  LEFT JOIN units pu 
    ON ai.Primary_Unit_Id = pu.id 

  LEFT JOIN units su 
    ON ai.Secondary_Unit_Id = su.id 

  ${whereSQL} 

  ORDER BY ai.id DESC 

  LIMIT ? 
  `,
      [...params, limit + 1]
    );

    // =========================================================
    // 11. PAGINATION
    // =========================================================

    const hasMore = rows.length > limit;

    const pageItems = hasMore
      ? rows.slice(0, limit)
      : rows;

    // =========================================================
    // 12. FORMAT RESPONSE
    // =========================================================

    const result = pageItems.map((item) => {

      // =======================================================
      // AVAILABLE UNITS
      // =======================================================

      const availableUnits = [];

      // -------------------------------------------------------
      // PRIMARY UNIT
      // -------------------------------------------------------

      if (item.Primary_Unit_Id) {
        availableUnits.push({
          Unit_Id:
            item.Primary_Unit_Id,

          Unit_Shorthand:
            item.Primary_Unit_Shorthand,

          Unit_Name:
            item.Primary_Unit_Name,
        });
      }

      // -------------------------------------------------------
      // SECONDARY UNIT
      // -------------------------------------------------------

      if (
        item.Secondary_Unit_Id &&
        item.Secondary_Unit_Id !==
        item.Primary_Unit_Id
      ) {
        availableUnits.push({
          Unit_Id:
            item.Secondary_Unit_Id,

          Unit_Shorthand:
            item.Secondary_Unit_Shorthand,

          Unit_Name:
            item.Secondary_Unit_Name,
        });
      }

      // =======================================================
      // UNIT USAGE / EDIT PERMISSION
      // =======================================================

      const usedUnits =
        usedUnitsByItem[item.Item_Id] ||
        new Set();

      // -------------------------------------------------------
      // PRIMARY UNIT USED?
      //
      // Compare IDs, NOT names.
      // -------------------------------------------------------

      const primaryUsed =
        item.Primary_Unit_Id
          ? usedUnits.has(
            Number(item.Primary_Unit_Id)
          )
          : false;

      // -------------------------------------------------------
      // SECONDARY UNIT USED?
      //
      // Compare IDs, NOT names.
      // -------------------------------------------------------

      const secondaryUsed =
        item.Secondary_Unit_Id
          ? usedUnits.has(
            Number(item.Secondary_Unit_Id)
          )
          : false;

      const canEditUnits = {
        Primary: !primaryUsed,
        Secondary: !secondaryUsed,
      };

      // =======================================================
      // RETURN ITEM
      // =======================================================

      return {
        ...item,

        // -----------------------------------------------------
        // Latest transaction information
        // -----------------------------------------------------

        // Purchase_Price:
        //   latestPurchasePrice[item.Item_Id] ?? 0,

        // Tax_Type:
        //   latestTaxType[item.Item_Id] ?? null,

        // Sale_Price:
        //   latestSalePrice[item.Item_Id] ?? 0,
        //     Purchase_Price:
        // item.Purchase_Price !== null &&
        // item.Purchase_Price !== undefined
        //   ? Number(item.Purchase_Price)
        //   : (latestPurchasePrice[item.Item_Id] ?? 0),
        Purchase_Price:
          item.Purchase_Price !== null
            ? Number(item.Purchase_Price)
            : 0,

        Sale_Price:
          item.Sale_Price !== null
            ? Number(item.Sale_Price)
            : 0,

        // Tax_Type:
        //   latestTaxType[item.Item_Id] ?? null,

        // Sale_Price:
        //   item.Sale_Price !== null &&
        //   item.Sale_Price !== undefined
        //     ? Number(item.Sale_Price)
        //     : (latestSalePrice[item.Item_Id] ?? 0),
        // -----------------------------------------------------
        // NEW PRICING FIELDS
        // -----------------------------------------------------

        MRP:
          item.MRP !== null
            ? Number(item.MRP)
            : null,

        Discount_On_MRP_For_Sale:
          item.Discount_On_MRP_For_Sale !== null
            ? Number(item.Discount_On_MRP_For_Sale)
            : null,

        Sale_Price_Type:
          item.Sale_Price_Type || "Without_Tax",

        Discount_On_Sale_Price:
          item.Discount_On_Sale_Price !== null
            ? Number(item.Discount_On_Sale_Price)
            : null,

        Discount_Type_On_Sale_Price:
          item.Discount_Type_On_Sale_Price || "Percentage",

        Purchase_Price_Type:
          item.Purchase_Price_Type || "Without_Tax",

        // -----------------------------------------------------
        // Current configured units
        // -----------------------------------------------------

        Available_Units:
          availableUnits,

        // -----------------------------------------------------
        // Historical conversion records
        // -----------------------------------------------------

        unitConversions:
          conversionsByItem[item.Item_Id] || [],

        // -----------------------------------------------------
        // Unit editing permission
        // -----------------------------------------------------

        Can_Edit_Units:
          canEditUnits,

        // -----------------------------------------------------
        // Numeric values
        // -----------------------------------------------------

        Conversion_Rate:
          item.Conversion_Rate !== null
            ? Number(item.Conversion_Rate)
            : null,

        Stock_Quantity:
          Number(item.Stock_Quantity || 0),

        Opening_Quantity:
          item.Opening_Quantity !== null
            ? Number(item.Opening_Quantity)
            : null,

        At_Price:
          item.At_Price !== null
            ? Number(item.At_Price)
            : null,

        Min_Stock:
          item.Min_Stock !== null
            ? Number(item.Min_Stock)
            : null,
      };
    });

    // =========================================================
    // 13. RESPONSE
    // =========================================================

    return res.status(200).json({
      success: true,

      totalItems,

      items: result,

      hasMore,

      nextCursor: hasMore
        ? pageItems[pageItems.length - 1].id
        : null,
    });

  } catch (err) {

    console.error(
      "❌ Error fetching items for ledger:",
      err
    );

    next(err);

  } finally {

    if (connection) {
      connection.release();
    }
  }
};

const getItemByCode = async (req, res, next) => {
  try {
    const { code } = req.params;

    if (!code || !code.trim()) {
      return res.status(400).json({
        success: false,
        message: "Item code is required.",
      });
    }
    const trimmedCode = code.trim();
    const [rows] = await db.query(
      `
      SELECT
        ai.id,
        ai.Item_Id,
        ai.Item_Type,
        ai.Item_Name,
        ai.Item_HSN,
        ai.Item_Category,

        ai.Item_Code,

        ai.MRP,
        ai.Discount_On_MRP_For_Sale,

        ai.Sale_Price,
        ai.Sale_Price_Type,
        ai.Discount_On_Sale_Price,
        ai.Discount_Type_On_Sale_Price,

        ai.Purchase_Price,
        ai.Purchase_Price_Type,

        ai.Primary_Unit_Id,
        pu.Unit_Shorthand AS Primary_Unit,
        pu.Unit_Name AS Primary_Unit_Name,

        ai.Secondary_Unit_Id,
        su.Unit_Shorthand AS Secondary_Unit,
        su.Unit_Name AS Secondary_Unit_Name,

        ai.Conversion_Rate,

        ai.Stock_Quantity

      FROM add_item ai

      LEFT JOIN units pu
        ON ai.Primary_Unit_Id = pu.id

      LEFT JOIN units su
        ON ai.Secondary_Unit_Id = su.id

    WHERE ai.Item_Code = ?

      LIMIT 1
      `,
      [trimmedCode]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No item found for code "${trimmedCode}".`,
      });
    }

    const item = rows[0];

    const availableUnits = [];

    if (item.Primary_Unit_Id) {
      availableUnits.push({
        Unit_Id: item.Primary_Unit_Id,
        Unit_Shorthand: item.Primary_Unit,
        Unit_Name: item.Primary_Unit_Name,
      });
    }

    if (
      item.Secondary_Unit_Id &&
      item.Secondary_Unit_Id !== item.Primary_Unit_Id
    ) {
      availableUnits.push({
        Unit_Id: item.Secondary_Unit_Id,
        Unit_Shorthand: item.Secondary_Unit,
        Unit_Name: item.Secondary_Unit_Name,
      });
    }

    return res.status(200).json({
      success: true,

      item: {
        ...item,

        Sale_Price:
          item.Sale_Price !== null
            ? Number(item.Sale_Price)
            : 0,

        Purchase_Price:
          item.Purchase_Price !== null
            ? Number(item.Purchase_Price)
            : 0,

        MRP:
          item.MRP !== null
            ? Number(item.MRP)
            : null,

        Discount_On_MRP_For_Sale:
          item.Discount_On_MRP_For_Sale !== null
            ? Number(item.Discount_On_MRP_For_Sale)
            : null,

        Discount_On_Sale_Price:
          item.Discount_On_Sale_Price !== null
            ? Number(item.Discount_On_Sale_Price)
            : null,

        Conversion_Rate:
          item.Conversion_Rate !== null
            ? Number(item.Conversion_Rate)
            : null,

        Stock_Quantity:
          Number(item.Stock_Quantity || 0),

        Available_Units: availableUnits,
      },
    });

  } catch (err) {
    console.error("❌ Error fetching item by code:", err);
    next(err);
  }
};
const getItemBills = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const { Item_Id } = req.params;

    const {
      cursor = null,
      search = "",
      date = "",
    } = req.query;

    //const limit = 10;
    const limit = Math.min(parseInt(req.query.limit, 10) || 10, 200);

    // =========================================================
    // 1. VALIDATE ITEM
    // =========================================================

    if (!Item_Id) {
      return res.status(400).json({
        success: false,
        message: "Item ID is required.",
      });
    }

    // =========================================================
    // 2. ITEM DETAILS
    // =========================================================

    // const [[item]] = await connection.query(
    //   `SELECT
    //   id,
    //      Item_Id,
    //        Item_Type,
    //      Item_Name,
    //      Item_HSN,
    //      Item_Category,
    //      Item_Unit,
    //      Primary_Unit,
    //      Secondary_Unit,
    //      Conversion_Rate,
    //      Sale_Price,
    //      Purchase_Price,
    //      Stock_Quantity
    //    FROM add_item
    //    WHERE Item_Id = ?
    //    LIMIT 1`,
    //   [Item_Id]
    // );
    const [[item]] = await connection.query(
      `
  SELECT
    i.id,
    i.Item_Id,
    i.Item_Type,
    i.Item_Name,
    i.Item_HSN,
    i.Item_Category,

    iu.Unit_Shorthand AS Item_Unit,
    cpu.Unit_Shorthand AS Primary_Unit,
    csu.Unit_Shorthand AS Secondary_Unit,

    i.Conversion_Rate,
    i.Sale_Price,
    i.Purchase_Price,
    i.Stock_Quantity

  FROM add_item i

  LEFT JOIN units iu
    ON i.Item_Unit_Id = iu.id

  LEFT JOIN units cpu
    ON i.Primary_Unit_Id = cpu.id

  LEFT JOIN units csu
    ON i.Secondary_Unit_Id = csu.id

  WHERE i.Item_Id = ?
  LIMIT 1
  `,
      [Item_Id]
    );

    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Item not found.",
      });
    }

    // =========================================================
    // 3. BUILD LEDGER FILTER
    // =========================================================

    //     const where = [`Item_Id = ?`];
    //     const params = [Item_Id];


    //     if (search?.trim()) {
    //       const like = `%${search.trim().toLowerCase()}%`;

    //       where.push(`(
    //     LOWER(COALESCE(Bill_Number, '')) LIKE ?
    //     OR LOWER(COALESCE(Party_Name, '')) LIKE ?
    //     OR LOWER(COALESCE(Txn_Type, '')) LIKE ?
    //     OR CAST(COALESCE(Quantity, 0) AS CHAR) LIKE ?
    //     OR CAST(COALESCE(Rate, 0) AS CHAR) LIKE ?
    //     OR DATE_FORMAT(Txn_Date, '%d/%m/%Y') LIKE ?
    //   )`);

    //       params.push(
    //         like,
    //         like,
    //         like,
    //         like,
    //         like,
    //         like
    //       );
    //     }


    //     if (date) {
    //       where.push(`DATE(Txn_Date) = ?`);
    //       params.push(date);
    //     }

    //     // =========================================================
    //     // 4. CURSOR
    //     // =========================================================

    //     if (cursor) {
    //       try {
    //         const decoded = JSON.parse(
    //           Buffer.from(cursor, "base64").toString("utf8")
    //         );

    //         if (!decoded.date || !decoded.id) {
    //           return res.status(400).json({ success: false, message: "Invalid cursor." });
    //         }

    //         where.push(`(
    //           Txn_Date < ?
    //           OR (Txn_Date = ? AND id < ?)
    //         )`);
    //         params.push(decoded.date, decoded.date, Number(decoded.id));

    //       } catch {
    //         return res.status(400).json({ success: false, message: "Invalid cursor." });
    //       }
    //     }

    //     // =========================================================
    //     // 5. FETCH LIMIT + 1
    //     // =========================================================

    //     // const [rows] = await connection.query(
    //     //   `SELECT
    //     //      id          AS Ledger_Id,
    //     //      Item_Id,
    //     //      Txn_Type,
    //     //      Direction,
    //     //      Source_Id,
    //     //      Bill_Id,
    //     //      Bill_Number,
    //     //      Party_Name,
    //     //      Quantity,
    //     //      Selected_Unit,
    //     //      Rate,
    //     //      Running_Stock,
    //     //      Txn_Date
    //     //    FROM item_ledger
    //     //    WHERE ${where.join(" AND ")}
    //     //    ORDER BY Txn_Date DESC, id DESC
    //     //    LIMIT ?`,
    //     //   [...params, limit + 1]
    //     // );
    //     const [rows] = await connection.query(
    //   `
    //   SELECT
    //     il.id AS Ledger_Id,
    //     il.Item_Id,
    //     il.Txn_Type,
    //     il.Direction,
    //     il.Source_Id,
    //     il.Bill_Id,
    //     il.Bill_Number,
    //     il.Party_Name,
    //     il.Quantity,
    //     u.Unit_Shorthand AS Selected_Unit,
    //     il.Rate,
    //     il.Running_Stock,
    //     il.Txn_Date
    //   FROM item_ledger il

    //   LEFT JOIN units u
    //     ON u.id = il.Selected_Unit_Id

    //   WHERE ${where.map(condition => `il.${condition}`).join(" AND ")}
    //   ORDER BY il.Txn_Date DESC, il.id DESC
    //   LIMIT ?
    //   `,
    //   [...params, limit + 1]
    // );

    const where = [`il.Item_Id = ?`];
    const params = [Item_Id];

    if (search?.trim()) {
      const like = `%${search.trim().toLowerCase()}%`;

      where.push(`(
    LOWER(COALESCE(il.Bill_Number, '')) LIKE ?
    OR LOWER(COALESCE(il.Party_Name, '')) LIKE ?
    OR LOWER(COALESCE(il.Txn_Type, '')) LIKE ?
    OR CAST(COALESCE(il.Quantity, 0) AS CHAR) LIKE ?
    OR CAST(COALESCE(il.Rate, 0) AS CHAR) LIKE ?
    OR DATE_FORMAT(il.Txn_Date, '%d/%m/%Y') LIKE ?
  )`);

      params.push(
        like,
        like,
        like,
        like,
        like,
        like
      );
    }

    if (date) {
      where.push(`DATE(il.Txn_Date) = ?`);
      params.push(date);
    }

    if (cursor) {
      try {
        const decoded = JSON.parse(
          Buffer.from(cursor, "base64").toString("utf8")
        );

        if (!decoded.date || !decoded.id) {
          return res.status(400).json({
            success: false,
            message: "Invalid cursor."
          });
        }

        where.push(`(
      il.Txn_Date < ?
      OR (il.Txn_Date = ? AND il.id < ?)
    )`);

        params.push(
          decoded.date,
          decoded.date,
          Number(decoded.id)
        );

      } catch {
        return res.status(400).json({
          success: false,
          message: "Invalid cursor."
        });
      }
    }

    const [rows] = await connection.query(
      `
  SELECT
    il.id AS Ledger_Id,
    il.Item_Id,
    il.Txn_Type,
    il.Direction,
    il.Source_Id,
    il.Bill_Id,
    il.Bill_Number,
    il.Party_Name,
    il.Quantity,
    il.Free_Quantity,

    u.Unit_Shorthand AS Selected_Unit,

    il.Rate,
    il.Running_Stock,
    il.Txn_Date,
     DATE_FORMAT(il.Txn_Date, '%Y-%m-%d %H:%i:%s') AS Txn_Date_Raw

  FROM item_ledger il

  LEFT JOIN units u
    ON u.id = il.Selected_Unit_Id

  WHERE ${where.join(" AND ")}

  ORDER BY il.Txn_Date DESC, il.id DESC

  LIMIT ?
  `,
      [...params, limit + 1]
    );

    const hasMore = rows.length > limit;
    const transactions = hasMore ? rows.slice(0, limit) : rows;
    // =========================================================
    // 5A. GET STOCK ADJUSTMENT DETAILS
    // =========================================================

    const adjustmentSourceIds = transactions
      .filter(
        (r) =>
          (
            r.Txn_Type === "Add_Adjustment" ||
            r.Txn_Type === "Reduce_Adjustment"
          ) &&
          r.Source_Id
      )
      .map((r) => r.Source_Id);

    const adjustmentMap = new Map();

    if (adjustmentSourceIds.length > 0) {
      const [adjustmentRows] = await connection.query(
        `
    SELECT
      id,
      Item_Id,
      At_Price,
      Details,
        Selected_Unit,
      Adjustment_Date
    FROM item_stock_adjustments
    WHERE id IN (?)
      AND Item_Id = ?
    `,
        [
          adjustmentSourceIds,
          Item_Id,
        ]
      );

      adjustmentRows.forEach((row) => {
        adjustmentMap.set(row.id, row);
      });
    }
    // =========================================================
    // 6. RESOLVE RETURN Bill_Id
    //
    // For Purchase_Return and Sale_Return:
    //   Bill_Id is NULL in item_ledger.
    //   Source_Id → purchase_return_items.id
    //             → sale_return_items.id
    //
    //   Join through item table to get the return header id.
    //   Return header id is what frontend uses to navigate
    //   to /purchase/return/edit/:id or /sale/return/edit/:id
    //
    // For Purchase and Sale:
    //   Bill_Id already holds e.g. "PUR001" / "SAL001" — no join needed.
    // =========================================================

    const purchaseReturnSourceIds = transactions
      .filter((r) => r.Txn_Type === "Purchase_Return" && r.Source_Id)
      .map((r) => r.Source_Id);

    const saleReturnSourceIds = transactions
      .filter((r) => r.Txn_Type === "Sale_Return" && r.Source_Id)
      .map((r) => r.Source_Id);

    /* Maps: source_id → return header numeric id */
    const purchaseReturnMap = new Map();
    const saleReturnMap = new Map();

    if (purchaseReturnSourceIds.length > 0) {
      const [prRows] = await connection.query(
        `SELECT
           pri.id                 AS source_id,
           pri.Purchase_Return_Id AS return_header_id
         FROM purchase_return_items pri
         WHERE pri.id IN (?)`,
        [purchaseReturnSourceIds]
      );
      prRows.forEach((r) =>
        purchaseReturnMap.set(r.source_id, r.return_header_id)
      );
    }

    if (saleReturnSourceIds.length > 0) {
      const [srRows] = await connection.query(
        `SELECT
           sri.id             AS source_id,
           sri.Sale_Return_Id AS return_header_id
         FROM sale_return_items sri
         WHERE sri.id IN (?)`,
        [saleReturnSourceIds]
      );
      srRows.forEach((r) =>
        saleReturnMap.set(r.source_id, r.return_header_id)
      );
    }

    // =========================================================
    // 7. NEXT CURSOR
    // =========================================================

    let nextCursor = null;

    // if (hasMore && transactions.length > 0) {
    //   const last = transactions[transactions.length - 1];
    //   nextCursor = Buffer.from(
    //     JSON.stringify({ date: last.Txn_Date, id: last.Ledger_Id })
    //   ).toString("base64");
    // }
    if (hasMore && transactions.length > 0) {
  const last = transactions[transactions.length - 1];
  nextCursor = Buffer.from(
    JSON.stringify({ date: last.Txn_Date_Raw, id: last.Ledger_Id })
  ).toString("base64");
}

    // =========================================================
    // 8. RESPONSE
    //
    // Resolved_Bill_Id rules:
    //
    //   Purchase      → Bill_Id  (e.g. "PUR001")
    //   Sale          → Bill_Id  (e.g. "SAL001")
    //   Purchase_Return → purchase_return.id  (numeric, e.g. 3)
    //   Sale_Return     → sale_return.id      (numeric, e.g. 7)
    //
    // Frontend uses Resolved_Bill_Id to build its nav link.
    // =========================================================
    const isService = item.Item_Type === "Service";

    const filteredTransactions = isService
      ? transactions.filter(
        (row) =>
          ![
            "Opening_Stock",
            "Add_Adjustment",
            "Reduce_Adjustment",
          ].includes(row.Txn_Type)
      )
      : transactions;

    return res.status(200).json({
      success: true,

      item: {
        ...item,

        Conversion_Rate:
          item.Conversion_Rate !== null
            ? Number(item.Conversion_Rate)
            : null,

        ...(isService
          ? {
            Purchase_Price: null,
            Stock_Quantity: null,
            Opening_Quantity: null,
            At_Price: null,
            Min_Stock: null,
            Location: null,
            As_Of_Date: null,
          }
          : {
            Purchase_Price:
              item.Purchase_Price !== null ? Number(item.Purchase_Price) : null,

            Stock_Quantity: Number(item.Stock_Quantity || 0),
          }),
      },

      transactions: filteredTransactions.map((row) => {
        let resolvedBillId = row.Bill_Id;

        if (
          row.Txn_Type === "Purchase_Return" &&
          row.Source_Id
        ) {
          resolvedBillId =
            purchaseReturnMap.get(row.Source_Id) ??
            null;

        } else if (
          row.Txn_Type === "Sale_Return" &&
          row.Source_Id
        ) {
          resolvedBillId =
            saleReturnMap.get(row.Source_Id) ??
            null;
        }

        const adjustment =
          row.Txn_Type === "Add_Adjustment" ||
            row.Txn_Type === "Reduce_Adjustment"
            ? adjustmentMap.get(row.Source_Id)
            : null;

        return {
          Ledger_Id: row.Ledger_Id,
          Item_Id: row.Item_Id,
          Txn_Type: row.Txn_Type,
          Direction: row.Direction,
          Source_Id: row.Source_Id,
          Selected_Unit:
            adjustment?.Selected_Unit ??
            row.Selected_Unit ??
            null,
          //Selected_Unit: row.Selected_Unit,

          Document_Id: resolvedBillId,

          Number: row.Bill_Number,
          Party_Name: row.Party_Name,

          Quantity: Number(row.Quantity || 0),
          
Free_Quantity:Number(row.Free_Quantity) > 0? Number(row.Free_Quantity): null,

          Rate:
            row.Rate !== null
              ? Number(row.Rate)
              : null,

          At_Price:
            adjustment?.At_Price !== null &&
              adjustment?.At_Price !== undefined
              ? Number(adjustment.At_Price)
              : null,

          Details:
            adjustment?.Details ?? null,

          Adjustment_Date:
            formatDateOnly(
              adjustment?.Adjustment_Date
            ) ?? null,

          Running_Stock:
            isService
              ? null
              : Number(row.Running_Stock || 0),

          Txn_Date: row.Txn_Date,
        };
      }),

      nextCursor,
      hasMore,
    });
    // const isService = item.Item_Type === "Service";
    //     return res.status(200).json({
    //       success: true,

    //       // item: {
    //       //   ...item,
    //       //   Conversion_Rate: item.Conversion_Rate !== null ? Number(item.Conversion_Rate) : null,
    //       //   Stock_Quantity: Number(item.Stock_Quantity || 0),
    //       // },
    //         item: {
    //     ...item,

    //     Conversion_Rate:
    //       item.Conversion_Rate !== null? Number(item.Conversion_Rate): null,

    //     ...(isService
    //       ? {
    //           Purchase_Price: null,
    //           Stock_Quantity: null,
    //           Opening_Quantity: null,
    //           At_Price: null,
    //           Min_Stock: null,
    //           Location: null,
    //           As_Of_Date: null,
    //         }
    //       : {
    //           Purchase_Price:item.Purchase_Price !== null? Number(item.Purchase_Price): null,

    //           Stock_Quantity:Number(item.Stock_Quantity || 0),
    //         }),
    //   },

    //       transactions: transactions.map((row) => {
    //         let resolvedBillId = row.Bill_Id; // Purchase / Sale — already correct

    //         if (row.Txn_Type === "Purchase_Return" && row.Source_Id) {
    //           resolvedBillId = purchaseReturnMap.get(row.Source_Id) ?? null;
    //         } else if (row.Txn_Type === "Sale_Return" && row.Source_Id) {
    //           resolvedBillId = saleReturnMap.get(row.Source_Id) ?? null;
    //         }

    //         const adjustment =
    //           row.Txn_Type === "Add_Adjustment" ||
    //             row.Txn_Type === "Reduce_Adjustment"
    //             ? adjustmentMap.get(row.Source_Id)
    //             : null;


    //         return {
    //           Ledger_Id: row.Ledger_Id,
    //           Item_Id: row.Item_Id,
    //           Txn_Type: row.Txn_Type,
    //           Direction: row.Direction,
    //           Source_Id: row.Source_Id,
    //           Selected_Unit: row.Selected_Unit,
    //           //Bill_Id: row.Bill_Id,
    //           Document_Id: resolvedBillId, // SAL001 / PUR001 / numeric return header id

    //           Number: row.Bill_Number,     // INV-001 / AEPL-001 / SR-001 / PR-001
    //           Party_Name: row.Party_Name,
    //           Quantity: Number(row.Quantity || 0),
    //           Rate: row.Rate !== null ? Number(row.Rate) : null,
    //           // ✅ ONLY populated for adjustments
    //           At_Price:
    //             adjustment?.At_Price !== null &&
    //               adjustment?.At_Price !== undefined
    //               ? Number(adjustment.At_Price)
    //               : null,

    //           // ✅ ONLY populated for adjustments
    //           Details: adjustment?.Details ?? null,

    //           // ✅ ONLY populated for adjustments
    //           Adjustment_Date: formatDateOnly(adjustment?.Adjustment_Date) ?? null,
    //           Running_Stock: Number(row.Running_Stock || 0),
    //           Txn_Date: row.Txn_Date,
    //         };
    //       }),

    //       nextCursor,
    //       hasMore,
    //     });

  } catch (err) {
    console.error("❌ Error fetching item bills:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};

{/* add category */ }

const addCategory = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    const { Item_Category } = req.body;

    if (!Item_Category?.trim()) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: "Item Category is required",
      });
    }

    // Normalize category name
    const normalizedCategory = Item_Category.trim().replace(/\s+/g, " ");

    // Check duplicate (case-insensitive)
    const [existing] = await connection.query(
      `SELECT Category_Id
       FROM add_category
       WHERE LOWER(TRIM(Item_Category)) = ?`,
      [normalizedCategory.toLowerCase()]
    );

    if (existing.length > 0) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: "Category already exists.",
      });
    }

    // Generate Category_Id
    let categoryId = "CAT001";

    const [last] = await connection.query(
      `SELECT Category_Id
       FROM add_category
       ORDER BY id DESC
       LIMIT 1`
    );

    if (last.length > 0) {
      const lastId = last[0].Category_Id; // CAT001
      const nextNumber = parseInt(lastId.replace("CAT", ""), 10) + 1;

      categoryId = "CAT" + nextNumber.toString().padStart(3, "0");
    }

    // Insert category
    const [result] = await connection.execute(
      `INSERT INTO add_category
        (
          Category_Id,
          Item_Category,
          created_at,
          updated_at
        )
       VALUES
        (?, ?, NOW(), NOW())`,
      [categoryId, normalizedCategory]
    );

    await connection.commit();

    return res.status(201).json({
      success: true,
      message: "Category added successfully.",
      id: result.insertId,
      Category_Id: categoryId,
      Item_Category: normalizedCategory,
    });
  } catch (err) {
    if (connection) await connection.rollback();
    console.error("❌ Error adding category:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};
const editCategory = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    const { categoryId } = req.params;
    const { Item_Category } = req.body;

    if (!categoryId) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: "Category ID is required.",
      });
    }

    if (!Item_Category?.trim()) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: "Item Category is required.",
      });
    }

    const normalizedCategory = Item_Category.trim().replace(/\s+/g, " ");

    // Get existing category
    const [[existingCategory]] = await connection.query(
      `
      SELECT Category_Id, Item_Category
      FROM add_category
      WHERE Category_Id = ?
      LIMIT 1
      `,
      [categoryId]
    );

    if (!existingCategory) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: "Category not found.",
      });
    }

    const oldCategoryName = existingCategory.Item_Category;

    // Duplicate check
    const [duplicate] = await connection.query(
      `
      SELECT Category_Id
      FROM add_category
      WHERE LOWER(TRIM(Item_Category)) = ?
      AND Category_Id <> ?
      `,
      [normalizedCategory.toLowerCase(), categoryId]
    );

    if (duplicate.length > 0) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: "Category already exists.",
      });
    }

    // Update category master
    await connection.query(
      `
      UPDATE add_category
      SET
        Item_Category = ?,
        updated_at = NOW()
      WHERE Category_Id = ?
      `,
      [normalizedCategory, categoryId]
    );

    // Update all items using old category name
    await connection.query(
      `
      UPDATE add_item
      SET Item_Category = ?
      WHERE TRIM(Item_Category) = TRIM(?)
      `,
      [normalizedCategory, oldCategoryName]
    );

    await connection.commit();

    return res.status(200).json({
      success: true,
      message: "Category updated successfully.",
      Category_Id: categoryId,
      Item_Category: normalizedCategory,
    });
  } catch (err) {
    if (connection) await connection.rollback();
    console.error("❌ Error updating category:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};
const getAllCategories = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();
    const [rows] = await db.query("SELECT * FROM add_category  ORDER BY created_at DESC");
    return res.status(200).json(rows);
  } catch (err) {
    if (connection) connection.release();
    console.error("❌ Error getting all categories:", err);
    next(err);
    // return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    if (connection) connection.release();
  }
}
const getAllCategoriesCursor = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const cursor = req.query.cursor
      ? Number(req.query.cursor)
      : null;

    const search = req.query.search
      ? req.query.search.trim()
      : "";

    const limit = parseInt(req.query.limit, 10) || 10;

    const where = [];
    const params = [];

    // =========================================================
    // SEARCH FILTER
    // =========================================================

    if (search) {
      where.push(`Item_Category LIKE ?`);
      params.push(`%${search}%`);
    }

    // =========================================================
    // CURSOR FILTER
    // =========================================================

    if (cursor) {
      where.push(`id < ?`);
      params.push(cursor);
    }

    const whereSQL =
      where.length > 0
        ? `WHERE ${where.join(" AND ")}`
        : "";

    // =========================================================
    // TOTAL CATEGORY COUNT
    // =========================================================

    const [[countResult]] = await connection.query(`
      SELECT COUNT(*) AS totalCategories
      FROM add_category
    `);

    // +1 because we show
    // "Items Not In Any Category"
    const totalCategories = Number(countResult.totalCategories || 0);

    // =========================================================
    // FETCH CATEGORIES
    // =========================================================

    const [rows] = await connection.query(
      `
      SELECT *
      FROM add_category
      ${whereSQL}
      ORDER BY id DESC
      LIMIT ?
      `,
      [...params, limit + 1]
    );

    // =========================================================
    // PAGINATION
    // =========================================================

    const hasMore = rows.length > limit;

    const pageRows = hasMore
      ? rows.slice(0, limit)
      : rows;

    const nextCursor = hasMore
      ? pageRows[pageRows.length - 1].id
      : null;

    // =========================================================
    // ADD SPECIAL CATEGORY
    // =========================================================

    let categories = [...pageRows];

    if (!cursor && !search) {
      categories.unshift({
        Category_Id: "uncategorized",
        Item_Category: "Items Not In Any Category",
      });
    }

    // =========================================================
    // RESPONSE
    // =========================================================

    return res.status(200).json({
      success: true,
      categories,
      totalCategories,
      hasMore,
      nextCursor,
    });
  } catch (err) {
    console.error(
      "❌ Error getting categories (cursor):",
      err
    );
    next(err);
  } finally {
    if (connection) {
      connection.release();
    }
  }
};
const getItemsNotInCategory = async (req, res, next) => {
  let connection;

  try {
    const { Category_Id } = req.params;


    connection = await db.getConnection();
    const [[category]] = await connection.query(
      `
  SELECT Item_Category
  FROM add_category
  WHERE Category_Id = ?
  `,
      [Category_Id]
    );

    if (!category) {
      return res.status(404).json({
        success: false,
        message: "Category not found",
      });
    }

    const [items] = await connection.query(
      `
  SELECT
    Item_Id,
    Item_Name,
    Item_Category
  FROM add_item
  WHERE Item_Category IS NULL
     OR TRIM(Item_Category) = ''
     OR LOWER(TRIM(Item_Category)) <> LOWER(TRIM(?))
  ORDER BY Item_Name ASC
  `,
      [category.Item_Category]
    );

    return res.status(200).json({
      success: true,
      data: items,
    });
  } catch (err) {
    console.error(err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};
const moveItemsToCategory = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    const { Item_Category, itemIds } = req.body;

    if (!Item_Category) {
      return res.status(400).json({
        success: false,
        message: "Item Category is required",
      });
    }

    if (!Array.isArray(itemIds) || itemIds.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No items selected",
      });
    }

    const placeholders = itemIds.map(() => "?").join(",");

    const [result] = await connection.query(
      `
      UPDATE add_item
      SET Item_Category = ?,
          updated_at = NOW()
      WHERE Item_Id IN (${placeholders})
      `,
      [Item_Category, ...itemIds]
    );

    await connection.commit();

    return res.status(200).json({
      success: true,
      message: `${result.affectedRows} item(s) moved successfully`,
    });
  } catch (err) {
    if (connection) await connection.rollback();
    next(err);
  } finally {
    if (connection) connection.release();
  }
};
/* ═══════════════════════════════════════
   ITEMS BY CATEGORY (cursor paginated, mirrors getItemBills)
   categoryId = "all" → every item, regardless of category
═══════════════════════════════════════ */
//OLD

const getItemsByCategory = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const { categoryId } = req.params;
    const { cursor = null, search = "" } = req.query;

    const limit = 10;

    if (!categoryId) {
      return res.status(400).json({
        success: false,
        message: "Category ID is required.",
      });
    }

    const where = [];
    const params = [];

    // For total count (without cursor)
    const countWhere = [];
    const countParams = [];

    let categoryResponse;

    // =========================================================
    // ITEMS NOT IN ANY CATEGORY
    // =========================================================

    if (categoryId === "uncategorized") {
      const uncategorizedCondition = `
        (
          Item_Category IS NULL
          OR TRIM(Item_Category) = ''
        )
      `;

      where.push(uncategorizedCondition);
      countWhere.push(uncategorizedCondition);

      categoryResponse = {
        Category_Id: "uncategorized",
        Item_Category: "Items Not In Any Category",
      };
    }

    // =========================================================
    // NORMAL CATEGORY
    // =========================================================

    else {
      const [[category]] = await connection.query(
        `
        SELECT
          Category_Id,
          Item_Category
        FROM add_category
        WHERE Category_Id = ?
        LIMIT 1
        `,
        [categoryId]
      );

      if (!category) {
        return res.status(404).json({
          success: false,
          message: "Category not found.",
        });
      }

      where.push(`TRIM(Item_Category) = TRIM(?)`);
      params.push(category.Item_Category);

      countWhere.push(`TRIM(Item_Category) = TRIM(?)`);
      countParams.push(category.Item_Category);

      categoryResponse = {
        Category_Id: category.Category_Id,
        Item_Category: category.Item_Category,
      };
    }

    // =========================================================
    // SEARCH
    // =========================================================

    if (search?.trim()) {
      const like = `%${search.trim()}%`;

      const searchCondition = `
        (
          LOWER(Item_Name) LIKE LOWER(?)
          OR CAST(Stock_Quantity AS CHAR) LIKE ?
        )
      `;

      where.push(searchCondition);
      params.push(like, like);

      countWhere.push(searchCondition);
      countParams.push(like, like);
    }

    // =========================================================
    // CURSOR PAGINATION
    // =========================================================

    if (cursor) {
      try {
        const decoded = JSON.parse(
          Buffer.from(cursor, "base64").toString("utf8")
        );

        if (!decoded.id) {
          return res.status(400).json({
            success: false,
            message: "Invalid cursor.",
          });
        }

        where.push(`id < ?`);
        params.push(Number(decoded.id));
      } catch (error) {
        return res.status(400).json({
          success: false,
          message: "Invalid cursor.",
        });
      }
    }

    const whereSQL =
      where.length > 0
        ? `WHERE ${where.join(" AND ")}`
        : "";

    const countWhereSQL =
      countWhere.length > 0
        ? `WHERE ${countWhere.join(" AND ")}`
        : "";

    // =========================================================
    // TOTAL ITEMS COUNT (NO CURSOR)
    // =========================================================

    const [countRows] = await connection.query(
      `
      SELECT COUNT(*) AS totalItems
      FROM add_item
      ${countWhereSQL}
      `,
      countParams
    );

    const totalItems = Number(countRows[0].totalItems || 0);

    // =========================================================
    // FETCH ITEMS
    // =========================================================

    const [rows] = await connection.query(
      `
      SELECT
        id,
        Item_Id,
        Item_Name,
        Item_Category,
        Stock_Quantity,
        At_Price,
        Item_Unit,
        Primary_Unit,
        Secondary_Unit,
        (Stock_Quantity * COALESCE(At_Price, 0)) AS Stock_Value
      FROM add_item
      ${whereSQL}
      ORDER BY id DESC
      LIMIT ?
      `,
      [...params, limit + 1]
    );

    // =========================================================
    // PAGINATION
    // =========================================================

    const hasMore = rows.length > limit;

    const pageRows = hasMore
      ? rows.slice(0, limit)
      : rows;

    let nextCursor = null;

    if (hasMore && pageRows.length > 0) {
      nextCursor = Buffer.from(
        JSON.stringify({
          id: pageRows[pageRows.length - 1].id,
        })
      ).toString("base64");
    }

    // =========================================================
    // RESPONSE
    // =========================================================

    return res.status(200).json({
      success: true,

      category: categoryResponse,

      totalItems,

      items: pageRows.map((row) => ({
        Item_Id: row.Item_Id,
        Item_Name: row.Item_Name,
        Item_Category: row.Item_Category,
        Stock_Quantity: Number(row.Stock_Quantity || 0),
        Unit: row.Primary_Unit || row.Item_Unit || null,
        Stock_Value: Number(row.Stock_Value || 0),
      })),

      hasMore,
      nextCursor,
    });
  } catch (err) {
    console.error("❌ Error fetching items by category:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};

const eachItemSalesPurchaseDetails = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const { Item_Id } = req.params;

    const page = parseInt(req.query.page, 10) || 1;
    const limit = 10;
    const offset = (page - 1) * limit;

    // Fetch Item
    const [items] = await connection.query(
      `SELECT Item_Id, Item_Name 
       FROM add_item 
       WHERE Item_Id = ?`,
      [Item_Id]
    );

    if (!items.length) {
      return res.status(404).json({
        success: false,
        message: "Item not found",
      });
    }

    /* ---------------------------------------------------
       1️⃣ Get total record count
    --------------------------------------------------- */

    const [[countResult]] = await connection.query(
      `
      SELECT COUNT(*) AS totalRecords
      FROM (
        SELECT Purchase_Id AS id
        FROM add_purchase_items
        WHERE Item_Id = ?

        UNION ALL

        SELECT Sale_Id AS id
        FROM add_sale_items
        WHERE Item_Id = ?
      ) t
      `,
      [Item_Id, Item_Id]
    );

    const totalRecords = countResult.totalRecords;
    const totalPages = Math.ceil(totalRecords / limit);

    /* ---------------------------------------------------
       2️⃣ Fetch combined transactions
    --------------------------------------------------- */

    const [transactions] = await connection.query(
      `
      SELECT * FROM (
          SELECT 
              'Purchase' AS Type,
              pi.Purchase_Id AS Bill_Id,
              pi.Item_Id,
              pi.Quantity,
              pi.Amount,
              pi.created_at
          FROM add_purchase_items pi
          WHERE pi.Item_Id = ?

          UNION ALL

          SELECT 
              'Sale' AS Type,
              si.Sale_Id AS Bill_Id,
              si.Item_Id,
              si.Quantity,
              si.Amount,
              si.created_at
          FROM add_sale_items si
          WHERE si.Item_Id = ?
      ) t
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
      `,
      [Item_Id, Item_Id, limit, offset]
    );

    /* ---------------------------------------------------
       3️⃣ Extract Bill IDs
    --------------------------------------------------- */

    const purchaseIds = transactions
      .filter((t) => t.Type === "Purchase")
      .map((t) => t.Bill_Id);

    const saleIds = transactions
      .filter((t) => t.Type === "Sale")
      .map((t) => t.Bill_Id);

    /* ---------------------------------------------------
       4️⃣ Fetch Purchase Bills
    --------------------------------------------------- */

    const [purchases] = purchaseIds.length
      ? await connection.query(
        `
          SELECT ap.*, p.Party_Name, p.Phone_Number, p.GSTIN
          FROM add_purchase ap
          LEFT JOIN add_party p ON ap.Party_Id = p.Party_Id
          WHERE ap.Purchase_Id IN (?)
          `,
        [purchaseIds]
      )
      : [[]];

    /* ---------------------------------------------------
       5️⃣ Fetch Sale Bills
    --------------------------------------------------- */

    const [sales] = saleIds.length
      ? await connection.query(
        `
          SELECT s.*, p.Party_Name, p.Phone_Number, p.GSTIN
          FROM add_sale s
          LEFT JOIN add_party p ON s.Party_Id = p.Party_Id
          WHERE s.Sale_Id IN (?)
          `,
        [saleIds]
      )
      : [[]];

    /* ---------------------------------------------------
       6️⃣ Fetch Items for Bills
    --------------------------------------------------- */

    const [purchaseItems] = purchaseIds.length
      ? await connection.query(
        `
          SELECT pi.*, i.Item_Name, i.Item_HSN, i.Item_Category, i.Item_Unit
          FROM add_purchase_items pi
          LEFT JOIN add_item i ON pi.Item_Id = i.Item_Id
          WHERE pi.Purchase_Id IN (?)
          `,
        [purchaseIds]
      )
      : [[]];

    const [saleItems] = saleIds.length
      ? await connection.query(
        `
          SELECT si.*, i.Item_Name, i.Item_HSN, i.Item_Category, i.Item_Unit
          FROM add_sale_items si
          LEFT JOIN add_item i ON si.Item_Id = i.Item_Id
          WHERE si.Sale_Id IN (?)
          `,
        [saleIds]
      )
      : [[]];

    /* ---------------------------------------------------
       7️⃣ Build Final Objects
    --------------------------------------------------- */
    const purchaseMap = new Map();

    purchaseItems.forEach(it => {
      if (!purchaseMap.has(it.Purchase_Id)) {
        purchaseMap.set(it.Purchase_Id, []);
      }
      purchaseMap.get(it.Purchase_Id).push(it);
    });
    const purchaseBills = purchases.map((bill) => ({
      Type: "Purchase",
      ...bill,
      Party_Name: bill.Party_Name,
      Party_GST: bill.GSTIN,
      Party_Phone: bill.Phone_Number,
      items: purchaseMap.get(bill.Purchase_Id) || []
      // items: purchaseItems.filter(
      //   (it) => it.Purchase_Id === bill.Purchase_Id
      // ),
    }));

    const saleMap = new Map()
    saleItems.forEach(it => {
      if (!saleMap.has(it.Sale_Id)) {
        saleMap.set(it.Sale_Id, []);
      }
      saleMap.get(it.Sale_Id).push(it);
    });

    const saleBills = sales.map((bill) => ({
      Type: "Sale",
      ...bill,
      Party_Name: bill.Party_Name,
      Party_GST: bill.GSTIN,
      Party_Phone: bill.Phone_Number,
      items: saleMap.get(bill.Sale_Id) || [],
    }));

    /* ---------------------------------------------------
       8️⃣ Final Response
    --------------------------------------------------- */

    return res.status(200).json({
      success: true,
      Item_Id,
      Item_Name: items[0].Item_Name,
      page,
      limit,
      totalRecords,
      totalPages,
      purchases: purchaseBills,
      sales: saleBills,
      transactions,
    });

  } catch (err) {
    console.error("❌ Error:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};

const addStockAdjustment = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    await connection.beginTransaction();

    const {
      Item_Id,
      Adjustment_Type,   // "Add" | "Reduce"
      Quantity,
      Selected_Unit,
      At_Price,
      Details,
      Adjustment_Date,
    } = req.body;

    // =========================================================
    // 1. VALIDATION
    // =========================================================

    if (
      !Item_Id ||
      !Adjustment_Type ||
      Quantity === undefined ||
      Quantity === null ||
      Quantity === ""
    ) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Invalid adjustment data.",
      });
    }

    if (
      Adjustment_Type !== "Add" &&
      Adjustment_Type !== "Reduce"
    ) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Invalid adjustment type.",
      });
    }

    const qty = Number(Quantity);

    if (!Number.isFinite(qty) || qty <= 0) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Quantity must be greater than 0.",
      });
    }

    // =========================================================
    // 2. GET ITEM
    // =========================================================

    const [[item]] = await connection.query(
      `
      SELECT
        Item_Id,
        Item_Name,
        Primary_Unit,
        Secondary_Unit,
        Conversion_Rate,
        Stock_Quantity
      FROM add_item
      WHERE Item_Id = ?
      LIMIT 1
      `,
      [Item_Id]
    );

    if (!item) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "Item not found.",
      });
    }

    // =========================================================
    // 3. CONVERT QUANTITY TO PRIMARY / BASE UNIT
    //
    // Example:
    //
    // Primary   = Kg
    // Secondary = Gm
    // Rate      = 1000
    //
    // User enters:
    // 500 Gm
    //
    // Base_Qty = 500 / 1000 = 0.5 Kg
    // =========================================================

    let baseQty = qty;

    if (
      item.Primary_Unit &&
      item.Secondary_Unit &&
      Selected_Unit === item.Secondary_Unit
    ) {
      const rate = Number(item.Conversion_Rate) || 0;

      if (rate <= 0) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message:
            `Missing conversion rate for ${item.Primary_Unit} → ${item.Secondary_Unit}.`,
        });
      }

      baseQty = qty / rate;
    }

    // =========================================================
    // 4. DETERMINE LEDGER DIRECTION
    //
    // Add    = IN
    // Reduce = OUT
    // =========================================================

    const direction =
      Adjustment_Type === "Add"
        ? "In"
        : "Out";

    // Signed quantity used ONLY for add_item stock.
    //
    // Add    => +
    // Reduce => -
    const signedBaseQty =
      Adjustment_Type === "Add"
        ? baseQty
        : -baseQty;

    // =========================================================
    // 5. INSERT STOCK ADJUSTMENT HEADER
    //
    // item_stock_adjustments.id becomes the
    // item_ledger.Source_Id
    // =========================================================

    const [insertRes] = await connection.execute(
      `
      INSERT INTO item_stock_adjustments
      (
        Item_Id,
        Adjustment_Type,
        Quantity,
        Selected_Unit,
        Base_Qty,
        At_Price,
        Details,
        Adjustment_Date,
        created_at,
        updated_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        Item_Id,
        Adjustment_Type,
        qty,
        Selected_Unit || null,
        baseQty,
        At_Price || null,
        Details || null,
        Adjustment_Date,
      ]
    );

    const adjustmentId = insertRes.insertId;

    // =========================================================
    // 6. UPDATE ITEM MASTER STOCK
    //
    // NO NEGATIVE STOCK RESTRICTION.
    //
    // Reduce can make Stock_Quantity negative.
    // =========================================================

    await connection.query(
      `
      UPDATE add_item
      SET
        Stock_Quantity = Stock_Quantity + ?,
        updated_at = NOW()
      WHERE Item_Id = ?
      `,
      [
        signedBaseQty,
        Item_Id,
      ]
    );

    // =========================================================
    // 7. INSERT ITEM LEDGER
    //
    // IMPORTANT:
    //
    // Quantity  = user entered quantity
    // Base_Qty  = normalized primary-unit quantity
    //
    // Example:
    //
    // User enters 500 Gm
    //
    // Quantity      = 500
    // Selected_Unit = Gm
    // Base_Qty      = 0.5
    //
    // Direction:
    // Add    = In
    // Reduce = Out
    // =========================================================

    await recordItemLedger({
      connection,

      itemId: Item_Id,

      txnType:
        Adjustment_Type === "Reduce"
          ? "Reduce_Adjustment"
          : "Add_Adjustment",

      // item_stock_adjustments.id
      referenceId: adjustmentId,

      // You can keep these null because this isn't
      // a Sale/Purchase document.
      billId: null,
      billNumber: null,

      partyName: null,

      // Original user-entered quantity
      quantity: qty,

      // Unit selected by user
      selectedUnit: Selected_Unit || null,

      // Normalized quantity in primary unit
      baseQty: baseQty,

      rate:
        At_Price !== undefined &&
          At_Price !== null &&
          At_Price !== ""
          ? Number(At_Price)
          : null,

      txnDate: Adjustment_Date,

      // IMPORTANT:
      // Add    => In
      // Reduce => Out
      direction,
    });

    // =========================================================
    // 8. COMMIT
    // =========================================================

    await connection.commit();

    return res.status(200).json({
      success: true,

      message:
        `Stock ${Adjustment_Type === "Add"
          ? "added"
          : "reduced"
        } successfully`,

      adjustment: {
        id: adjustmentId,
        Item_Id,
        Adjustment_Type,
        Quantity: qty,
        Selected_Unit: Selected_Unit || null,
        Base_Qty: baseQty,
        At_Price:
          At_Price !== undefined &&
            At_Price !== null &&
            At_Price !== ""
            ? Number(At_Price)
            : null,
        Details: Details || null,
        Adjustment_Date,
      },
    });

  } catch (err) {

    if (connection) {
      await connection.rollback();
    }

    console.error(
      "❌ addStockAdjustment:",
      err
    );

    next(err);

  } finally {

    if (connection) {
      connection.release();
    }
  }
};
const editStockAdjustment = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    // =========================================================
    // 1. IDS + BODY
    //
    // URL:
    // /item/stock-adjustment/edit/:id
    //
    // id = item_stock_adjustments.id
    // Item_Id = body
    // =========================================================

    const { id } = req.params;

    const {
      Item_Id,
      Adjustment_Type,
      Quantity,
      Selected_Unit,
      At_Price,
      Details,
      Adjustment_Date,
    } = req.body;

    // =========================================================
    // 2. VALIDATION
    // =========================================================

    if (!id) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Adjustment ID is required.",
      });
    }

    if (!Item_Id) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Item ID is required.",
      });
    }

    if (
      !Adjustment_Type ||
      Quantity === undefined ||
      Quantity === null ||
      Quantity === ""
    ) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Invalid adjustment data.",
      });
    }

    if (
      Adjustment_Type !== "Add" &&
      Adjustment_Type !== "Reduce"
    ) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Invalid adjustment type.",
      });
    }

    const qty = Number(Quantity);

    if (!Number.isFinite(qty) || qty <= 0) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Quantity must be greater than 0.",
      });
    }

    // =========================================================
    // 3. GET OLD ADJUSTMENT
    // =========================================================

    const [[oldAdjustment]] = await connection.query(
      `
      SELECT
        id,
        Item_Id,
        Adjustment_Type,
        Quantity,
        Selected_Unit,
        Base_Qty,
        At_Price,
        Details,
        Adjustment_Date
      FROM item_stock_adjustments
      WHERE id = ?
        AND Item_Id = ?
      LIMIT 1
      `,
      [id, Item_Id]
    );

    if (!oldAdjustment) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "Stock adjustment not found for this item.",
      });
    }

    // =========================================================
    // 4. GET ITEM
    // =========================================================

    const [[item]] = await connection.query(
      `
      SELECT
        Item_Id,
        Item_Name,
        Primary_Unit,
        Secondary_Unit,
        Conversion_Rate,
        Stock_Quantity
      FROM add_item
      WHERE Item_Id = ?
      LIMIT 1
      `,
      [Item_Id]
    );

    if (!item) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "Item not found.",
      });
    }

    // =========================================================
    // 5. CALCULATE NEW BASE QTY
    //
    // Primary:
    //   2 Kg = 2
    //
    // Secondary:
    //   500 Gm / 1000 = 0.5 Kg
    //
    // Use item_unit_conversions for secondary units.
    // =========================================================

    let newBaseQty = qty;

    if (
      Selected_Unit &&
      Selected_Unit !== item.Primary_Unit
    ) {
      const [[conversion]] = await connection.query(
        `
        SELECT
          Conversion_Rate
        FROM item_unit_conversions
        WHERE  Primary_Unit = ?
          AND Secondary_Unit = ?
        ORDER BY id DESC
        LIMIT 1
        `,
        [

          item.Primary_Unit,
          Selected_Unit,
        ]
      );

      const conversionRate =
        Number(conversion?.Conversion_Rate) || 0;

      if (conversionRate <= 0) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message:
            `Missing conversion rate for ${item.Primary_Unit} → ${Selected_Unit}.`,
        });
      }

      newBaseQty = qty / conversionRate;
    }

    // =========================================================
    // 6. OLD SIGNED EFFECT
    //
    // Add    = +
    // Reduce = -
    // =========================================================

    const oldBaseQty =
      Number(oldAdjustment.Base_Qty) || 0;

    const oldSignedBaseQty =
      oldAdjustment.Adjustment_Type === "Add"
        ? oldBaseQty
        : -oldBaseQty;

    // =========================================================
    // 7. NEW SIGNED EFFECT
    //
    // Add    = +
    // Reduce = -
    // =========================================================

    const newSignedBaseQty =
      Adjustment_Type === "Add"
        ? newBaseQty
        : -newBaseQty;

    // =========================================================
    // 8. NET DIFFERENCE
    //
    // Example:
    //
    // Old: Reduce 10
    // New: Add 5
    //
    // old = -10
    // new = +5
    //
    // netDiff = +15
    // =========================================================

    const netDiff =
      newSignedBaseQty -
      oldSignedBaseQty;

    // =========================================================
    // 9. NEW LEDGER TYPE + DIRECTION
    // =========================================================

    const direction =
      Adjustment_Type === "Add"
        ? "In"
        : "Out";

    const txnType =
      Adjustment_Type === "Add"
        ? "Add_Adjustment"
        : "Reduce_Adjustment";

    // =========================================================
    // 10. UPDATE STOCK ADJUSTMENT TABLE
    // =========================================================

    await connection.query(
      `
      UPDATE item_stock_adjustments
      SET
        Adjustment_Type = ?,
        Quantity = ?,
        Selected_Unit = ?,
        Base_Qty = ?,
        At_Price = ?,
        Details = ?,
        Adjustment_Date = ?,
        updated_at = NOW()
      WHERE id = ?
        AND Item_Id = ?
      `,
      [
        Adjustment_Type,
        qty,
        Selected_Unit || null,
        newBaseQty,

        At_Price !== undefined &&
          At_Price !== null &&
          At_Price !== ""
          ? Number(At_Price)
          : null,

        Details || null,
        Adjustment_Date,

        id,
        Item_Id,
      ]
    );

    // =========================================================
    // 11. UPDATE ITEM MASTER STOCK
    //
    // NO NEGATIVE STOCK RESTRICTION
    // =========================================================

    await connection.query(
      `
      UPDATE add_item
      SET
        Stock_Quantity = Stock_Quantity + ?,
        updated_at = NOW()
      WHERE Item_Id = ?
      `,
      [
        netDiff,
        Item_Id,
      ]
    );

    // =========================================================
    // 12. FIND EXISTING ITEM LEDGER ROW
    // =========================================================

    const [[ledgerRow]] = await connection.query(
      `
      SELECT
        id
      FROM item_ledger
      WHERE Item_Id = ?
        AND Source_Id = ?
        AND Txn_Type IN (
          'Add_Adjustment',
          'Reduce_Adjustment'
        )
      LIMIT 1
      `,
      [
        Item_Id,
        id,
      ]
    );

    if (!ledgerRow) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "Adjustment ledger entry not found.",
      });
    }

    // =========================================================
    // 13. UPDATE EXISTING ITEM LEDGER ROW
    // =========================================================

    await connection.query(
      `
      UPDATE item_ledger
      SET
        Txn_Type = ?,
        Direction = ?,
        Quantity = ?,
        Selected_Unit = ?,
        Base_Qty = ?,
        Rate = ?,
        Txn_Date = ?
      WHERE id = ?
      `,
      [
        txnType,
        direction,
        qty,
        Selected_Unit || null,
        newBaseQty,

        At_Price !== undefined &&
          At_Price !== null &&
          At_Price !== ""
          ? Number(At_Price)
          : null,

        Adjustment_Date,

        ledgerRow.id,
      ]
    );

    // =========================================================
    // 14. FIX RUNNING STOCK
    //
    // The edited ledger row AND all rows after it
    // must move by netDiff.
    //
    // Example:
    //
    // Old adjustment: +10
    // New adjustment: +5
    //
    // netDiff = -5
    //
    // Current row and every later row:
    // Running_Stock -= 5
    // =========================================================

    if (netDiff !== 0) {
      await connection.query(
        `
        UPDATE item_ledger
        SET
          Running_Stock = Running_Stock + ?
        WHERE Item_Id = ?
          AND id >= ?
        `,
        [
          netDiff,
          Item_Id,
          ledgerRow.id,
        ]
      );
    }

    // =========================================================
    // 15. COMMIT
    // =========================================================

    await connection.commit();

    return res.status(200).json({
      success: true,
      message: "Stock adjustment updated successfully",

      adjustment: {
        id,
        Item_Id,
        Adjustment_Type,
        Quantity: qty,
        Selected_Unit:
          Selected_Unit || null,
        Base_Qty: newBaseQty,

        At_Price:
          At_Price !== undefined &&
            At_Price !== null &&
            At_Price !== ""
            ? Number(At_Price)
            : null,

        Details:
          Details || null,

        Adjustment_Date,
      },
    });

  } catch (err) {
    if (connection) {
      await connection.rollback();
    }

    console.error(
      "❌ editStockAdjustment:",
      err
    );

    next(err);

  } finally {
    if (connection) {
      connection.release();
    }
  }
};
const deleteStockAdjustment = async (req, res, next) => {
  let connection;
  try {
    const { id } = req.params;  // item_stock_adjustments.id

    if (!id) {
      return res.status(400).json({
        success: false,
        message: "Adjustment ID is required.",
      });
    }

    connection = await db.getConnection();
    await connection.beginTransaction();

    // =========================================================
    // 1. CHECK ADJUSTMENT EXISTS
    // =========================================================

    const [[adjustment]] = await connection.query(
      `SELECT * FROM item_stock_adjustments WHERE id = ? LIMIT 1`,
      [id]
    );

    if (!adjustment) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: "Stock adjustment not found.",
      });
    }

    const {
      Item_Id,
      Adjustment_Type,   // "Add_Adjustment" | "Reduce_Adjustment"
      Quantity,
    } = adjustment;

    const qty = Number(Quantity) || 0;

    // =========================================================
    // 2. VERIFY ITEM EXISTS
    // =========================================================

    const [[item]] = await connection.query(
      `SELECT Item_Id, Stock_Quantity FROM add_item WHERE Item_Id = ? LIMIT 1`,
      [Item_Id]
    );

    if (!item) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: "Item not found.",
      });
    }

    // =========================================================
    // 3. REVERSE Stock_Quantity ON add_item
    //    Add_Adjustment   added stock  → reverse = subtract
    //    Reduce_Adjustment removed stock → reverse = add
    // =========================================================

    if (Adjustment_Type === "Add") {
      await connection.query(
        `UPDATE add_item
         SET Stock_Quantity = Stock_Quantity - ?,
             updated_at     = NOW()
         WHERE Item_Id = ?`,
        [qty, Item_Id]
      );
    } else if (Adjustment_Type === "Reduce") {
      await connection.query(
        `UPDATE add_item
         SET Stock_Quantity = Stock_Quantity + ?,
             updated_at     = NOW()
         WHERE Item_Id = ?`,
        [qty, Item_Id]
      );
    }

    // =========================================================
    // 4. DELETE ITEM LEDGER ROW
    //    reverseItemLedger just deletes —
    //    Running_Stock recomputed via window function on read
    // =========================================================

    await reverseItemLedger({
      connection,
      itemId: Item_Id,
      txnType:
        Adjustment_Type === "Add"
          ? "Add_Adjustment"
          : "Reduce_Adjustment",
      referenceId: Number(id),
    });

    // =========================================================
    // 5. DELETE ADJUSTMENT RECORD
    // =========================================================

    await connection.query(
      `DELETE FROM item_stock_adjustments WHERE id = ?`,
      [id]
    );

    // =========================================================
    // 6. COMMIT
    // =========================================================

    await connection.commit();

    return res.status(200).json({
      success: true,
      message: "Stock adjustment deleted successfully.",
      id,
      Item_Id,
      Reversed_Quantity: qty,
      Adjustment_Type,
    });

  } catch (err) {
    if (connection) await connection.rollback();
    console.error("❌ deleteStockAdjustment:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};
const fonts = {
  Helvetica: {
    normal: "Helvetica",
    bold: "Helvetica-Bold",
    italics: "Helvetica-Oblique",
    bolditalics: "Helvetica-BoldOblique",
  },
};

const printer = new PdfPrinter(fonts);

const printEachItemSalesPurchasesReport = async (req, res) => {
  try {
    const {
      itemName,
      purchases = [],
      sales = [],
    } = req.body;

    const safe = (v) => (v !== undefined && v !== null ? v : "N/A");

    // 🔵 Build each Purchase/Sale section
    const buildSection = (title, list, type) => {
      if (!list.length) return [];

      const rows = [
        {
          text: title.toUpperCase(),
          style: "sectionHeader",
          alignment: "center",
          margin: [0, 20, 0, 10],
        },
      ];

      list.forEach((entry, idx) => {
        rows.push({
          unbreakable: true,
          stack: [
            // Small title
            {
              text: `${title.slice(0, -1)} ${idx + 1}`,
              style: "subTitle",
              margin: [0, 0, 0, 5],
            },

            // Party + Bill/Invoice details
            {
              columns: [
                {
                  width: "48%",
                  stack: [
                    { text: "Party Name", style: "label" },
                    { text: safe(entry.Party_Name), style: "value" },

                    { text: "GSTIN", style: "label" },
                    { text: safe(entry.GSTIN), style: "value" },

                    { text: "Phone", style: "label" },
                    { text: safe(entry.Phone_Number), style: "value" },
                  ],
                },

                {
                  width: "48%",
                  alignment: "right",
                  stack: [
                    {
                      text: type === "purchase" ? "Bill Number" : "Invoice Number",
                      style: "label"
                    },
                    {
                      text: safe(entry.Bill_Number || entry.Invoice_Number),
                      style: "value"
                    },

                    {
                      text: type === "purchase" ? "Bill Date" : "Invoice Date",
                      style: "label"
                    },
                    {
                      text: safe(
                        new Date(entry.Bill_Date || entry.Invoice_Date)
                          .toLocaleDateString("en-IN", {
                            day: "numeric",
                            month: "numeric",
                            year: "numeric",
                          })
                      ),
                      style: "value"
                    },

                  ],
                },
              ],
              columnGap: 20,
              margin: [0, 0, 0, 10],
            },

            // ITEMS TABLE
            {
              style: "tableSmall",
              table: {
                headerRows: 1,
                widths: ["auto", "*", "*", "*", "*", "*", "*", "*"],
                body: [
                  [
                    { text: "Sl", style: "tableHeader" },
                    { text: "Category", style: "tableHeader" },
                    { text: "Item", style: "tableHeader" },
                    { text: "HSN", style: "tableHeader" },
                    { text: "Qty", style: "tableHeader" },
                    { text: "Price", style: "tableHeader" },
                    { text: "Tax", style: "tableHeader" },
                    { text: "Amount", style: "tableHeader" },
                  ],

                  ...(entry.items || []).map((it, i) => [
                    i + 1,
                    safe(it.Item_Category),
                    safe(it.Item_Name),
                    safe(it.Item_HSN),
                    safe(it.Quantity),
                    safe(it.Sale_Price || it.Purchase_Price),
                    safe(it.Tax_Type),
                    Number(it.Amount || 0).toFixed(2),
                  ]),
                ],
              },
              layout: "lightHorizontalLines",
              margin: [0, 0, 0, 10],
            },

            // TOTALS
            {
              columns: [
                { width: "*", text: "" },
                {
                  width: "40%",
                  table: {
                    widths: ["*", "auto"],
                    body: [
                      ["Total Amount", safe(entry.Total_Amount)],
                      [
                        type === "purchase" ? "Paid" : "Received",
                        safe(entry.Total_Paid || entry.Total_Received),
                      ],
                      ["Balance Due", safe(entry.Balance_Due)],
                    ],
                  },
                  layout: "noBordersBox",
                },
              ],
              margin: [0, 0, 0, 15],
            },
          ],
        });
      });

      return rows;
    };

    // HEADER — print first party from first purchase or sale
    const firstEntry = purchases[0] || sales[0] || {};

    const docDefinition = {
      pageMargins: [18, 18, 18, 30],
      defaultStyle: { font: "Helvetica" },

      footer: (p, pc) => ({
        text: `Page ${p} of ${pc}`,
        alignment: "center",
        margin: [10, 10, 10, 10],
      }),

      content: [
        {
          text: safe(itemName),
          style: "header",
          alignment: "center",
          margin: [0, 0, 0, 8],
        },


        ...buildSection("Purchases", purchases, "purchase"),
        ...buildSection("Sales", sales, "sale"),
      ],

      styles: {
        header: { fontSize: 18, bold: true },
        sectionHeader: { fontSize: 15, bold: true },
        subTitle: { fontSize: 12, bold: true },
        label: { bold: true, fontSize: 10 },
        value: { fontSize: 10 },
        tableHeader: { bold: true, fillColor: "#eee" },
        tableSmall: { fontSize: 9 },
      },
    };

    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    const chunks = [];

    pdfDoc.on("data", (c) => chunks.push(c));
    pdfDoc.on("end", () => {
      res.setHeader("Content-Type", "application/pdf");
      res.send(Buffer.concat(chunks));
    });

    pdfDoc.end();
  } catch (err) {
    console.error("❌ PDF Print failed:", err);
    res.status(500).json({ message: "PDF Print Error" });
  }
};
const addItemUnit = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    const Unit_Name = req.body.Unit_Name?.trim();
    const Unit_Shorthand = req.body.Unit_Shorthand?.trim() || null;

    if (!Unit_Name) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Unit name is required",
      });
    }

    // Case-insensitive duplicate check
    // const [existingUnit] = await connection.query(
    //   `
    //   SELECT id
    //   FROM units
    //   WHERE LOWER(TRIM(Unit_Name)) = LOWER(TRIM(?))
    //   LIMIT 1
    //   `,
    //   [Unit_Name]
    // );
    const [existingUnit] = await connection.query(
      `
  SELECT id
  FROM units
  WHERE
    LOWER(TRIM(Unit_Name)) = LOWER(TRIM(?))
    OR (
      ? IS NOT NULL
      AND LOWER(TRIM(Unit_Shorthand)) = LOWER(TRIM(?))
    )
  LIMIT 1
  `,
      [
        Unit_Name,
        Unit_Shorthand,
        Unit_Shorthand,
      ]
    );

    if (existingUnit.length > 0) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Unit name or shorthand already exists",
      });
    }

    const [result] = await connection.query(
      `
      INSERT INTO units
      (
        Unit_Name,
        Unit_Shorthand,
        Is_System,
        Is_Used
      )
      VALUES (?, ?, 0, 0)
      `,
      [Unit_Name, Unit_Shorthand]
    );

    await connection.commit();

    return res.status(201).json({
      success: true,
      message: "Unit added successfully",
      data: {
        id: result.insertId,
        Unit_Name,
        Unit_Shorthand,
        Is_System: 0,
        Is_Used: 0,
      },
    });

  } catch (err) {
    if (connection) await connection.rollback();

    console.error("❌ Error adding unit:", err);

    next(err)
  } finally {
    if (connection) connection.release();
  }
};
const editItemUnit = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    const { id } = req.params;

    const Unit_Name = req.body.Unit_Name?.trim();
    const Unit_Shorthand =
      req.body.Unit_Shorthand?.trim() || null;

    if (!Unit_Name) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Unit name is required",
      });
    }

    const [[existingUnit]] = await connection.query(
      `
      SELECT
        id,
        Unit_Name,
        Unit_Shorthand,
        Is_System,
        Is_Used
      FROM units
      WHERE id = ?
      LIMIT 1
      `,
      [id]
    );

    if (!existingUnit) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "Unit not found",
      });
    }

    // System units can never be edited
    if (Number(existingUnit.Is_System) === 1) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "System units cannot be edited.",
      });
    }

    // if (Number(existingUnit.Is_Used) === 1) {
    //   await connection.rollback();

    //   return res.status(400).json({
    //     success: false,
    //     message:
    //       "This unit has already been used in transactions and cannot be edited.",
    //   });
    // }

    // Duplicate check (case-insensitive)
    // const [duplicate] = await connection.query(
    //   `
    //   SELECT id
    //   FROM units
    //   WHERE LOWER(TRIM(Unit_Name)) = LOWER(TRIM(?))
    //     AND id <> ?
    //   LIMIT 1
    //   `,
    //   [Unit_Name, id]
    // );
    const [duplicate] = await connection.query(
      `
  SELECT id
  FROM units
  WHERE (
    LOWER(TRIM(Unit_Name)) = LOWER(TRIM(?))
    OR (
      ? IS NOT NULL
      AND LOWER(TRIM(Unit_Shorthand)) = LOWER(TRIM(?))
    )
  )
  AND id <> ?
  LIMIT 1
  `,
      [
        Unit_Name,
        Unit_Shorthand,
        Unit_Shorthand,
        id,
      ]
    );

    if (duplicate.length > 0) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Unit name or shorthand already exists",
      });
    }

    await connection.query(
      `
      UPDATE units
      SET
        Unit_Name = ?,
        Unit_Shorthand = ?
      WHERE id = ?
      `,
      [
        Unit_Name,
        Unit_Shorthand,
        id,
      ]
    );

    await connection.commit();

    return res.status(200).json({
      success: true,
      message: "Unit updated successfully",
    });

  } catch (err) {
    if (connection) await connection.rollback();

    console.error("❌ Error updating unit:", err);

    next(err)
  } finally {
    if (connection) connection.release();
  }
};
const getAllItemUnits = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();
    const [results] = await db.query(`SELECT Unit_Name ,Unit_Shorthand FROM units`);

    const finalData = [];
    results.forEach((item) => {
      finalData.push({
        Unit_Name: item.Unit_Name,
        Unit_Shorthand: item.Unit_Shorthand,
      });
    })
    return res.status(200).json(results);
  } catch (err) {
    console.error("❌ Error getting units:", err);
    next(err);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};
const getAllItemUnitsCursor = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const search = req.query.search?.trim() || "";
    const limit = parseInt(req.query.limit, 10) || 10;
    const cursorId = req.query.cursor
      ? Number(req.query.cursor)
      : null;

    const whereParts = [];
    const params = [];

    if (search) {
      const like = `%${search}%`;

      whereParts.push(`
        (
          LOWER(Unit_Name) LIKE ?
          OR LOWER(Unit_Shorthand) LIKE ?
        )
      `);

      params.push(
        like.toLowerCase(),
        like.toLowerCase()
      );
    }

    // if (cursorId) {
    //   whereParts.push(`id < ?`);
    //   params.push(cursorId);
    // }
    if (cursorId) {
      whereParts.push(`id > ?`);
      params.push(cursorId);
    }

    const whereSQL =
      whereParts.length > 0
        ? `WHERE ${whereParts.join(" AND ")}`
        : "";

    const [[{ totalUnits }]] = await connection.query(
      `
      SELECT COUNT(*) AS totalUnits
      FROM units
      ${search ? whereSQL.replace(/AND id < \?/g, "") : ""}
      `,
      search
        ? params.filter((_, i) => i < 2)
        : []
    );

    const [rows] = await connection.query(
      `
      SELECT *
      FROM units
      ${whereSQL}
      ORDER BY id ASC
      LIMIT ?
      `,
      [...params, limit + 1]
    );

    const hasMore = rows.length > limit;

    const pageUnits = hasMore
      ? rows.slice(0, limit)
      : rows;

    return res.status(200).json({
      success: true,
      totalUnits,
      units: pageUnits,
      hasMore,
      nextCursor: hasMore
        ? pageUnits[pageUnits.length - 1].id
        : null,
    });
  } catch (err) {
    next(err);
  } finally {
    if (connection) connection.release();
  }
};
//CURSOR

const getUnitConversions = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const { unitId } = req.params;
    const { cursor = null, search = "" } = req.query;

    const limit = 10;

    if (!unitId) {
      return res.status(400).json({
        success: false,
        message: "Unit Id is required",
      });
    }

    // =========================================================
    // GET UNIT
    // =========================================================

    const [[unit]] = await connection.query(
      `
      SELECT
        id,
        Unit_Name,
        Unit_Shorthand
      FROM units
      WHERE id = ?
      LIMIT 1
      `,
      [unitId]
    );

    if (!unit) {
      return res.status(404).json({
        success: false,
        message: "Unit not found",
      });
    }

    // =========================================================
    // FILTERS
    // =========================================================

    const where = [
      `Primary_Unit = ?`
    ];

    const params = [
      unit.Unit_Shorthand
    ];

    if (search?.trim()) {
      const like = `%${search.trim().toLowerCase()}%`;

      where.push(`
        (
          LOWER(COALESCE(Primary_Unit,'')) LIKE ?
          OR LOWER(COALESCE(Secondary_Unit,'')) LIKE ?
          OR CAST(COALESCE(Conversion_Rate,0) AS CHAR) LIKE ?
        )
      `);

      params.push(
        like,
        like,
        like
      );
    }

    // =========================================================
    // TOTAL COUNT
    // =========================================================

    const [countRows] = await connection.query(
      `
      SELECT COUNT(*) AS total
      FROM item_unit_conversions
      WHERE ${where.join(" AND ")}
      `,
      params
    );

    const totalConversions =
      Number(countRows[0]?.total || 0);

    // =========================================================
    // CURSOR PAGINATION
    // =========================================================

    if (cursor) {
      try {
        const decoded = JSON.parse(
          Buffer.from(cursor, "base64").toString("utf8")
        );

        if (!decoded.id) {
          return res.status(400).json({
            success: false,
            message: "Invalid cursor",
          });
        }

        where.push(`id < ?`);
        params.push(Number(decoded.id));
      } catch (err) {
        return res.status(400).json({
          success: false,
          message: "Invalid cursor",
        });
      }
    }

    // =========================================================
    // FETCH DATA
    // =========================================================

    const [rows] = await connection.query(
      `
      SELECT
        id,
        Primary_Unit,
        Secondary_Unit,
        Conversion_Rate
      FROM item_unit_conversions
      WHERE ${where.join(" AND ")}
      ORDER BY id DESC
      LIMIT ?
      `,
      [...params, limit + 1]
    );

    const hasMore = rows.length > limit;

    const conversions = hasMore
      ? rows.slice(0, limit)
      : rows;

    // =========================================================
    // NEXT CURSOR
    // =========================================================

    let nextCursor = null;

    if (hasMore && conversions.length > 0) {
      const last =
        conversions[conversions.length - 1];

      nextCursor = Buffer.from(
        JSON.stringify({
          id: last.id,
        })
      ).toString("base64");
    }
    console.log(
      rows.map(r => ({
        id: r.id,
        rate: r.Conversion_Rate
      }))
    );
    // =========================================================
    // RESPONSE
    // =========================================================

    return res.status(200).json({
      success: true,

      unit: {
        id: unit.id,
        Unit_Name: unit.Unit_Name,
        Unit_Shorthand: unit.Unit_Shorthand,
      },

      totalConversions,

      conversions: conversions.map((row) => ({
        id: row.id,
        Primary_Unit: row.Primary_Unit,
        Secondary_Unit: row.Secondary_Unit,
        Conversion_Rate:
          row.Conversion_Rate !== null
            ? Number(row.Conversion_Rate)
            : null,
      })),

      nextCursor,
      hasMore,
    });

  } catch (err) {
    console.error(
      "❌ Error fetching unit conversions:",
      err
    );
    next(err);
  } finally {
    if (connection) {
      connection.release();
    }
  }
};

export {
  addItem, importItemsExcel, validateImportItemRow,importItemRows,editItem, deleteItem, addCategory, editCategory, getAllItems, getItemsForDropdown, getItemByName, getAllCategories, getAllCategoriesCursor,
  getItemsNotInCategory, moveItemsToCategory,
  eachItemSalesPurchaseDetails,
  printEachItemSalesPurchasesReport, eachItemBillAndInvoiceNumbers, addItemConversion, getItemConversions,
  getAllItemsForLedger, getItemByCode, getItemBills, getItemsByCategory, addStockAdjustment, editStockAdjustment,
  deleteStockAdjustment, addItemUnit, editItemUnit, getAllItemUnits, getAllItemUnitsCursor, getUnitConversions
};
// ALTER TABLE add_item


// CHANGE COLUMN Item_Unit Primary_Unit VARCHAR(255) NULL AFTER `Item_Unit`,


// ADD COLUMN Secondary_Unit VARCHAR(255) NULL
// AFTER Primary_Unit,


// ADD COLUMN Conversion_Rate DECIMAL(18,6) NULL
// AFTER Secondary_Unit,

// -- Opening stock entered from Item → Stock tab
// ADD COLUMN Opening_Quantity DECIMAL(18,6) NULL DEFAULT NULL
// AFTER Stock_Quantity,

// -- Cost/value of opening stock
// ADD COLUMN At_Price DECIMAL(10,2) NULL DEFAULT NULL
// AFTER Opening_Quantity,

// -- Date from which opening stock applies
// ADD COLUMN As_Of_Date DATE NULL DEFAULT NULL
// AFTER At_Price,

// -- Low-stock warning level
// ADD COLUMN Min_Stock DECIMAL(10,2) NULL DEFAULT NULL
// AFTER As_Of_Date,

// -- Storage location
// ADD COLUMN Location VARCHAR(255) NULL DEFAULT NULL
// AFTER Min_Stock;

// }
// | When bill was created | Unit used on bill | Item configuration NOW | OLD bill dropdown | NEW bill dropdown | Old stock effect              |
// | --------------------- | ----------------- | ---------------------- | ----------------- | ----------------- | ----------------------------- |
// | `None`                | None              | None                   | None              | None              | Stored `Base_Quantity`        |
// | `None`                | None              | `Kg`                   | **Kg**            | **Kg**            | unchanged                     |
// | `None`                | None              | `Kg + Gm`              | **Kg + Gm**       | **Kg + Gm**       | unchanged                     |
// | `Kg`                  | Kg                | `Kg + Gm`              | **Kg + Gm**       | **Kg + Gm**       | unchanged                     |
// | `Kg + Gm`             | **Kg**            | `Kg + Box`             | **Kg + Box**      | **Kg + Box**      | unchanged                     |
// | `Kg + Gm`             | **Gm**            | `Kg + Box`             | **Kg + Gm**       | **Kg + Box**      | unchanged                     |
// | `Kg + Gm`             | **Gm**            | secondary removed      | **Kg + Gm**       | **Kg**            | unchanged                     |
// | `Kg + Gm`             | **Kg**            | secondary removed      | **Kg**            | **Kg**            | unchanged                     |
// | `Kg + Gm`             | **Gm**            | rate changed           | **Kg + Gm**       | **Kg + Gm**       | old `Base_Quantity` unchanged |
