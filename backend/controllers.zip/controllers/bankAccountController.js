import db from "../config/db.js";

/* ═══════════════════════════════════════
   CREATE BANK ACCOUNT
═══════════════════════════════════════ */
const createBankAccount = async (req, res, next) => {
  try {
    const {
      accountDisplayName,
      openingBalance,
      asOfDate,
      accountNumber,
      ifscCode,
      upiId,
      qrCodeImage,
      bankName,
      accountHolderName,
    } = req.body;

    if (!accountDisplayName || !accountDisplayName.trim()) {
      return res.status(400).json({ success: false, message: "Account Display Name is required" });
    }

    const [result] = await db.query(
      `INSERT INTO bank_accounts
       (Account_Display_Name, Opening_Balance, As_Of_Date, Account_Number,
        IFSC_Code, UPI_Id, QR_Code_Image, Bank_Name, Account_Holder_Name)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        accountDisplayName.trim(),
        openingBalance || 0,
        asOfDate || null,
        accountNumber || null,
        ifscCode || null,
        upiId || null,
        qrCodeImage || null,
        bankName || null,
        accountHolderName || null,
      ]
    );

    res.status(201).json({
      success: true,
      message: "Bank account created successfully",
      bankAccountId: result.insertId,
    });
  } catch (err) {
    console.error("❌ Create bank account error:", err);
    next(err);
  }
};

/* ═══════════════════════════════════════
   EDIT BANK ACCOUNT
═══════════════════════════════════════ */
const editBankAccount = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    const { Bank_Account_Id } = req.params;
    const {
      accountDisplayName,
      openingBalance,
      asOfDate,
      accountNumber,
      ifscCode,
      upiId,
      qrCodeImage,
      bankName,
      accountHolderName,
    } = req.body;

    if (!accountDisplayName || !accountDisplayName.trim()) {
      await connection.rollback();
      return res.status(400).json({ success: false, message: "Account Display Name is required" });
    }

    const [existing] = await connection.query(
      `SELECT * FROM bank_accounts WHERE id = ?`,
      [Bank_Account_Id]
    );
    if (existing.length === 0) {
      await connection.rollback();
      return res.status(404).json({ success: false, message: "Bank account not found" });
    }

    const currentAccount = existing[0];
    const newOpeningBalance = Number(openingBalance || 0);
    const openingBalanceChanged = newOpeningBalance !== Number(currentAccount.Opening_Balance);

    // 🔹 check if any transactions already exist against this account
    const [[{ txnCount }]] = await connection.query(
      `SELECT COUNT(*) AS txnCount FROM bank_transactions WHERE Bank_Account_Id = ?`,
      [Bank_Account_Id]
    );

    if (openingBalanceChanged && txnCount > 0) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: "Cannot change Opening Balance after transactions exist. This would corrupt the ledger's running balance history.",
      });
    }

    await connection.query(
      `UPDATE bank_accounts SET
        Account_Display_Name = ?, Opening_Balance = ?, As_Of_Date = ?,
        Account_Number = ?, IFSC_Code = ?, UPI_Id = ?, QR_Code_Image = ?,
        Bank_Name = ?, Account_Holder_Name = ?
       WHERE id = ?`,
      [
        accountDisplayName.trim(),
        newOpeningBalance,
        asOfDate || null,
        accountNumber || null,
        ifscCode || null,
        upiId || null,
        qrCodeImage || null,
        bankName || null,
        accountHolderName || null,
        Bank_Account_Id,
      ]
    );

    await connection.commit();
    res.status(200).json({ success: true, message: "Bank account updated successfully" });
  } catch (err) {
    if (connection) await connection.rollback();
    console.error("❌ Edit bank account error:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};

/* ═══════════════════════════════════════
   GET ALL BANK ACCOUNTS
═══════════════════════════════════════ */
const getAllBankAccounts = async (req, res, next) => {
  try {
    const [accounts] = await db.query(`
  SELECT
  ba.id AS Bank_Account_Id,
  ba.Account_Display_Name,
  ba.Bank_Name,
  ba.Account_Holder_Name,
  ba.Account_Number,
  ba.IFSC_Code,
  ba.UPI_Id,
  ba.Opening_Balance,
  ba.As_Of_Date,
  COALESCE(
    (
      SELECT bt.Running_Balance
      FROM bank_transactions bt
      WHERE bt.Bank_Account_Id = ba.id
      ORDER BY bt.id DESC
      LIMIT 1
    ),
    ba.Opening_Balance
  ) AS Current_Balance
FROM bank_accounts ba
ORDER BY ba.Account_Display_Name;
`);

    res.status(200).json({ success: true, bankAccounts: accounts });
  } catch (err) {
    console.error("❌ Get all bank accounts error:", err);
    next(err);
  }
};

/* ═══════════════════════════════════════
   GET SINGLE BANK ACCOUNT + ALL TRANSACTIONS
   (reads straight from the running-balance ledger — no recompute)
═══════════════════════════════════════ */


// const getBankAccountById = async (req, res, next) => {
//   try {
//     const { Bank_Account_Id } = req.params;
//     const limit = Math.min(parseInt(req.query.limit, 10) || 10, 200);
//     //const limit = Number(req.query.limit) || 10;

//     // 🔹 decode cursor
//     let cursorId = null;
//     const cursorRaw = req.query.cursor || null;

//     if (cursorRaw) {
//       try {
//         const decoded = JSON.parse(
//           Buffer.from(cursorRaw, "base64").toString("utf8")
//         );
//         cursorId = decoded.id ? Number(decoded.id) : null;
//       } catch {
//         return res.status(400).json({
//           success: false,
//           message: "Invalid cursor.",
//         });
//       }
//     }

//     const [[account]] = await db.query(
//       `SELECT
//          id AS Bank_Account_Id,
//          Account_Display_Name,
//          Bank_Name,
//          Account_Holder_Name,
//          Account_Number,
//          IFSC_Code,
//          UPI_Id,
//          Opening_Balance,
//          As_Of_Date
//        FROM bank_accounts
//        WHERE id = ?`,
//       [Bank_Account_Id]
//     );

//     if (!account) {
//       return res.status(404).json({
//         success: false,
//         message: "Bank account not found",
//       });
//     }

//     // 🔹 cursor condition — fetch rows with id < cursorId
//     const cursorSQL = cursorId ? `AND bt.id < ?` : "";
//     const queryParams = cursorId
//       ? [Bank_Account_Id, cursorId, limit + 1]
//       : [Bank_Account_Id, limit + 1];

//     const [transactions] = await db.query(
//       `WITH txn AS (
//          SELECT
//            bt.*,
//            ps.Source_Type,
//            ps.Source_Id
//          FROM bank_transactions bt
//          LEFT JOIN payment_splits ps
//            ON bt.Reference_Id = ps.id
//            AND bt.Txn_Type IN (
//              'Sale', 'Purchase', 'Sale_Return', 'Purchase_Return',
//              'Payment_In', 'Payment_Out', 'Expense'
//            )
//          WHERE bt.Bank_Account_Id = ?
//            ${cursorSQL}
//        )
//        SELECT
//          txn.*,
//          CASE txn.Txn_Type
//            WHEN 'Sale'            THEN s.Sale_Id
//            WHEN 'Purchase'        THEN p.Purchase_Id
//            WHEN 'Expense'         THEN e.id
//            WHEN 'Sale_Return'     THEN sr.id
//            WHEN 'Purchase_Return' THEN pr.id
//            WHEN 'Payment_In'      THEN pi.id
//            WHEN 'Payment_Out'     THEN po.id
//          END AS Formatted_Reference_Id
//        FROM txn
//        LEFT JOIN add_sale s
//          ON txn.Txn_Type = 'Sale' AND txn.Source_Id = s.id
//        LEFT JOIN add_purchase p
//          ON txn.Txn_Type = 'Purchase' AND txn.Source_Id = p.id
//        LEFT JOIN sale_return sr
//          ON txn.Txn_Type = 'Sale_Return' AND txn.Source_Id = sr.id
//        LEFT JOIN purchase_return pr
//          ON txn.Txn_Type = 'Purchase_Return' AND txn.Source_Id = pr.id
//        LEFT JOIN payment_in pi
//          ON txn.Txn_Type = 'Payment_In' AND txn.Source_Id = pi.Id
//        LEFT JOIN payment_out po
//          ON txn.Txn_Type = 'Payment_Out' AND txn.Source_Id = po.id

// LEFT JOIN expenses e
//   ON txn.Txn_Type = 'Expense' AND txn.Source_Id = e.id
//        ORDER BY txn.id DESC
//        LIMIT ?`,
//       queryParams
//     );

//     // 🔹 detect hasMore by fetching limit+1
//     const hasMore = transactions.length > limit;
//     const pageRows = hasMore ? transactions.slice(0, limit) : transactions;

//     // 🔹 build next cursor from last row
//     let nextCursor = null;
//     if (hasMore && pageRows.length > 0) {
//       const last = pageRows[pageRows.length - 1];
//       nextCursor = Buffer.from(
//         JSON.stringify({ id: last.id })
//       ).toString("base64");
//     }

//     // current balance — always from the latest row regardless of cursor
//     const [[latestRow]] = await db.query(
//       `SELECT Running_Balance
//        FROM bank_transactions
//        WHERE Bank_Account_Id = ?
//        ORDER BY id DESC LIMIT 1`,
//       [Bank_Account_Id]
//     );

//     const currentBalance = latestRow
//       ? Number(latestRow.Running_Balance)
//       : Number(account.Opening_Balance);

//     res.status(200).json({
//       success: true,
//       bankAccount: account,
//       currentBalance,
//       transactions: pageRows,
//       hasMore,
//       nextCursor,
//     });
//   } catch (err) {
//     console.error("❌ Get bank account details error:", err);
//     next(err);
//   }
// };
const getBankAccountById = async (req, res, next) => {
  try {
    const { Bank_Account_Id } = req.params;

    const limit = Math.min(
      parseInt(req.query.limit, 10) || 10,
      200
    );

    // =========================================================
    // 1. DECODE CURSOR
    // =========================================================

    let cursorDate = null;
    let cursorId = null;

    const cursorRaw = req.query.cursor || null;

    if (cursorRaw) {
      try {
        const decoded = JSON.parse(
          Buffer.from(cursorRaw, "base64").toString("utf8")
        );

        cursorDate = decoded.date || null;
        cursorId = decoded.id ? Number(decoded.id) : null;

        if (!cursorDate || !cursorId) {
          return res.status(400).json({
            success: false,
            message: "Invalid cursor.",
          });
        }
      } catch {
        return res.status(400).json({
          success: false,
          message: "Invalid cursor.",
        });
      }
    }

    // =========================================================
    // 2. GET BANK ACCOUNT
    // =========================================================

    const [[account]] = await db.query(
      `
      SELECT
        id AS Bank_Account_Id,
        Account_Display_Name,
        Bank_Name,
        Account_Holder_Name,
        Account_Number,
        IFSC_Code,
        UPI_Id,
        Opening_Balance,
        As_Of_Date
      FROM bank_accounts
      WHERE id = ?
      `,
      [Bank_Account_Id]
    );

    if (!account) {
      return res.status(404).json({
        success: false,
        message: "Bank account not found",
      });
    }

    // =========================================================
    // 3. CURSOR CONDITION
    //
    // ORDER:
    // Txn_Date DESC
    // id       DESC
    //
    // For the next page:
    // - older date
    // OR
    // - same date + smaller id
    // =========================================================

    const cursorSQL = cursorId
      ? `
        AND (
          bt.Txn_Date < ?
          OR (
            bt.Txn_Date = ?
            AND bt.id < ?
          )
        )
      `
      : "";

    const queryParams = cursorId
      ? [
          Bank_Account_Id,
          cursorDate,
          cursorDate,
          cursorId,
          limit + 1,
        ]
      : [
          Bank_Account_Id,
          limit + 1,
        ];

    // =========================================================
    // 4. GET TRANSACTIONS
    // =========================================================

    const [transactions] = await db.query(
      `
      WITH txn AS (
        SELECT
          bt.*,
          ps.Source_Type,
          ps.Source_Id

        FROM bank_transactions bt

        LEFT JOIN payment_splits ps
          ON bt.Reference_Id = ps.id
          AND bt.Txn_Type IN (
            'Sale',
            'Purchase',
            'Sale_Return',
            'Purchase_Return',
            'Payment_In',
            'Payment_Out',
            'Expense'
          )

        WHERE bt.Bank_Account_Id = ?

        ${cursorSQL}
      )

      SELECT
        txn.*,

        CASE txn.Txn_Type

          WHEN 'Sale'
            THEN s.Sale_Id

          WHEN 'Purchase'
            THEN p.Purchase_Id

          WHEN 'Expense'
            THEN e.id

          WHEN 'Sale_Return'
            THEN sr.id

          WHEN 'Purchase_Return'
            THEN pr.id

          WHEN 'Payment_In'
            THEN pi.id

          WHEN 'Payment_Out'
            THEN po.id

        END AS Formatted_Reference_Id

      FROM txn

      LEFT JOIN add_sale s
        ON txn.Txn_Type = 'Sale'
        AND txn.Source_Id = s.id

      LEFT JOIN add_purchase p
        ON txn.Txn_Type = 'Purchase'
        AND txn.Source_Id = p.id

      LEFT JOIN sale_return sr
        ON txn.Txn_Type = 'Sale_Return'
        AND txn.Source_Id = sr.id

      LEFT JOIN purchase_return pr
        ON txn.Txn_Type = 'Purchase_Return'
        AND txn.Source_Id = pr.id

      LEFT JOIN payment_in pi
        ON txn.Txn_Type = 'Payment_In'
        AND txn.Source_Id = pi.Id

      LEFT JOIN payment_out po
        ON txn.Txn_Type = 'Payment_Out'
        AND txn.Source_Id = po.id

      LEFT JOIN expenses e
        ON txn.Txn_Type = 'Expense'
        AND txn.Source_Id = e.id

      ORDER BY
        txn.Txn_Date DESC,
        txn.id DESC

      LIMIT ?
      `,
      queryParams
    );

    // =========================================================
    // 5. HAS MORE
    // =========================================================

    const hasMore = transactions.length > limit;

    const pageRows = hasMore
      ? transactions.slice(0, limit)
      : transactions;

    // =========================================================
    // 6. NEXT CURSOR
    // =========================================================

    let nextCursor = null;

    if (hasMore && pageRows.length > 0) {
      const last = pageRows[pageRows.length - 1];

      nextCursor = Buffer.from(
        JSON.stringify({
          date: last.Txn_Date,
          id: last.id,
        })
      ).toString("base64");
    }

    // =========================================================
    // 7. CURRENT BANK BALANCE
    // =========================================================
    //
    // IMPORTANT:
    // The latest balance is still determined by the transaction
    // with the greatest id because Running_Balance represents
    // the ledger sequence.
    //
    // This is independent from how the UI list is sorted.
    // =========================================================

    const [[latestRow]] = await db.query(
      `
      SELECT Running_Balance
      FROM bank_transactions
      WHERE Bank_Account_Id = ?
      ORDER BY id DESC
      LIMIT 1
      `,
      [Bank_Account_Id]
    );

    const currentBalance = latestRow
      ? Number(latestRow.Running_Balance)
      : Number(account.Opening_Balance);

    // =========================================================
    // 8. RESPONSE
    // =========================================================

    return res.status(200).json({
      success: true,
      bankAccount: account,
      currentBalance,
      transactions: pageRows,
      hasMore,
      nextCursor,
    });

  } catch (err) {
    console.error(
      "❌ Get bank account details error:",
      err
    );

    next(err);
  }
};

/* ═══════════════════════════════════════
   DELETE BANK ACCOUNT (optional, guard against existing txns)
═══════════════════════════════════════ */
//  const deleteBankAccount = async (req, res, next) => {
//   try {
//     const { id } = req.params;
//     const [[{ txnCount }]] = await db.query(
//       `SELECT COUNT(*) AS txnCount FROM bank_transactions WHERE id = ?`,
//       [id]
//     );
//     if (txnCount > 0) {
//       return res.status(400).json({
//         success: false,
//         message: "Cannot delete: transactions already recorded against this account",
//       });
//     }
//     await db.query(`DELETE FROM bank_accounts WHERE id = ?`, [id]);
//     res.status(200).json({ success: true, message: "Bank account deleted" });
//   } catch (err) {
//     console.error("❌ Delete bank account error:", err);
//     next(err);
//   }
// };

export { createBankAccount, editBankAccount, getAllBankAccounts, getBankAccountById };
