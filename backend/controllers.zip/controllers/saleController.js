
import db from "../config/db.js"; // mysql2/promise db
import { sanitizeObject } from "../utils/sanitizeInput.js";

import saleSchema from "../validators/saleSchema.js";
import PdfPrinter from "pdfmake";
import ExcelJS from "exceljs";

import { deletePaymentSplits, insertPaymentSplits, validateSplits } from "../utils/paymentSplitHelper.js";
import { recordPartyLedger, reversePartyLedger } from "../utils/partyLedgerHelper.js";
import { recordItemLedger, reverseItemLedger } from "../utils/itemLedgerHelper.js";
import { resolveUnitAndStockDelta } from "../utils/resolveUnitAndStockDelta.js";
import { getSalesForPrint } from "../helpers/printReportHelpers.js";
import { syncUnitIdsForItem, syncUnitIdsForSaleItem } from "../helpers/unitSyncHelper.js";
// import puppeteer from "puppeteer";
//import pdf from "html-pdf-node";
const TAX_TYPES = {
  "GST0": "GST 0%",
  "GST0.25": "GST 0.25%",
  "GST3": "GST 3%",
  GST5: "GST 5%",
  GST12: "GST 12%",
  GST18: "GST 18%",
  GST28: "GST 28%",
  GST40: "GST 40%",
  "IGST0": "IGST 0%",
  "IGST0.25": "IGST 0.25%",
  "IGST3": "IGST 3%",
  IGST5: "IGST 5%",
  IGST12: "IGST 12%",
  IGST18: "IGST 18%",
  IGST28: "IGST 28%",
  IGST40: "IGST 40%"
}
// const cleanValue = (value) => {
//   if (value === undefined || value === null || value === "" || value === " ") {
//     return null; // store as NULL in DB
//   }
//   return value;  // ✅ returns the original value for valid data
// };
const cleanValue = (value) => {
  if (value === undefined || value === null) {
    return null;
  }

  if (typeof value === "string") {
    const trimmedValue = value.trim();

    return trimmedValue === "" ? null : trimmedValue;
  }

  return value;
};
const cleanDiscount = (value) => {
  if (value === undefined || value === null || value === "" || value === " ") {
    return 0.00; // store as 0.00 in DB
  }
  return Number(value);
}
const normalizeNumber = (val) =>
  val !== undefined && val !== null && String(val).trim() !== ""
    ? Number(val)
    : null;


const buildLegacyInvoiceNumber = (
  invoiceNumberPrefix,
  invoiceNumberValue
) => {
  const prefix =
    String(invoiceNumberPrefix ?? "").trim() || "None";

  const valueString =
    String(invoiceNumberValue ?? "").trim();

  // No number
  if (valueString === "") {
    return null;
  }

  const number = Number(valueString);

  // 0 / 00 / 000000 means no invoice number
  if (number === 0) {
    return null;
  }

  // None + 5000 -> "5000"
  if (prefix === "None") {
    return String(number);
  }

  // SAL + 5000 -> "SAL5000"
  return `${prefix}${number}`;
};
//OLD






const addSale = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    // =========================================================
    // 1. SANITIZE + ZOD VALIDATION
    // =========================================================

    const cleanData = sanitizeObject(req.body);

    const validation = saleSchema.safeParse(cleanData);

    if (!validation.success) {
      await connection.rollback();

      return res.status(400).json({
        errors: validation.error.errors,
      });
    }

    const {
      Sale_Mode,          // 🔹 "Credit" | "Cash" — request/controller logic only, never stored
      Party_Name,
      Billing_Name,        // 🔹 invoice snapshot field
      Phone_Number,
      Billing_Address,
      GSTIN,
      Invoice_Number,
      Invoice_Number_Prefix,
      Invoice_Number_Value,
      Invoice_Date,
      State_Of_Supply,
      Transaction_Discount_Percentage,
      Transaction_Discount_Amount,
      Total_Amount,
      Round_Off,
      Total_Received,
      Balance_Due,
      splits,
      Terms_Conditions_Id,          // nullable int — null if user typed fresh or cleared
      Terms_Conditions_Description,
      items,

    } = validation.data;

    const saleMode = Sale_Mode === "Cash" ? "Cash" : "Credit"; // default Credit if missing/unexpected
    console.log("Sale mode:", saleMode);
    // =========================================================
    // 2. TOTAL AMOUNT
    // =========================================================

    const totalAmount = Number(Total_Amount) || 0;
    const roundOffValue = Number(Round_Off) || 0

    // =========================================================
    // 3. SALE PAYMENT SPLITS
    //
    // CREDIT: existing behavior — first split kept even at ₹0,
    //         later ₹0 splits dropped, positive splits kept.
    //
    // CASH: sum of splits MUST equal totalAmount exactly.
    //       Always fully paid — Total_Received/Balance_Due are
    //       computed here, never trusted from frontend.
    // =========================================================
    let termsId = null;
    let termsDescription = null;



    if (
      Terms_Conditions_Id &&
      Terms_Conditions_Description?.trim()
    ) {
      // Template selected and untouched
      termsId = Number(Terms_Conditions_Id);
      termsDescription = Terms_Conditions_Description.trim();

    } else if (Terms_Conditions_Description?.trim()) {
      // Custom / edited description
      // UI has already cleared the template ID/title
      termsId = null;
      termsDescription = Terms_Conditions_Description.trim();
    }

    // Otherwise:
    // termsId = null
    // termsDescription = null
    if (termsId) {
      const [[selectedTerm]] = await connection.query(
        `SELECT id
     FROM terms_conditions
     WHERE id = ?
       AND Sale_Invoice = 1
     LIMIT 1`,
        [termsId]
      );

      if (!selectedTerm) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message: "Invalid Terms & Conditions for Sale Invoice.",
        });
      }
    }

    let validSplits = [];

    if (totalAmount > 0) {
      const normalizedSplits = (splits || [])
        .filter((split) => {
          // Must have payment type
          if (!split.Payment_Type) {
            return false;
          }

          // Bank must have selected bank account
          if (
            split.Payment_Type === "Bank" &&
            !split.Bank_Account_Id
          ) {
            return false;
          }

          return true;
        })
        .map((split) => ({
          ...split,
          Amount: Number(split.Amount) || 0,
        }));

      if (saleMode === "Cash") {
        // 🔹 Cash mode: keep every split with a real amount (no first-at-₹0 exception —
        //    a cash sale must be exactly and fully paid, so a ₹0 placeholder split is meaningless)
        validSplits = normalizedSplits.filter((split) => split.Amount > 0);
      } else {
        // 🔹 Credit mode — unchanged existing logic
        validSplits = normalizedSplits.filter(
          (split, index) => {
            // FIRST valid payment method: always preserve, even ₹0
            if (index === 0) {
              return true;
            }
            // Every payment after first: only preserve positive amount
            return split.Amount > 0;
          }
        );
      }
    }

    // =========================================================
    // 4. TOTAL RECEIVED / BALANCE DUE
    //
    // Backend calculates this. Don't trust Total_Received/Balance_Due
    // coming from frontend, especially for Cash mode.
    // =========================================================

    let totalReceived;
    let balanceDue;

    if (saleMode === "Cash") {
      // 🔹 Cash sale must be fully paid — enforced here, not trusted from frontend
      totalReceived = totalAmount;
      balanceDue = 0;

      if (totalAmount > 0) {
        const splitsSum = validSplits.reduce(
          (sum, split) => sum + (Number(split.Amount) || 0),
          0
        );

        if (Math.round(splitsSum * 100) !== Math.round(totalAmount * 100)) {
          await connection.rollback();
          return res.status(400).json({
            success: false,
            message:
              splitsSum < totalAmount
                ? "Cash sale must be fully paid."
                : "Payment exceeds the total amount.",
          });
        }
      }
    } else {
      // 🔹 Credit mode — unchanged existing logic
      totalReceived = validSplits.reduce(
        (sum, split) => sum + (Number(split.Amount) || 0),
        0
      );
      balanceDue = totalAmount - totalReceived;
    }

    // =========================================================
    // 6. PAYMENT VALIDATION
    // =========================================================

    if (totalReceived > totalAmount) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message:
          "Received amount should be less than or equal to Total Amount",
      });
    }

    // Only validate when an actual payment exists
    if (totalReceived > 0) {
      try {
        validateSplits(validSplits, totalReceived);
      } catch (validationErr) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message: validationErr.message,
        });
      }
    }




    // =========================================================
    // RESOLVE PARTY
    // =========================================================

    let Party_Id;
    let resolvedPartyName;

    if (saleMode === "Credit") {
      // Credit sale MUST have a party
      if (!Party_Name?.trim()) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message: "Party is required for a Credit sale.",
        });
      }

      resolvedPartyName = Party_Name.trim();

    } else {
      // Cash mode:
      // blank party -> special system "Cash Sale" party
      // selected party -> normal party
      resolvedPartyName = Party_Name?.trim() || "Cash Sale";
    }


    // =========================================================
    // IS THIS THE SPECIAL CASH SALE PARTY?
    // =========================================================

    const isCashSaleParty = resolvedPartyName.toLowerCase() === "cash sale";


    // =========================================================
    // FIND PARTY
    // =========================================================

    const [partyRows] = await connection.execute(
      `SELECT *
   FROM add_party
   WHERE TRIM(Party_Name) = TRIM(?)
   LIMIT 1`,
      [resolvedPartyName]
    );


    // =========================================================
    // CASE 1: PARTY DOES NOT EXIST
    // =========================================================

    if (partyRows.length === 0) {

      // =======================================================
      // A. CREATE SPECIAL "CASH SALE" PARTY
      // =======================================================
      //
      // Cash Sale is only an accounting/system party.
      //
      // DON'T put invoice customer details into its master:
      // - Billing_Name
      // - Phone_Number
      // - GSTIN
      // - Billing_Address
      //
      // Those belong to add_sale.
      // =======================================================

      if (isCashSaleParty) {

        const [partyResult] = await connection.execute(
          `INSERT INTO add_party
       (
         Party_Name,
         created_at,
         updated_at
       )
       VALUES (?, NOW(), NOW())`,
          [resolvedPartyName]
        );

        const partyIdNumber = partyResult.insertId;

        Party_Id =
          "PTY" +
          partyIdNumber.toString().padStart(3, "0");

        await connection.execute(
          `UPDATE add_party
       SET Party_Id = ?
       WHERE id = ?`,
          [
            Party_Id,
            partyIdNumber,
          ]
        );

      }

      // =======================================================
      // B. CREATE NEW NORMAL PARTY
      // =======================================================

      else {

        const [partyResult] = await connection.execute(
          `INSERT INTO add_party
       (
         Party_Name,
         Billing_Name,
         Phone_Number,
         GSTIN,
         created_at,
         updated_at
       )
       VALUES (?, ?, ?, ?, NOW(), NOW())`,
          [
            resolvedPartyName,
            cleanValue(Billing_Name),
            cleanValue(Phone_Number),
            cleanValue(GSTIN),
          ]
        );

        const partyIdNumber = partyResult.insertId;

        Party_Id =
          "PTY" +
          partyIdNumber.toString().padStart(3, "0");

        await connection.execute(
          `UPDATE add_party
       SET Party_Id = ?
       WHERE id = ?`,
          [
            Party_Id,
            partyIdNumber,
          ]
        );


        // =====================================================
        // FIRST BILLING ADDRESS -> DEFAULT ADDRESS
        // =====================================================

        if (Billing_Address?.trim()) {

          await connection.execute(
            `INSERT INTO add_party_addresses
         (
           Party_Id,
           Address_Type,
           Address_Text,
           Is_Default,
           created_at,
           updated_at
         )
         VALUES (?, 'Billing', ?, 1, NOW(), NOW())`,
            [
              Party_Id,
              Billing_Address.trim(),
            ]
          );
        }
      }

    }


    // =========================================================
    // CASE 2: PARTY ALREADY EXISTS
    // =========================================================

    else {

      const existingParty = partyRows[0];

      Party_Id = existingParty.Party_Id;


      // =======================================================
      // SPECIAL "CASH SALE"
      // =======================================================
      //
      // DO NOTHING TO MASTER.
      //
      // Every invoice may belong to a different walk-in
      // customer, so invoice details must NOT modify Cash Sale.
      // =======================================================

      if (isCashSaleParty) {

        // Intentionally empty.
        //
        // DON'T update:
        // add_party.Billing_Name
        // add_party.Phone_Number
        // add_party.GSTIN
        // add_party_addresses
      }


      // =======================================================
      // NORMAL EXISTING PARTY
      // =======================================================

      else {

        // =====================================================
        // 1. BILLING NAME
        //
        // Initialize master only if currently blank.
        // =====================================================

        if (
          !existingParty.Billing_Name?.trim() &&
          Billing_Name?.trim()
        ) {

          await connection.execute(
            `UPDATE add_party
         SET
           Billing_Name = ?,
           updated_at = NOW()
         WHERE Party_Id = ?`,
            [
              //Billing_Name.trim(),
              cleanValue(Billing_Name),
              Party_Id,
            ]
          );
        }


        // =====================================================
        // 2. PHONE NUMBER
        //
        // Initialize master only if currently blank.
        // =====================================================

        if (
          !existingParty.Phone_Number?.trim() &&
          Phone_Number?.trim()
        ) {

          await connection.execute(
            `UPDATE add_party
         SET
           Phone_Number = ?,
           updated_at = NOW()
         WHERE Party_Id = ?`,
            [
              Phone_Number.trim(),
              Party_Id,
            ]
          );
        }


        // =====================================================
        // 3. BILLING ADDRESS
        //
        // Initialize only if NO billing address exists.
        // =====================================================

        if (Billing_Address?.trim()) {

          const [[{ addrCount }]] =
            await connection.query(
              `SELECT COUNT(*) AS addrCount
           FROM add_party_addresses
           WHERE Party_Id = ?
             AND Address_Type = 'Billing'`,
              [Party_Id]
            );

          if (Number(addrCount) === 0) {

            await connection.execute(
              `INSERT INTO add_party_addresses
           (
             Party_Id,
             Address_Type,
             Address_Text,
             Is_Default,
             created_at,
             updated_at
           )
           VALUES (?, 'Billing', ?, 1, NOW(), NOW())`,
              [
                Party_Id,
                Billing_Address.trim(),
              ]
            );
          }
        }

        // GSTIN:
        // readonly in Sale UI.
        // Don't update an existing party's GSTIN from sale.
      }
    }



    // =========================================================
    // 8. ACTIVE FINANCIAL YEAR
    // =========================================================

    const [fy] = await connection.query(
      `SELECT Financial_Year
       FROM financial_year
       WHERE Current_Financial_Year = 1
       LIMIT 1`
    );

    if (fy.length === 0) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message:
          "No active financial year found. Please set one in settings.",
      });
    }

    const activeFY = fy[0].Financial_Year;

    // =========================================================
    // 9. CREATE SALE HEADER
    //
    // Billing_Name / Phone_Number / Billing_Address stored here
    // as this invoice's own snapshot — independent of party master.
    // =========================================================
    const transactionDiscountPercentage =
      normalizeNumber(Transaction_Discount_Percentage);

    const transactionDiscountAmount =
      normalizeNumber(Transaction_Discount_Amount);
    if (
      transactionDiscountPercentage !== null &&
      transactionDiscountPercentage > 100
    ) {
      return res.status(400).json({
        success: false,
        message: "Transaction discount percentage cannot be greater than 100%",
      });
    }

    const cleanTransactionDiscountPercentage =
      transactionDiscountPercentage > 0
        ? transactionDiscountPercentage
        : null;

    const cleanTransactionDiscountAmount =
      transactionDiscountAmount > 0
        ? transactionDiscountAmount
        : null;
    // =========================================================
    // INVOICE NUMBER + TRANSACTION PREFIX SEQUENCE
    // =========================================================

    // let invoiceNumber = String(Invoice_Number || "").trim();

    // // ---------------------------------------------------------
    // // SPECIAL CASE:
    // // 000 / 00 / 0000 etc. means blank invoice number.
    // // No error.
    // // ---------------------------------------------------------

    // if (/^0+$/.test(invoiceNumber)) {
    //   invoiceNumber = "";
    // }


    // // ---------------------------------------------------------
    // // Only process prefix sequence when invoice number exists
    // // ---------------------------------------------------------

    // if (invoiceNumber) {

    //   // Extract trailing numeric part.
    //   //
    //   // SAL1000
    //   //   prefix = SAL
    //   //   number = 1000
    //   //
    //   // INV100
    //   //   prefix = INV
    //   //   number = 100
    //   //
    //   // AEPL-2627-0086
    //   //   prefix = AEPL-2627-
    //   //   number = 0086
    //   //
    //   // 1000
    //   //   prefix = None
    //   //   number = 1000

    //   const invoiceMatch = invoiceNumber.match(/^(.*?)(\d+)$/);

    //   if (!invoiceMatch) {
    //     await connection.rollback();

    //     return res.status(400).json({
    //       success: false,
    //       message: "Invalid invoice number.",
    //     });
    //   }

    //   const invoicePrefix = invoiceMatch[1] || "None";
    //   const enteredInvoiceNumber = Number(invoiceMatch[2]);

    //   if (
    //     !Number.isInteger(enteredInvoiceNumber) ||
    //     enteredInvoiceNumber < 1
    //   ) {
    //     await connection.rollback();

    //     return res.status(400).json({
    //       success: false,
    //       message: "Invoice number must contain a valid positive number.",
    //     });
    //   }


    //   // -------------------------------------------------------
    //   // Find + LOCK the prefix row.
    //   //
    //   // Because addSale already started a transaction at the
    //   // beginning of this controller, FOR UPDATE keeps this
    //   // prefix row locked until commit/rollback.
    //   // -------------------------------------------------------

    //   const [prefixRows] = await connection.execute(
    //     `
    //     SELECT
    //       id,
    //       transaction_type,
    //       prefix_name,
    //       last_number,
    //       is_active
    //     FROM transactions_prefixes
    //     WHERE transaction_type = 'sale'
    //       AND prefix_name = ?
    //     LIMIT 1
    //     FOR UPDATE
    //     `,
    //     [invoicePrefix]
    //   );


    //   // -------------------------------------------------------
    //   // Prefix must exist.
    //   // -------------------------------------------------------

    //   if (prefixRows.length === 0) {
    //     await connection.rollback();

    //     return res.status(400).json({
    //       success: false,
    //       message: `Invoice prefix "${invoicePrefix}" does not exist.`,
    //     });
    //   }


    //   const prefixRow = prefixRows[0];

    //   const currentLastNumber =
    //     Number(prefixRow.last_number) || 0;


    //   // -------------------------------------------------------
    //   // IMPORTANT:
    //   //
    //   // NEVER decrease last_number.
    //   //
    //   // Example:
    //   //
    //   // last_number = 1000
    //   //
    //   // SAL1  -> stays 1000
    //   // SAL2  -> stays 1000
    //   // SAL3  -> stays 1000
    //   //
    //   // SAL1001 -> becomes 1001
    //   // -------------------------------------------------------

    //   if (enteredInvoiceNumber > currentLastNumber) {

    //     await connection.execute(
    //       `
    //       UPDATE transactions_prefixes
    //       SET last_number = ?
    //       WHERE id = ?
    //       `,
    //       [
    //         enteredInvoiceNumber,
    //         prefixRow.id,
    //       ]
    //     );
    //   }
    // }
    // =========================================================
    // INVOICE NUMBER + TRANSACTION PREFIX SEQUENCE
    // =========================================================

    const invoicePrefix =
      String(
        Invoice_Number_Prefix ?? ""
      ).trim() || "None";

    const invoiceValueString =
      String(
        Invoice_Number_Value ?? ""
      ).trim();

    let invoiceNumberValue = null;

    // ---------------------------------------------------------
    // Validate numeric invoice value
    // ---------------------------------------------------------

    if (invoiceValueString !== "") {

      if (!/^\d+$/.test(invoiceValueString)) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message:
            "Invoice number must contain only digits.",
        });
      }

      invoiceNumberValue =
        Number(invoiceValueString);
    }


    // ---------------------------------------------------------
    // Handle prefix sequence
    // ---------------------------------------------------------

    if (invoiceNumberValue !== null) {

      const [prefixRows] =
        await connection.execute(
          `
      SELECT
        id,
        transaction_type,
        prefix_name,
        last_number,
        is_active
      FROM transactions_prefixes
      WHERE transaction_type = 'sale'
        AND prefix_name = ?
      LIMIT 1
      FOR UPDATE
      `,
          [invoicePrefix]
        );

      if (prefixRows.length === 0) {

        await connection.rollback();

        return res.status(400).json({
          success: false,
          message:
            `Invoice prefix "${invoicePrefix}" does not exist.`,
        });
      }

      const prefixRow =
        prefixRows[0];

      const currentLastNumber =
        Number(prefixRow.last_number) || 0;

      // 0 is meaningless, so never update
      // the sequence to 0.
      if (
        invoiceNumberValue >
        currentLastNumber
      ) {

        await connection.execute(
          `
      UPDATE transactions_prefixes
      SET last_number = ?
      WHERE id = ?
      `,
          [
            invoiceNumberValue,
            prefixRow.id,
          ]
        );
      }
    }


    // =========================================================
    // BUILD LEGACY INVOICE NUMBER
    // =========================================================

    const invoiceNumber =
      buildLegacyInvoiceNumber(
        invoicePrefix,
        invoiceNumberValue
      );
    // =========================================================
    // CHECK INVOICE NUMBER UNIQUENESS
    // =========================================================

    if (invoiceNumber !== null) {

      const [duplicateRows] =
        await connection.execute(
          `
      SELECT id
      FROM add_sale
      WHERE Invoice_Number = ?
      LIMIT 1
      FOR UPDATE
      `,
          [invoiceNumber]
        );

      if (duplicateRows.length > 0) {

        await connection.rollback();

        return res.status(400).json({
          success: false,
          message:
            `Invoice number "${invoiceNumber}" already exists.`,
        });
      }
    }
    const [saleResult] = await connection.execute(
      `INSERT INTO add_sale
   (
      Party_Id,
      Billing_Name,
      Phone_Number,
      Billing_Address,
      Invoice_Number,
      Invoice_Number_Prefix,
      Invoice_Number_Value,
      Invoice_Date,
      Financial_Year,
      State_Of_Supply,
      Transaction_Discount_Percentage,
      Transaction_Discount_Amount,
      Total_Amount,
      Round_Off,
      Total_Received,
      Balance_Due,
      Terms_Conditions_Id,
      Terms_Conditions_Description,
      created_at,
      updated_at
   )
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [
        Party_Id,
        cleanValue(Billing_Name),
        cleanValue(Phone_Number),
        cleanValue(Billing_Address),

        invoiceNumber,
        invoicePrefix,
        invoiceNumberValue,

        Invoice_Date,
        activeFY,
        cleanValue(State_Of_Supply),
        cleanTransactionDiscountPercentage,
        cleanTransactionDiscountAmount,
        totalAmount,
        roundOffValue,
        totalReceived,
        balanceDue,
        termsId,
        termsDescription,
      ]
    );

    const saleIdNumber = saleResult.insertId;

    const newSaleId =
      "SAL" + saleIdNumber.toString().padStart(3, "0");

    await connection.execute(
      `UPDATE add_sale
       SET Sale_Id = ?
       WHERE id = ?`,
      [newSaleId, saleIdNumber]
    );

    // =========================================================
    // 10. PAYMENT SPLITS
    //
    // Use validSplits, NOT original splits, for BOTH modes.
    // Cash mode: validSplits sums exactly to totalAmount (enforced above),
    // so payment_splits/bank_transactions/cash_transactions stay
    // consistent with add_sale.Total_Received.
    // =========================================================
    // console.log("🔍 BEFORE INSERT PAYMENT SPLITS");
    // console.log("saleIdNumber:", saleIdNumber);
    // console.log("newSaleId:", newSaleId);
    // console.log("validSplits:", JSON.stringify(validSplits, null, 2));

    if (validSplits.length > 0) {
      await insertPaymentSplits({
        connection,
        sourceType: "Sale",
        sourceId: saleIdNumber,
        partyName: resolvedPartyName,
        txnDate: Invoice_Date,
        splits: validSplits,
      });
    }

    // =========================================================
    // 11. PARTY LEDGER
    // =========================================================

    await recordPartyLedger({
      connection,
      partyId: Party_Id,
      txnType: "Sale",
      referenceId: saleIdNumber,
      amount: totalAmount,
      txnDate: Invoice_Date,
      //docNumber: Invoice_Number,
      docNumber: invoiceNumber,
      balanceDue,
    });

    // =========================================================
    // 12. ITEMS — unchanged
    // =========================================================

    // =========================================================
    // 12. ITEMS — with unit resolution + snapshot logic
    // =========================================================

    for (const item of items || []) {

      if (!item.Item_Name?.trim()) {
        if ((normalizeNumber(item.Amount) ?? 0) > 0) {
          await connection.rollback();
          return res.status(400).json({
            success: false,
            message: "Please enter an item name for the row.",
          });
        }
        continue;
      }

      const {
        Item_Name,
        Item_HSN,
        Item_Category,
        Quantity,
        Free_Quantity,
        Item_Unit,
        MRP,
        Discount_On_MRP_For_Sale_Percentage,

        Sale_Price,
        Discount_On_Sale_Price,
        Discount_Type_On_Sale_Price,
        Tax_Type,
        Tax_Amount,
        Amount,
      } = item;
      const cleanFreeQuantity = Number(Free_Quantity) > 0 ? Number(Free_Quantity) : null;
      // UI calls the selected billing unit "Item_Unit"; backend calls it Selected_Unit
      const Selected_Unit = Item_Unit || null;

      const [itemRows] = await connection.execute(
        `SELECT * FROM add_item WHERE TRIM(Item_Name) = TRIM(?) LIMIT 1`,
        [Item_Name]
      );

      let Item_Id;
      let stockDelta;
      let snapshot = { Primary_Unit_Snapshot: null, Secondary_Unit_Snapshot: null };
      let resolvedSelectedUnit = null;

      if (itemRows.length === 0) {
        // =========================================================
        // CASE 1 — BRAND-NEW ITEM CREATED FROM SALE
        //
        // The selected transaction unit becomes the item's first Primary_Unit.
        // If Item_Unit is blank/NONE, everything stays NULL and raw quantity is used.
        // =========================================================

        const selectedUnit = Item_Unit || null;
        const primaryUnit = selectedUnit;

        const [itemResult] = await connection.execute(
          `
  INSERT INTO add_item
  (
    Item_Name,
    Item_HSN,
    Item_Unit,
    Item_Category,

    Primary_Unit,
    Secondary_Unit,
    Conversion_Rate,

    Sale_Price,

    Stock_Quantity,

    created_at,
    updated_at
  )
  VALUES
  (
    ?, ?, ?, ?,
    ?, ?, ?,
    ?,
    ?,
    NOW(), NOW()
  )
  `,
          [
            Item_Name.trim(),
            cleanValue(Item_HSN),

            // Legacy field
            Item_Unit || "",

            Item_Category || "",

            // Unit system
            primaryUnit,
            null,
            null,

            // ✅ Save latest sale price
            normalizeNumber(Sale_Price) ?? null,

            // Sale decreases stock
            //-(normalizeNumber(Quantity) ?? 0),
            -(
              (normalizeNumber(Quantity) ?? 0) +
              (cleanFreeQuantity ?? 0)
            )
          ]
        );

        const itemIdNum = itemResult.insertId;
        Item_Id = "ITM" + itemIdNum.toString().padStart(3, "0");

        await connection.execute(
          `UPDATE add_item SET Item_Id = ? WHERE id = ?`,
          [Item_Id, itemIdNum]
        );

        // Stock already applied above — don't add again below
        //stockDelta = normalizeNumber(Quantity) ?? 0;
        stockDelta =
          (normalizeNumber(Quantity) ?? 0) +
          (cleanFreeQuantity ?? 0);
        snapshot = {
          Primary_Unit_Snapshot: primaryUnit,
          Secondary_Unit_Snapshot: null,
        };

        resolvedSelectedUnit = selectedUnit;

      } else {
        // =========================================================
        // CASE 2 — EXISTING ITEM
        //
        // Never accept Primary_Unit/Secondary_Unit/Conversion_Rate from
        // the frontend — always resolve from the current add_item row,
        // exactly like addPurchase.
        // =========================================================

        Item_Id = itemRows[0].Item_Id;

        let dbItemRow = itemRows[0];
        if (
          !dbItemRow.Primary_Unit &&
          Selected_Unit
        ) {
          await connection.execute(
            `
    UPDATE add_item
    SET
      Primary_Unit = ?,
      Item_Unit = ?,
      updated_at = NOW()
    WHERE Item_Id = ?
    `,
            [
              Selected_Unit,
              Selected_Unit,
              Item_Id,
            ]
          );

          dbItemRow = {
            ...dbItemRow,
            Primary_Unit: Selected_Unit,
            Item_Unit: Selected_Unit,
          };
        }

        try {
          const result = resolveUnitAndStockDelta({
            dbItemRow,
            Selected_Unit,
            // Quantity,
            Quantity:
              (normalizeNumber(Quantity) ?? 0) +
              (cleanFreeQuantity ?? 0),
          });

          stockDelta = result.stockDelta;
          snapshot = result.snapshot;
          resolvedSelectedUnit = result.resolvedSelectedUnit;
        } catch (unitErr) {
          await connection.rollback();
          return res.status(400).json({ success: false, message: unitErr.message });
        }

        // Sale DECREASES stock — the only difference from addPurchase's "+"

        await connection.execute(
          `
  UPDATE add_item
  SET
    Stock_Quantity = Stock_Quantity - ?,
    Item_HSN = ?,
    Item_Category = ?,

    -- ✅ Keep latest sale price in item master
    Sale_Price = ?,

    updated_at = NOW()
  WHERE Item_Id = ?
  `,
          [
            stockDelta,

            cleanValue(Item_HSN) || dbItemRow.Item_HSN,

            Item_Category || "",

            // ✅ Latest sale price
            normalizeNumber(Sale_Price) ?? null,

            Item_Id,
          ]
        );
      }

      const safeTaxType = Tax_Type || "None";

      const [saleItemResult] = await connection.execute(
        `INSERT INTO add_sale_items
     (Sale_Id, Item_Id, Quantity,Free_Quantity, MRP,Discount_On_MRP_For_Sale_Percentage ,Sale_Price,
      Discount_On_Sale_Price, Discount_Type_On_Sale_Price,
      Tax_Type, Tax_Amount, Amount,
      Primary_Unit_Snapshot, Secondary_Unit_Snapshot, Selected_Unit,
      created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?,?,?,?, ?, ?, ?, ?, ?, NOW(), NOW())`,
        [
          newSaleId,
          Item_Id,
          normalizeNumber(Quantity) ?? 0,
          cleanFreeQuantity,
          //normalizeNumber(Free_Quantity) ?? null,
          normalizeNumber(MRP) || null,
          normalizeNumber(Discount_On_MRP_For_Sale_Percentage) || null,
          normalizeNumber(Sale_Price) ?? 0,
          cleanDiscount(Discount_On_Sale_Price),
          cleanValue(Discount_Type_On_Sale_Price),
          cleanValue(safeTaxType),
          normalizeNumber(Tax_Amount) ?? 0,
          normalizeNumber(Amount) ?? 0,
          snapshot.Primary_Unit_Snapshot,
          snapshot.Secondary_Unit_Snapshot,
          resolvedSelectedUnit,
        ]
      );

      const saleItemIdNum = saleItemResult.insertId;
      const newSaleItemId = "SIT" + saleItemIdNum.toString().padStart(3, "0");

      await connection.execute(
        `UPDATE add_sale_items SET Sale_Items_Id = ? WHERE id = ?`,
        [newSaleItemId, saleItemIdNum]
      );
      await connection.execute(
        `
  UPDATE add_item
  SET
    Item_Unit = ?,
    Primary_Unit = ?,
    Secondary_Unit = ?
  WHERE Item_Id = ?
  `,
        [
          resolvedSelectedUnit || null,
          snapshot.Primary_Unit_Snapshot || null,
          snapshot.Secondary_Unit_Snapshot || null,
          Item_Id,
        ]
      );
      await syncUnitIdsForItem(
        connection,
        Item_Id
      );

      await syncUnitIdsForSaleItem(connection, {
        saleItemRowId: saleItemIdNum,
        Primary_Unit_Snapshot: snapshot.Primary_Unit_Snapshot,
        Secondary_Unit_Snapshot: snapshot.Secondary_Unit_Snapshot,
        Selected_Unit: resolvedSelectedUnit,
      });
      await recordItemLedger({
        connection,
        itemId: Item_Id,
        txnType: "Sale",
        referenceId: saleItemIdNum,
        billId: newSaleId,
        //billNumber: Invoice_Number,
        billNumber: invoiceNumber,
        partyName: Party_Name,
        quantity: normalizeNumber(Quantity) ?? 0,
        freeQuantity: cleanFreeQuantity,   // user-entered: e.g. 500
        //freeQuantity: normalizeNumber(Free_Quantity) ?? null,
        selectedUnit: resolvedSelectedUnit,               // 🔹 e.g. "Gm"
        baseQty: stockDelta,                         // 🔹 normalized: e.g. 0.5
        rate: normalizeNumber(Sale_Price) ?? null,
        txnDate: Invoice_Date,
      });
    }

    // =========================================================
    // 19. COMMIT
    // =========================================================

    await connection.commit();

    return res.status(201).json({
      success: true,
      message: "Sale and items added successfully",
      saleId: newSaleId,
    });

  } catch (err) {

    if (connection) {
      await connection.rollback();
    }

    console.error("❌ Error adding sale:", err);

    next(err);

  } finally {

    if (connection) {
      connection.release();
    }
  }
};

const addInvoice = async (req, res, next) => {

  let connection;
  try {
    const { Invoice_Name } = req.body;
    connection = await db.getConnection();
    await connection.beginTransaction();
    const newInvoice = await db.execute(
      `INSERT INTO add_invoice (Invoice_Name, created_at, updated_at) VALUES (?, NOW(), NOW())`,
      [Invoice_Name]
    );

    await connection.commit();
    return res.status(201).json(
      {
        success: true,
        message: "Invoice added successfully",
        invoiceId: newInvoice[0].insertId,
      }
    )
  }
  catch (err) {
    if (connection) await connection.rollback();
    console.error("❌ Error adding invoice:", err);
    next(err);
    // return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    if (connection) connection.release();
  }
}
const updateInvoice = async (req, res, next) => {
  let connection;


  try {
    const { Invoice_Name, id } = req.body;
    connection = await db.getConnection();
    await connection.beginTransaction();
    const newInvoice = await db.execute(
      `UPDATE add_invoice SET Invoice_Name=? WHERE id=?`,
      [Invoice_Name, id]
    );

    await connection.commit();
    return res.status(201).json(
      {
        success: true,
        message: "Invoice updated successfully",
        invoiceId: newInvoice[0].insertId,
      }
    )
  } catch (err) {
    if (connection) await connection.rollback();
    console.error("❌ Error updating invoice:", err);
    next(err);
    // return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    if (connection) connection.release();
  }
}
const getSingleInvoice = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();
    const [rows] = await db.query("SELECT * FROM add_invoice");

    // 🧠 If no invoice exists yet (first-time user)
    if (rows.length === 0) {
      return res.status(200).json({
        success: true,
        invoice: null,
        message: "No invoice found. You can create your first invoice prefix.",
      });
    }

    // ✅ Return the existing invoice (only one per user)
    return res.status(200).json({
      success: true,
      invoice: rows[0],
    });
  } catch (err) {
    if (connection) connection.release();
    console.error("❌ Error getting invoice:", err);
    next(err);
    //return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    if (connection) connection.release();
  }
};


const getAllSales = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    /* ---------- PAGINATION ---------- */

    const limit = Math.min(
      parseInt(req.query.limit, 10) || 10,
      200
    );

    let cursorDate = null;
    let cursorId = null;

    if (req.query.cursor) {
      try {
        const decoded = JSON.parse(
          Buffer.from(req.query.cursor, "base64").toString("utf8")
        );

        cursorDate = decoded.date || null;
        cursorId =
          decoded.id !== undefined && decoded.id !== null
            ? Number(decoded.id)
            : null;

        if (
          !cursorDate ||
          !Number.isInteger(cursorId) ||
          cursorId <= 0
        ) {
          return res.status(400).json({
            success: false,
            message: "Invalid cursor.",
          });
        }
      } catch {
        return res.status(400).json({
          success: false,
          message: "Invalid cursor.",
        });
      }
    }

    /* ---------- FILTERS ---------- */

    const search =
      req.query.search?.trim().toLowerCase() || "";

    const fromDate = req.query.fromDate || null;
    const toDate = req.query.toDate || null;

    const filterClauses = [];
    const filterParams = [];

    /* ---------- SEARCH ---------- */

    if (search) {
      const like = `%${search}%`;

      filterClauses.push(`(
        a.Party_Name LIKE ?
        OR CAST(s.Total_Amount AS CHAR) LIKE ?
        OR CAST(s.Balance_Due AS CHAR) LIKE ?
        OR s.Invoice_Number LIKE ?
      )`);

      filterParams.push(
        like,
        like,
        like,
        like
      );
    }

    /* ---------- DATE FILTER ---------- */

    if (fromDate && toDate) {
      filterClauses.push(`
        DATE(s.Invoice_Date) BETWEEN ? AND ?
      `);

      // filterParams.push(
      //   `${fromDate} 00:00:00`,
      //   `${toDate} 23:59:59`
      // );

         filterParams.push(
        fromDate,
        toDate
      );

    } else if (fromDate) {
      filterClauses.push(`
        DATE(s.Invoice_Date) >= ?
      `);
       filterParams.push(fromDate);


      // filterParams.push(
      //   `${fromDate} 00:00:00`
      // );

    } else if (toDate) {
      filterClauses.push(`
        DATE(s.Invoice_Date) <= ?
      `);
         filterParams.push(toDate);

      // filterParams.push(
      //   `${toDate} 23:59:59`
      // );
    }

    /* ---------- CURSOR ---------- */

    const cursorClauses = [];
    const cursorParams = [];

    if (cursorDate !== null && cursorId !== null) {
      cursorClauses.push(`
        (
          s.Invoice_Date < ?
          OR (
            s.Invoice_Date = ?
            AND s.id < ?
          )
        )
      `);

      cursorParams.push(
        cursorDate,
        cursorDate,
        cursorId
      );
    }

    /* ---------- MAIN WHERE ---------- */

    const mainWhereClauses = [
      ...filterClauses,
      ...cursorClauses,
    ];

    const mainWhereSQL = mainWhereClauses.length
      ? `WHERE ${mainWhereClauses.join(" AND ")}`
      : "";

    const mainParams = [
      ...filterParams,
      ...cursorParams,
    ];

    /* ---------- MAIN QUERY ---------- */

    const [rows] = await connection.query(
      `
        SELECT
          s.*,
          a.Party_Name,
          DATE_FORMAT(s.Invoice_Date, '%Y-%m-%d %H:%i:%s') AS Invoice_Date_Raw

        FROM add_sale s

        LEFT JOIN add_party a
          ON s.Party_Id = a.Party_Id

        ${mainWhereSQL}

        ORDER BY
          s.Invoice_Date DESC,
          s.id DESC

        LIMIT ?
      `,
      [
        ...mainParams,
        limit + 1,
      ]
    );

    /* ---------- hasMore ---------- */

    const hasMore = rows.length > limit;

    const pageRows = hasMore
      ? rows.slice(0, limit)
      : rows;

    /* ---------- NEXT CURSOR ---------- */

    let nextCursor = null;

    if (hasMore && pageRows.length > 0) {
      const lastRow =
        pageRows[pageRows.length - 1];

      nextCursor = Buffer.from(
        JSON.stringify({
          //date: lastRow.Invoice_Date,
          date: lastRow.Invoice_Date_Raw,
          id: lastRow.id,
        })
      ).toString("base64");
    }

    /* ---------- PAYMENT SPLITS ---------- */

    if (pageRows.length > 0) {
      const saleIds = pageRows.map(
        (row) => row.id
      );

      const placeholders = saleIds
        .map(() => "?")
        .join(",");

      const [splits] = await connection.query(
        `
          SELECT
            ps.Source_Id,
            ps.Payment_Type,
            ba.Account_Display_Name

          FROM payment_splits ps

          LEFT JOIN bank_accounts ba
            ON ba.id = ps.Bank_Account_Id

          WHERE ps.Source_Type = 'Sale'
            AND ps.Source_Id IN (${placeholders})
        `,
        saleIds
      );

      const splitMap = {};

      for (const split of splits) {
        if (!splitMap[split.Source_Id]) {
          splitMap[split.Source_Id] = [];
        }

        splitMap[split.Source_Id].push(
          split.Payment_Type === "Bank"
            ? split.Account_Display_Name
            : split.Payment_Type
        );
      }

      for (const row of pageRows) {
        const labels =
          splitMap[row.id] || [];

        const counts = {};

        for (const label of labels) {
          counts[label] =
            (counts[label] || 0) + 1;
        }

        row.Payment_Type_Display =
          Object.entries(counts)
            .map(([label, count]) =>
              count > 1
                ? `${label} (x${count})`
                : label
            )
            .join(" , ") || "—";
      }
    }

    /* ---------- COUNT + TOTALS ---------- */

    const countWhereSQL = filterClauses.length
      ? `WHERE ${filterClauses.join(" AND ")}`
      : "";

    const [[combined]] =
      await connection.query(
        `
          SELECT
            COUNT(*) AS total,

            COALESCE(
              SUM(s.Total_Amount),
              0
            ) AS totalAmount,

            COALESCE(
              SUM(s.Balance_Due),
              0
            ) AS totalBalance,

            COALESCE(
              SUM(s.Total_Received),
              0
            ) AS totalReceived

          FROM add_sale s

          LEFT JOIN add_party a
            ON s.Party_Id = a.Party_Id

          ${countWhereSQL}
        `,
        filterParams
      );

    /* ---------- RESPONSE ---------- */

    return res.status(200).json({
      success: true,
      sales: pageRows,
      hasMore,
      nextCursor,
      totalSales: combined.total,
      totals: {
        totalAmount: combined.totalAmount,
        totalBalance: combined.totalBalance,
        totalReceived: combined.totalReceived,
      },
    });

  } catch (err) {
    console.error(
      "❌ Error fetching sales:",
      err
    );

    next(err);

  } finally {
    if (connection) {
      connection.release();
    }
  }
};
const exportAllSalesReportToExcel = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();

    const search = req.query.search ? req.query.search.trim().toLowerCase() : "";
    const fromDate = req.query.fromDate || null;
    const toDate = req.query.toDate || null;

    const whereClauses = [];
    const params = [];

    if (search) {
      whereClauses.push(`
        (LOWER(a.Party_Name)   LIKE ? OR
         LOWER(s.Payment_Type) LIKE ? OR
         CAST(s.Total_Amount  AS CHAR) LIKE ? OR
         CAST(s.Balance_Due   AS CHAR) LIKE ?)
      `);
      const like = `%${search}%`;
      params.push(like, like, like, like);
    }

    if (fromDate && toDate) {
      whereClauses.push(`s.Invoice_Date BETWEEN ? AND ?`);
      params.push(`${fromDate} 00:00:00`, `${toDate} 23:59:59`);
    } else if (fromDate) {
      whereClauses.push(`s.Invoice_Date >= ?`);
      params.push(`${fromDate} 00:00:00`);
    } else if (toDate) {
      whereClauses.push(`s.Invoice_Date <= ?`);
      params.push(`${toDate} 23:59:59`);
    }

    const whereSQL = whereClauses.length ? `WHERE ${whereClauses.join(" AND ")}` : "";

    const [rows] = await connection.query(
      `SELECT s.*, a.Party_Name, a.GSTIN
       FROM add_sale s
       LEFT JOIN add_party a ON s.Party_Id = a.Party_Id
       ${whereSQL}
       ORDER BY s.Invoice_Date DESC`,
      params
    );

    const [[totals]] = await connection.query(
      `SELECT
         COALESCE(SUM(s.Total_Amount),   0) AS totalAmount,
         COALESCE(SUM(s.Balance_Due),    0) AS totalBalance,
         COALESCE(SUM(s.Total_Received), 0) AS totalReceived
       FROM add_sale s
       LEFT JOIN add_party a ON s.Party_Id = a.Party_Id
       ${whereSQL}`,
      params
    );

    /* ════════════════════════════════════════════════════════
       BUILD WORKBOOK
    ════════════════════════════════════════════════════════ */
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Sale Report");
    const itemSheet = workbook.addWorksheet("Item Details");

    /* ── palette — pure black & white, no color fills ── */
    const WHITE = "FFFFFFFF";
    const BLACK = "FF000000";
    const STAMP_CLR = "FF595959";

    /* ── 8 columns ── */
    sheet.columns = [
      { key: "date", width: 14 },   // A
      { key: "invoice", width: 18 },   // B
      { key: "party", width: 34 },   // C
      { key: "gstin", width: 22 },   // D
      { key: "amount", width: 16 },   // E  Total Amount
      { key: "payment", width: 14 },   // F  Payment Type
      { key: "received", width: 20 },   // G  Received/Paid
      { key: "balance", width: 16 },   // H  Balance Due
    ];

    const LAST_COL = "H";
    const TOTAL_COLS = 8;

    /* ─── ROW 1 : report title ─── */
    sheet.mergeCells(`A1:${LAST_COL}1`);
    const titleCell = sheet.getCell("A1");
    titleCell.value = "SALES REPORT";
    titleCell.font = { name: "Calibri", bold: true, size: 14, color: { argb: BLACK } };
    titleCell.alignment = { horizontal: "center", vertical: "middle" };
    sheet.getRow(1).height = 28;

    /* ─── ROW 2 : generated-on stamp ─── */
    sheet.mergeCells(`A2:${LAST_COL}2`);
    const generatedOn = new Date().toLocaleString("en-IN", {
      day: "2-digit", month: "2-digit", year: "numeric",
      hour: "2-digit", minute: "2-digit", hour12: true,
    });
    const stampCell = sheet.getCell("A2");
    stampCell.value = `Generated on ${generatedOn}`;
    stampCell.font = { name: "Calibri", size: 10, italic: true, color: { argb: STAMP_CLR } };
    stampCell.alignment = { horizontal: "left", vertical: "middle" };
    sheet.getRow(2).height = 18;

    /* ─── ROW 3 : blank spacer ─── */
    sheet.addRow([]);
    sheet.getRow(3).height = 6;

    /* ─── ROW 4 : column headers ─── */
    const HEADERS = [
      "Date", "Invoice No", "Party Name", "GSTIN",
      "Total Amount", "Payment Type", "Received/Paid Amount", "Balance Due",
    ];

    const headerRow = sheet.addRow(HEADERS);
    headerRow.eachCell((cell) => {
      cell.font = { name: "Calibri", bold: true, size: 10, color: { argb: BLACK } };
      cell.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
      cell.border = {
        top: { style: "thin", color: { argb: BLACK } },
        left: { style: "thin", color: { argb: BLACK } },
        bottom: { style: "thin", color: { argb: BLACK } },
        right: { style: "thin", color: { argb: BLACK } },
      };
    });
    sheet.getRow(headerRow.number).height = 22;

    /* ─── DATA ROWS (start row 5) ─── */
    const FIRST_DATA = 5;
    rows.forEach((sale) => {
      const dataRow = sheet.addRow([
        sale.Invoice_Date
          ? new Date(sale.Invoice_Date).toLocaleDateString("en-IN", {
            day: "2-digit", month: "2-digit", year: "numeric",
          })
          : "N/A",
        sale.Invoice_Number || "N/A",
        sale.Party_Name || "N/A",
        sale.GSTIN || "",
        Number(sale.Total_Amount || 0),
        sale.Payment_Type || "N/A",
        Number(sale.Total_Received || 0),
        Number(sale.Balance_Due || 0),
      ]);

      dataRow.eachCell({ includeEmpty: true }, (cell, colNumber) => {
        cell.font = { name: "Calibri", size: 10, color: { argb: BLACK } };
        cell.alignment = { vertical: "middle" };
        cell.border = {
          top: { style: "hair", color: { argb: BLACK } },
          left: { style: "hair", color: { argb: BLACK } },
          bottom: { style: "hair", color: { argb: BLACK } },
          right: { style: "hair", color: { argb: BLACK } },
        };

        /* numeric columns: E(5) G(7) H(8) */
        if (colNumber === 5 || colNumber === 7 || colNumber === 8) {
          cell.numFmt = "₹#,##0.00";
          cell.alignment = { horizontal: "right", vertical: "middle" };
        }

        /* emphasize non-zero Balance Due — bold only, no color */
        if (colNumber === 8 && Number(sale.Balance_Due || 0) > 0) {
          cell.font = { name: "Calibri", size: 10, color: { argb: BLACK }, bold: true };
        }
      });

      dataRow.height = 18;
    });

    /* ─── TOTAL ROW ─── */
    const lastDataRow = sheet.rowCount;

    const totalRow = sheet.addRow([
      "", "", "", "TOTAL",
      { formula: `SUM(E${FIRST_DATA}:E${lastDataRow})` },
      "",
      { formula: `SUM(G${FIRST_DATA}:G${lastDataRow})` },
      { formula: `SUM(H${FIRST_DATA}:H${lastDataRow})` },
    ]);

    totalRow.eachCell({ includeEmpty: true }, (cell, colNumber) => {
      cell.font = { name: "Calibri", bold: true, size: 11, color: { argb: BLACK } };
      cell.alignment = { horizontal: "right", vertical: "middle" };
      cell.border = {
        top: { style: "medium", color: { argb: BLACK } },
        left: { style: "thin", color: { argb: BLACK } },
        bottom: { style: "medium", color: { argb: BLACK } },
        right: { style: "thin", color: { argb: BLACK } },
      };
      if (colNumber === 5 || colNumber === 7 || colNumber === 8) {
        cell.numFmt = "₹#,##0.00";
      }
      if (colNumber === 4) cell.alignment = { horizontal: "right", vertical: "middle" };
    });
    totalRow.height = 24;

    /* ─── freeze top 4 rows (title + stamp + spacer + header) ─── */
    sheet.views = [{ state: "frozen", ySplit: 4 }];

    /* ─── Item Details sheet placeholder ─── */
    itemSheet.columns = [{ width: 30 }];
    itemSheet.addRow(["Item-level detail export — coming soon"]);

    /* ════════════════════════════════════════════════════════
       STREAM TO CLIENT
    ════════════════════════════════════════════════════════ */
    const label = fromDate && toDate
      ? `SaleReport_${fromDate}_to_${toDate}`
      : `SaleReport_${new Date().toISOString().slice(0, 10)}`;

    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${label}.xlsx"`
    );

    await workbook.xlsx.write(res);
    res.end();

  } catch (err) {
    console.error("❌ Excel export error:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};

//     (
//   SELECT pa.Address_Text
//   FROM add_party_addresses pa
//   WHERE pa.Party_Id = s.Party_Id
//     AND pa.Address_Type = 'Billing'
//     AND pa.Is_Default = 1
// ) AS Billing_Address,
const getSingleSale = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();
    const { Sale_Id: saleId } = req.params;
    //console.log("🔍 Params =>", { saleId });

    if (!saleId) {
      return res.status(400).json({ success: false, message: "Sale ID is required." });
    }
    //  p.Party_Name,
    //      p.GSTIN,
    //    (
    //   SELECT pa.Address_Text
    //   FROM add_party_addresses pa
    //   WHERE pa.Party_Id = s.Party_Id
    //     AND pa.Address_Type = 'Billing'
    //   ORDER BY pa.Is_Default DESC, pa.id ASC
    //   LIMIT 1
    // ) AS Billing_Address,
    const isSaleForItemSale = saleId.startsWith("SAL");
    // const salesTable    = isSaleForItemSale ? "add_new_sale"       : "add_sale";
    // const saleItemTable = isSaleForItemSale ? "add_new_sale_items" : "add_sale_items";
    // const itemTable     = isSaleForItemSale ? "add_item_sale"      : "add_item";

    const salesTable = isSaleForItemSale ? "add_sale" : "add_sale";
    const saleItemTable = isSaleForItemSale ? "add_sale_items" : "add_sale_items";
    const itemTable = isSaleForItemSale ? "add_item" : "add_item";

    const [saleData] = await connection.query(
      `SELECT
     s.id,
     s.Sale_Id,
     s.Phone_Number,
     s.Billing_Name,
     s.Billing_Address,
     s.Invoice_Number,
     s.Invoice_Number_Prefix,
     s.Invoice_Number_Value,
     s.Invoice_Date,
     s.State_Of_Supply,
     s.Total_Amount,
     s.Round_Off,
     s.Total_Received,
     s.Balance_Due,
     s.Party_Id,

     -- Terms saved on this invoice
     s.Terms_Conditions_Id,
     s.Terms_Conditions_Description,
     s.Transaction_Discount_Percentage,
        s.Transaction_Discount_Amount,

     -- Party master   p.Phone_Number
         p.Party_Name,
    p.GSTIN,
    p.State,
    p.Phone_Number AS Party_Phone_Number,
  
    
     COALESCE(
       NULLIF(s.Billing_Address, ''),
       (
         SELECT pa.Address_Text
         FROM add_party_addresses pa
         WHERE pa.Party_Id = s.Party_Id
           AND pa.Address_Type = 'Billing'
           AND pa.Is_Default = 1
         ORDER BY pa.id ASC
         LIMIT 1
       )
     ) AS Billing_Address,

     -- Title only exists when this invoice is linked
     -- to a master Terms & Conditions template
     tc.Title AS Terms_Conditions_Title

   FROM ${salesTable} s

   LEFT JOIN add_party p
     ON s.Party_Id = p.Party_Id

   LEFT JOIN terms_conditions tc
     ON s.Terms_Conditions_Id = tc.id

   WHERE s.Sale_Id = ?`,
      [saleId]
    );

    if (!saleData.length) {
      return res.status(404).json({ success: false, message: "Sale not found." });
    }

    const saleHeader = saleData[0];
    console.log(saleHeader)



    //   const [items] = await connection.query(
    //     `
    // SELECT
    //   si.Sale_Items_Id,
    //   si.Item_Id,

    //   i.Item_Name,
    //   i.Item_HSN,
    //   i.Item_Unit,
    //   i.Item_Category,

    //   -- CURRENT ITEM MASTER
    //   i.Primary_Unit AS Current_Primary_Unit,
    //   i.Secondary_Unit AS Current_Secondary_Unit,
    //   i.Conversion_Rate,

    //   si.Quantity,

    //   -- HISTORICAL SALE SNAPSHOT (FROM IDS)
    //   pu1.Unit_Shorthand AS Primary_Unit_Snapshot,
    //   pu2.Unit_Shorthand AS Secondary_Unit_Snapshot,
    //   pu3.Unit_Shorthand AS Selected_Unit,

    //   si.Sale_Price,
    //   si.Discount_On_Sale_Price,
    //   si.Discount_Type_On_Sale_Price,
    //   si.Tax_Amount,
    //   si.Tax_Type,
    //   si.Amount,
    //   si.created_at

    // FROM ${saleItemTable} si

    // LEFT JOIN ${itemTable} i
    //   ON si.Item_Id = i.Item_Id

    // LEFT JOIN units pu1
    //   ON pu1.id = si.Primary_Unit_Snapshot_Id

    // LEFT JOIN units pu2
    //   ON pu2.id = si.Secondary_Unit_Snapshot_Id

    // LEFT JOIN units pu3
    //   ON pu3.id = si.Selected_Unit_Id

    // WHERE si.Sale_Id = ?

    // ORDER BY si.created_at DESC
    // `,
    //     [saleId]
    //   );
    const [items] = await connection.query(
      `
  SELECT
    si.Sale_Items_Id,
    si.Item_Id,

    i.Item_Name,
    i.Item_HSN,
    i.Item_Category,
    i.Item_Type,
    i.Discount_On_MRP_For_Sale AS Current_MRP_Discount,

    -- CURRENT ITEM MASTER UNITS FROM IDs
    iu.Unit_Shorthand AS Item_Unit,
    cpu.Unit_Shorthand AS Current_Primary_Unit,
    csu.Unit_Shorthand AS Current_Secondary_Unit,

    i.Conversion_Rate,

    si.Quantity,
    si.Free_Quantity,

    -- HISTORICAL SALE SNAPSHOT (FROM IDS)
    pu1.Unit_Shorthand AS Primary_Unit_Snapshot,
    pu2.Unit_Shorthand AS Secondary_Unit_Snapshot,
    pu3.Unit_Shorthand AS Selected_Unit,
      si.MRP,
      si.Discount_On_MRP_For_Sale_Percentage,
    si.Sale_Price,
    si.Discount_On_Sale_Price,
    si.Discount_Type_On_Sale_Price,
    si.Tax_Amount,
    si.Tax_Type,
    si.Amount,
    si.created_at

  FROM ${saleItemTable} si

  LEFT JOIN ${itemTable} i
    ON si.Item_Id = i.Item_Id

  -- HISTORICAL TRANSACTION UNITS
  LEFT JOIN units pu1
    ON pu1.id = si.Primary_Unit_Snapshot_Id

  LEFT JOIN units pu2
    ON pu2.id = si.Secondary_Unit_Snapshot_Id

  LEFT JOIN units pu3
    ON pu3.id = si.Selected_Unit_Id

  -- CURRENT MASTER UNITS
  LEFT JOIN units cpu
    ON i.Primary_Unit_Id = cpu.id

  LEFT JOIN units csu
    ON i.Secondary_Unit_Id = csu.id

  LEFT JOIN units iu
    ON i.Item_Unit_Id = iu.id

  WHERE si.Sale_Id = ?

  ORDER BY si.created_at DESC
  `,
      [saleId]
    );
    // if (!items.length) {
    //   return res.status(404).json({ success: false, message: "No sale items found for this invoice." });
    // }
    const [allUnits] = await connection.query(
      `
  SELECT
    Unit_Shorthand,
    Unit_Name
  FROM units
  ORDER BY Unit_Name ASC
  `
    );
    const formattedItems = items.map((it) => {
      const oldPrimary =
        it.Primary_Unit_Snapshot || null;

      const oldSecondary =
        it.Secondary_Unit_Snapshot || null;

      const oldSelected =
        it.Selected_Unit || null;

      const currentPrimary =
        it.Current_Primary_Unit || null;

      const currentSecondary = it.Current_Secondary_Unit || null;

      const hasHistoricalMRP = it.MRP !== null && Number(it.MRP) > 0;
      const hasHistoricalFreeQuantity = it.Free_Quantity !== null && Number(it.Free_Quantity) > 0;
      const price = Number(it.Sale_Price || 0);

      let discountAmount = 0;

      if (Number(it.Discount_On_Sale_Price || 0) > 0) {
        if (it.Discount_Type_On_Sale_Price === "Percentage") {
          discountAmount =
            (price * Number(it.Discount_On_Sale_Price)) / 100;
        } else {
          discountAmount = Number(
            it.Discount_On_Sale_Price
          );
        }
      }
      // =====================================================
      // DID THIS OLD SALE ACTUALLY USE THE OLD SECONDARY?
      // =====================================================
      //
      // Old snapshot:
      // KG / GM
      //
      // Selected:
      // GM
      //
      // => true
      // =====================================================

      const oldUsedSecondary =
        oldSecondary &&
        oldSelected === oldSecondary;


      let unitCodes = [];


      // =====================================================
      // CASE 1
      // OLD SALE USED SECONDARY
      //
      // Old sale:
      // KG / GM
      // selected GM
      //
      // Current master:
      // KG / BOX
      //
      // EDIT OLD SALE SHOW:
      // KG / GM
      // =====================================================

      if (oldUsedSecondary) {
        unitCodes = [
          oldPrimary,
          oldSecondary,
        ].filter(Boolean);
      }


      // =====================================================
      // CASE 2
      // OLD SALE USED PRIMARY
      //
      // Old sale:
      // KG / GM
      // selected KG
      //
      // Current master:
      // KG / BOX
      //
      // EDIT OLD SALE SHOW:
      // KG / BOX
      // =====================================================

      else {
        unitCodes = [
          currentPrimary,
          currentSecondary,
        ].filter(Boolean);
      }


      // Remove duplicate units
      unitCodes = [...new Set(unitCodes)];


      // =====================================================
      // CREATE Available_Units
      // =====================================================

      const availableUnits = unitCodes.map((unitCode) => {
        const masterUnit = allUnits.find(
          (unit) =>
            unit.Unit_Shorthand === unitCode
        );

        return {
          Unit_Shorthand: unitCode,
          Unit_Name:
            masterUnit?.Unit_Name || unitCode,
        };
      });


      return {
        Sale_Items_Id: it.Sale_Items_Id,

        Item_Id: it.Item_Id,

        Item_Name: it.Item_Name,

        Item_HSN: it.Item_HSN,
        Item_Type:it.Item_Type,

        // Legacy field
        Item_Unit: it.Item_Unit,

        Item_Category: it.Item_Category,

        Quantity: it.Quantity,

        Free_Quantity: it.Free_Quantity,

        hasHistoricalFreeQuantity,



        // ================================================
        // HISTORICAL TRANSACTION UNIT DATA
        // ================================================

        Primary_Unit:
          it.Primary_Unit_Snapshot,

        Secondary_Unit:
          it.Secondary_Unit_Snapshot,

        Selected_Unit: it.Selected_Unit,
        Conversion_Rate: it.Conversion_Rate !== null
          ? Number(it.Conversion_Rate)
          : 0,
        // What Edit Sale dropdown should display
        Available_Units: availableUnits,


        // ================================================
        // PRICE / TAX
        // ================================================
        MRP: it.MRP,
        Discount_On_MRP_For_Sale_Percentage: it.Discount_On_MRP_For_Sale_Percentage,
        // CURRENT MASTER VALUE
        Current_MRP_Discount: it.Current_MRP_Discount,
        hasHistoricalMRP,

        Sale_Price: it.Sale_Price,

        Discount_On_Sale_Price: it.Discount_On_Sale_Price,

        Discount_Type_On_Sale_Price:
          it.Discount_Type_On_Sale_Price,
        Discount_Amount: Number(
          discountAmount.toFixed(2)
        ),

        Tax_Amount: it.Tax_Amount,

        Tax_Type: it.Tax_Type || "None",

        Amount:
          it.Amount,

        created_at:
          it.created_at,
      };
    });
    // 🔹 fetch splits with bank display name
    const [splits] = await connection.query(
      `SELECT ps.*, ba.Account_Display_Name
       FROM payment_splits ps
       LEFT JOIN bank_accounts ba ON ba.id = ps.Bank_Account_Id
       WHERE ps.Source_Type = 'Sale' AND ps.Source_Id = ?
       ORDER BY ps.id ASC`,
      [saleHeader.id]   // numeric id — add to SELECT if not already there
    );
    // console.log("🔍 SALE SPLIT DEBUG");
    // console.log("saleId param:", saleId);
    // console.log("saleHeader.id:", saleHeader.id);
    // console.log("splits:", splits);
    // build a display summary for the header (e.g. "Cash + HDFC")
    const splitLabels = splits.map((s) =>
      s.Payment_Type === "Bank" ? s.Account_Display_Name : s.Payment_Type
    );
    const counts = {};
    splitLabels.forEach((l) => (counts[l] = (counts[l] || 0) + 1));
    const Payment_Type_Display = Object.entries(counts)
      .map(([label, count]) => (count > 1 ? `${label} (x${count})` : label))
      .join(" + ");

    return res.status(200).json({
      success: true,

      invoicePartyDetails: {
        Sale_Id: saleHeader.Sale_Id,
        Party_Name: saleHeader.Party_Name,
        Billing_Name: saleHeader.Billing_Name,
        Phone_Number: saleHeader.Phone_Number || saleHeader.Party_Phone_Number||"",
        Billing_Address: saleHeader.Billing_Address,
          addresses: saleHeader.Billing_Address
    ? [
        {
          Address_Type: "Billing",
          Address_Text: saleHeader.Billing_Address,
          Is_Default: true,
        },
      ]
    : [],
        GSTIN: saleHeader.GSTIN,
        State_Of_Supply: saleHeader.State_Of_Supply,
        State: saleHeader.State,
        //Reference_Number: saleHeader.Reference_Number,
        Payment_Type_Display,
        Invoice_Number: saleHeader.Invoice_Number,
        Invoice_Number_Prefix: saleHeader.Invoice_Number_Prefix,
        Invoice_Number_Value: saleHeader.Invoice_Number_Value,
        Invoice_Date: saleHeader.Invoice_Date,
        Total_Amount: saleHeader.Total_Amount,
        Round_Off: saleHeader.Round_Off,
        Total_Received: saleHeader.Total_Received,
        Balance_Due: saleHeader.Balance_Due,
        Terms_Conditions_Id: saleHeader.Terms_Conditions_Id,
        Terms_Conditions_Description: saleHeader.Terms_Conditions_Description,
        Transaction_Discount_Percentage: saleHeader.Transaction_Discount_Percentage,
        Transaction_Discount_Amount: saleHeader.Transaction_Discount_Amount

      },

      splits: splits.map((split) => ({
        Id: split.id,
        Payment_Type: split.Payment_Type,
        Bank_Account_Id: split.Bank_Account_Id,
        Account_Display_Name: split.Account_Display_Name,
        Reference_Number: split.Reference_Number,
        Amount: split.Amount,
      })),
      items: formattedItems,
      // items: items.map((it) => ({
      //   Sale_Items_Id: it.Sale_Items_Id,
      //   Item_Id: it.Item_Id,
      //   Item_Name: it.Item_Name,
      //   Item_HSN: it.Item_HSN,
      //   Item_Unit: it.Item_Unit,
      //   Item_Category: it.Item_Category,
      //   Quantity: it.Quantity,
      //   Sale_Price: it.Sale_Price,
      //   Discount_On_Sale_Price: it.Discount_On_Sale_Price,
      //   Discount_Type_On_Sale_Price: it.Discount_Type_On_Sale_Price,
      //   Tax_Amount: it.Tax_Amount,
      //   Tax_Type: it.Tax_Type || "None",
      //   Amount: it.Amount,
      //   created_at: it.created_at,
      // })),
    });
  } catch (err) {
    console.error("❌ Error getting single sale:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};
const generateInvoiceHtml = (sale) => {
  const { invoicePartyDetails, items } = sale;


  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>Invoice</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
          }
          header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
          }

          /* --- Invoice Meta Section --- */
          .meta-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 12px;
            margin: 20px 0;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            padding: 12px;
          }

          .meta-item {
            flex: 1 1 45%;
            min-width: 250px;
          }

          .meta-item strong {
            display: block;
            font-weight: bold;
            color: #222;
            margin-bottom: 4px;
          }

          /* --- Address Section --- */
          .address-section {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            overflow: hidden;
          }

          .address-box {
            flex: 1;
            padding: 12px 16px;
          }

          .address-box h4 {
            margin-bottom: 8px;
            border-bottom: 1px solid #ccc;
            padding-bottom: 4px;
          }

          .divider {
            width: 1px;
            background-color: #e0e0e0;
          }

          /* --- Items Table --- */
          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
          }

          th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
          }

          th {
            background-color: #f8f8f8;
          }

          /* --- Totals Section --- */
          .totals {
            margin-top: 20px;
            float: right;
          }

          .totals table {
            border-collapse: collapse;
          }

          .totals td {
            padding: 6px 12px;
            border: 1px solid #ccc;
          }
    footer { position: fixed; bottom: 30px; left: 0; right: 0; text-align: center; font-size: 12px; 
    color: #555; }
         
        </style>
      </head>
      <body>
        <header>
          <h1>Invoice</h1>
          <div class="invoice-meta">
            <strong>Invoice Number:</strong> ${invoicePartyDetails?.Invoice_Number || "N/A"}<br/>
            <strong>Date:</strong> ${new Date(invoicePartyDetails?.Invoice_Date).toLocaleDateString("en-IN")}
          </div>
        </header>

        <!-- 🧾 Meta Information -->
        <div class="meta-container">
          <div class="meta-item">
            <strong>Party Name</strong>
            <span>${invoicePartyDetails?.Party_Name || "N/A"}</span>
          </div>

          <div class="meta-item">
            <strong>GSTIN</strong>
            <span>${invoicePartyDetails?.GSTIN || "N/A"}</span>
          </div>

          <div class="meta-item">
            <strong>State of Supply</strong>
            <span>${invoicePartyDetails?.State_Of_Supply || "N/A"}</span>
          </div>

          <div class="meta-item">
            <strong>Payment Type</strong>
            <span>${invoicePartyDetails?.Payment_Type || "N/A"}</span>
          </div>

          ${invoicePartyDetails?.Reference_Number
      ? `<div class="meta-item" style="flex: 1 1 100%;">
                  <strong>Reference Number</strong>
                  <span>${invoicePartyDetails.Reference_Number}</span>
                </div>`
      : ""
    }
        </div>

        
        
          
              <div class="address-section">
                ${invoicePartyDetails?.Billing_Address
      ? `<div class="address-box">
                        <h4>Billed To</h4>
                        <p>${invoicePartyDetails.Billing_Address}</p>
                      </div>`
      : ""
    }
                ${invoicePartyDetails?.Shipping_Address
      ? `<div class="divider"></div>
                      <div class="address-box">
                        <h4>Shipped To</h4>
                        <p>${invoicePartyDetails.Shipping_Address}</p>
                      </div>`
      : ""
    }
              </div>
            
        

        <!-- 📦 Items Table -->
        <table>
          <thead>
            <tr>
              <th>Sl.No</th>
              <th>Category</th>
              <th>Item</th>
              <th>HSN</th>
              <th>Qty</th>
              <th>Price</th>
              <th>Discount</th>
              <th>Tax Type</th>
              <th>Tax</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            ${items
      ?.map(
        (it, idx) => `
                    <tr>
                      <td>${idx + 1}</td>
                      <td>${it?.Item_Category || ""}</td>
                      <td>${it?.Item_Name || ""}</td>
                      <td>${it?.Item_HSN || ""}</td>
                      <td>${it?.Quantity || 0} ${it?.Item_Unit || ""}</td>
                      <td>${Number(it?.Sale_Price || 0).toFixed(2)}</td>
                      <td>${it?.Discount_Type_On_Sale_Price === "Percentage"
            ? it?.Discount_On_Sale_Price == 0.00 ? "0%" : it?.Discount_On_Sale_Price + "%"
            : "₹" + it?.Discount_On_Sale_Price
          }</td>
                      <td>${Object.keys(TAX_TYPES).includes(it?.Tax_Type)
            ? TAX_TYPES[it?.Tax_Type]
            : it?.Tax_Type
          }</td>
                      <td>${Number(it?.Tax_Amount || 0).toFixed(2)}</td>
                      <td>${Number(it?.Amount || 0).toFixed(2)}</td>
                    </tr>
                  `
      )
      .join("") || ""
    }
          </tbody>
        </table>

        <!-- 💰 Totals Section -->
        <div class="totals">
          <table>
            <tr><td><strong>Total Amount</strong></td><td>${invoicePartyDetails?.Total_Amount || 0}</td></tr>
            <tr><td><strong>Received</strong></td><td>${invoicePartyDetails?.Total_Received || 0}</td></tr>
            <tr><td><strong>Balance Due</strong></td><td>${invoicePartyDetails?.Balance_Due || 0}</td></tr>
          </table>
        </div>

        <footer>Thank you for your business!</footer>
      </body>
    </html>
  `;

  return html;
};




// Main controller function to handle PDF creation
// const printSaleBill = async (req, res, next) => {
//   // 1. Fetch data (replace this with your actual DB query logic)
//   // For demonstration, assume 'sale' data is fetched here:
//  const sale = req.body;
//   console.log(sale);
//   if (!sale) {
//     return res.status(400).send("No invoice data provided.");
//   }

//   // 2. Generate the HTML content
//   const htmlContent = generateInvoiceHtml(sale);

//   let browser;
//   try {
//     // 3. Launch Puppeteer (headless Chrome)
//     browser = await puppeteer.launch({
//       args: ['--no-sandbox', '--disable-setuid-sandbox']
//     });
//     const page = await browser.newPage();

//     // 4. Set the HTML content
//     await page.setContent(htmlContent, {
//       waitUntil: 'networkidle0' // Wait until the network is idle
//     });

//     // 5. Generate PDF
//     const pdfBuffer = await page.pdf({
//       format: 'A4',
//       printBackground: true, // Ensure background colors/images are printed
//       preferCSSPageSize: true, // Use sizes defined in CSS @page rules if present
//     });

//     // 6. Send the PDF buffer back to the client
//     res.setHeader('Content-Type', 'application/pdf');
//     res.setHeader('Content-Disposition', `inline; filename=Invoice-${sale?.invoicePartyDetails?.Invoice_Number}.pdf`);
//     res.send(pdfBuffer);

//   } catch (error) {
//     console.error('PDF Generation Error:', error);
//     // next(error);
//     return res.status(500).send('Error generating PDF.');
//   } finally {
//     if (browser) {
//       await browser.close();
//     }
//   }
// };
// const printSaleBill = async (req, res) => {
//   const sale = req.body;
//   if (!sale) return res.status(400).send("No invoice data provided.");

//   const htmlContent = generateInvoiceHtml(sale);
//   const file = { content: htmlContent };

//   try {
//     const pdfBuffer = await pdf.generatePdf(file, {
//       format: "A4",
//       printBackground: true,
//       preferCSSPageSize: true,
//     });

//     res.setHeader("Content-Type", "application/pdf");
//     res.setHeader(
//       "Content-Disposition",
//       `inline; filename=Invoice-${sale?.invoicePartyDetails?.Invoice_Number}.pdf`
//     );
//     res.send(pdfBuffer);
//   } catch (err) {
//     console.error("PDF generation failed:", err);
//     res.status(500).send("Error generating PDF");
//   }
// };


const fonts = {
  Helvetica: {
    normal: "Helvetica",
    bold: "Helvetica-Bold",
    italics: "Helvetica-Oblique",
    bolditalics: "Helvetica-BoldOblique",
  },
};




const printer = new PdfPrinter(fonts);


const printSaleBill = async (req, res) => {
  try {
    const sale = req.body;
    if (!sale) return res.status(400).send("No invoice data provided.");

    const { invoicePartyDetails, items } = sale;
    const safe = (v) => (v ? v : "N/A");

    const docDefinition = {
      pageMargins: [30, 30, 30, 60], // left, top, right, bottom (space for footer)
      footer: (currentPage, pageCount) => ({
        text: `Thank you for your business! — Page ${currentPage} of ${pageCount}`,
        alignment: "center",
        fontSize: 10,
        color: "#555",
        margin: [0, 10, 0, 0],
      }),

      content: [
        // 🧾 HEADER (Centered)
        {
          stack: [
            { text: "INVOICE", style: "header", alignment: "center" },
            {
              columns: [
                {
                  width: "*",
                  alignment: "center",
                  stack: [
                    {
                      text: `Invoice Number: ${safe(invoicePartyDetails?.Invoice_Number)}`,
                      style: "meta",
                      alignment: "center",
                    },
                    {
                      text: `Date: ${new Date(
                        invoicePartyDetails?.Invoice_Date
                      ).toLocaleDateString("en-IN")}`,
                      style: "meta",
                      alignment: "center",
                    },
                  ],
                },
              ],
            },
          ],
          margin: [0, 0, 0, 15],
        },


        {
          style: "section",
          table: {
            widths: ["50%", "50%"],
            body: [
              [
                {
                  stack: [
                    { text: "Party Name", style: "label", margin: [0, 2, 0, 1] },
                    { text: safe(invoicePartyDetails?.Party_Name), style: "value", margin: [0, 0, 0, 4] },
                    { text: "GSTIN", style: "label", margin: [0, 2, 0, 1] },
                    { text: safe(invoicePartyDetails?.GSTIN), style: "value", margin: [0, 0, 0, 4] },
                  ],
                  border: [false, false, true, false],
                },
                {
                  stack: [
                    { text: "State of Supply", style: "label", margin: [0, 2, 0, 1] },
                    { text: safe(invoicePartyDetails?.State_Of_Supply), style: "value", margin: [0, 0, 0, 4] },
                    { text: "Payment Type", style: "label", margin: [0, 2, 0, 1] },
                    { text: safe(invoicePartyDetails?.Payment_Type), style: "value", margin: [0, 0, 0, 4] },
                    ...(invoicePartyDetails?.Reference_Number
                      ? [
                        { text: "Reference Number", style: "label", margin: [0, 2, 0, 1] },
                        { text: invoicePartyDetails.Reference_Number, style: "value", margin: [0, 0, 0, 4] },
                      ]
                      : []),
                  ],
                },
              ],
            ],
          },
          layout: "lightHorizontalLines",
          margin: [0, 5, 0, 5], // Adds spacing around the table itself
        },

        // 🏠 Addresses
        {
          columns: [
            invoicePartyDetails?.Billing_Address
              ? {
                width: "50%",
                stack: [
                  { text: "Billed To", style: "labelBold" },
                  { text: invoicePartyDetails.Billing_Address, style: "value" },
                ],
              }
              : {},
            invoicePartyDetails?.Shipping_Address
              ? {
                width: "50%",
                stack: [
                  { text: "Shipped To", style: "labelBold" },
                  { text: invoicePartyDetails.Shipping_Address, style: "value" },
                ],
              }
              : {},
          ],
          columnGap: 20,
          margin: [0, 10, 0, 0],
        },

        // 📦 Items Table
        {
          style: "tableExample",
          table: {
            headerRows: 1,
            widths: [30, 50, 50, 45, 35, 40, 50, 50, 45, 55],
            body: [
              [
                { text: "Sl.No", style: "tableHeader" },
                { text: "Category", style: "tableHeader" },
                { text: "Item", style: "tableHeader" },
                { text: "HSN", style: "tableHeader" },
                { text: "Qty", style: "tableHeader" },
                { text: "Price", style: "tableHeader" },
                { text: "Discount", style: "tableHeader" },
                { text: "Tax Type", style: "tableHeader" },
                { text: "Tax", style: "tableHeader" },
                { text: "Amount", style: "tableHeader" },
              ],
              ...items.map((it, idx) => [
                { text: idx + 1, style: "numeric" },
                safe(it.Item_Category),
                safe(it.Item_Name),
                safe(it.Item_HSN),
                { text: `${it.Quantity || 0} ${safe(it.Item_Unit)}`, style: "numeric" },
                { text: Number(it?.Sale_Price || 0).toFixed(2), style: "numeric" },
                {
                  text:
                    it?.Discount_Type_On_Sale_Price === "Percentage"
                      ? it?.Discount_On_Sale_Price == 0.0
                        ? "0%"
                        : `${it.Discount_On_Sale_Price}%`
                      : "₹" + (it.Discount_On_Sale_Price || 0),
                  style: "numeric",
                },
                Object.keys(TAX_TYPES).includes(it?.Tax_Type)
                  ? TAX_TYPES[it?.Tax_Type]
                  : it?.Tax_Type,
                // safe(it.Tax_Type),
                { text: Number(it?.Tax_Amount || 0).toFixed(2), style: "numeric" },
                { text: Number(it?.Amount || 0).toFixed(2), style: "numeric" },
              ]),
            ],
          },
          layout: {
            fillColor: (rowIndex) => (rowIndex === 0 ? "#f2f2f2" : null),
            hLineWidth: () => 0.5,
            vLineWidth: () => 0.5,
          },
          margin: [0, 10, 0, 0],
        },

        // 💰 Totals Box (Right Side)
        {
          columns: [
            { width: "*", text: "" },
            {
              width: "37%",
              table: {
                widths: ["*", "auto"],
                body: [
                  [{ text: "Total Amount", style: "labelBold" }, { text: `${invoicePartyDetails?.Total_Amount || 0}`, style: "numeric" }],
                  [{ text: "Received", style: "labelBold" }, { text: `${invoicePartyDetails?.Total_Received || 0}`, style: "numeric" }],
                  [
                    { text: "Balance Due", style: "labelBoldRed" },
                    //{ text: `${invoicePartyDetails?.Balance_Due || 0}` },
                    { text: `${invoicePartyDetails?.Balance_Due || 0}`, style: "numericRed" },
                  ],
                ],
              },
              layout: {
                hLineColor: "#999",
                vLineColor: "#999",
                fillColor: (rowIndex) => (rowIndex % 2 === 0 ? "#fafafa" : null),
              },
              margin: [0, 15, 0, 0],
            },
          ],
        },
      ],

      styles: {
        header: { fontSize: 18, bold: true, margin: [10, 10, 10, 10] },
        meta: { fontSize: 11, margin: [0, 2, 0, 2] },
        section: { margin: [0, 10, 0, 10] },
        tableHeader: { bold: true, fillColor: "#f2f2f2", fontSize: 11 },
        label: { bold: true, fontSize: 11 },
        labelBold: { bold: true, fontSize: 12, margin: [0, 5, 0, 3] },
        labelBoldRed: { bold: true, color: "black", fontSize: 11 },
        value: { fontSize: 11 },
        numeric: { alignment: "right", fontSize: 11 },
        numericRed: { alignment: "right", fontSize: 11, color: "black" },
        tableExample: { fontSize: 11 },
      },
      defaultStyle: { font: "Helvetica" },
    };

    // Generate PDF
    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    const chunks = [];
    pdfDoc.on("data", (chunk) => chunks.push(chunk));
    pdfDoc.on("end", () => {
      const pdfBuffer = Buffer.concat(chunks);
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader(
        "Content-Disposition",
        `inline; filename=Invoice-${invoicePartyDetails?.Invoice_Number}.pdf`
      );
      res.send(pdfBuffer);
    });
    pdfDoc.end();
  } catch (err) {
    console.error("PDF generation failed:", err);
    res.status(500).send("Error generating PDF");
  }
};

/**
 * Helper: Generate next ID (e.g., SIT001)
 */
const generateNextId = async (connection, table, column, prefix) => {
  const [latest] = await connection.query(
    `SELECT ${column} FROM ${table} ORDER BY id DESC LIMIT 1`
  );
  let nextNum = 1;
  if (latest.length > 0) {
    const lastId = latest[0][column];
    nextNum = parseInt(lastId.replace(prefix, "")) + 1;
  }
  return prefix + nextNum.toString().padStart(3, "0");
};

/**
 * Edit Sale Controller
 */


const editSale = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();
    await connection.beginTransaction();
    const { Sale_Id: saleId } = req.params;

    const [existingSale] = await connection.query(
      `SELECT *
   FROM add_sale
   WHERE Sale_Id = ?
   LIMIT 1
   FOR UPDATE`,
      [saleId]
    );
    if (existingSale.length === 0) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "No such Sale found.",
      });
    }
    // IMPORTANT:
    // Save old party before changing the sale
    const oldPartyId = existingSale[0].Party_Id;
    const saleIdNumber = existingSale[0].id;

    const cleanData = sanitizeObject(req.body);
    const validation = saleSchema.safeParse(cleanData);
    if (!validation.success) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        errors: validation.error.errors,
      });
    }

    const {
      Party_Name,
      Billing_Name,
      Invoice_Number,
      Invoice_Number_Prefix,
      Invoice_Number_Value,
      Phone_Number,        // ← add
      Billing_Address,     // ← add
      Invoice_Date,
      State_Of_Supply,
      Transaction_Discount_Percentage,
      Transaction_Discount_Amount,
      Total_Amount,
      Round_Off,
      Total_Received,
      Balance_Due,
      //Reference_Number,
      splits,   // 🔹 replaces single Payment_Type / Bank_Account_Id
      items,
      // Terms & Conditions
      Terms_Conditions_Id,
      Terms_Conditions_Description
    } = validation.data;

    //await connection.beginTransaction();
    let termsId = null;
    let termsDescription = null;

    if (
      Terms_Conditions_Id &&
      Terms_Conditions_Description?.trim()
    ) {
      // Saved template selected and untouched
      termsId = Number(Terms_Conditions_Id);
      termsDescription =
        Terms_Conditions_Description.trim();

    } else if (Terms_Conditions_Description?.trim()) {
      // Custom / edited description
      termsId = null;
      termsDescription = Terms_Conditions_Description.trim();
    }
    if (termsId) {
      const [[selectedTerm]] = await connection.query(
        `SELECT id
     FROM terms_conditions
     WHERE id = ?
       AND Sale_Invoice = 1
     LIMIT 1`,
        [termsId]
      );

      if (!selectedTerm) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message: "Invalid Terms & Conditions for Sale Invoice.",
        });
      }
    }
    const totalAmount = Number(Total_Amount) || 0;
    const roundOffValue = Number(Round_Off) || 0
    let validSplits = [];

    if (totalAmount > 0) {
      const normalizedSplits = (splits || [])
        .filter((split) => {
          // Must have payment type
          if (!split.Payment_Type) {
            return false;
          }

          // Bank must have selected bank account
          if (
            split.Payment_Type === "Bank" &&
            !split.Bank_Account_Id
          ) {
            return false;
          }

          return true;
        })
        .map((split) => ({
          ...split,
          Amount: Number(split.Amount) || 0,
        }));


      validSplits = normalizedSplits.filter(
        (split, index) => {

          // FIRST valid payment method:
          // always preserve, even ₹0
          if (index === 0) {
            return true;
          }

          // Every payment after first:
          // only preserve positive amount
          return split.Amount > 0;
        }
      );
    }
    // const totalReceived = Total_Received === "" || Total_Received === undefined
    //   ? 0
    //   : Number(Total_Received);
    const totalReceived = validSplits.reduce(
      (sum, split) => sum + (Number(split.Amount) || 0),
      0
    );
    const balanceDue = totalAmount - totalReceived;

    // 🔹 received cannot exceed total
    if (totalReceived > totalAmount) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: "Received amount should be less than or equal to Total Amount",
      });
    }

    // 🔹 validate splits
    if (totalReceived > 0) {
      try {
        validateSplits(validSplits, totalReceived);
      } catch (validationErr) {
        await connection.rollback();
        return res.status(400).json({ success: false, message: validationErr.message });
      }
    }



    // =========================================================
    // RESOLVE PARTY — EDIT SALE
    // =========================================================
    //
    // EDIT SALE RULE:
    //
    // Party_Name is always mandatory because even an anonymous
    // cash invoice already comes back as:
    //
    // Party_Name = "Cash Sale"
    //
    // ---------------------------------------------------------
    //
    // SPECIAL "Cash Sale" PARTY:
    //
    // add_party:
    //   ❌ NEVER update Billing_Name
    //   ❌ NEVER update Phone_Number
    //   ❌ NEVER update GSTIN
    //   ❌ NEVER create/update Billing_Address
    //
    // add_sale:
    //   ✅ Billing_Name is invoice-specific
    //   ✅ Phone_Number is invoice-specific
    //   ✅ Billing_Address is invoice-specific
    //
    // ---------------------------------------------------------
    //
    // NORMAL PARTY:
    //
    // If party doesn't exist:
    //   → create master
    //   → initialize Billing_Name
    //   → initialize Phone_Number
    //   → initialize first Billing_Address
    //
    // If party exists:
    //   → initialize Billing_Name only if master blank
    //   → initialize Phone_Number only if master blank
    //   → initialize Billing_Address only if none exists
    //
    // But add_sale ALWAYS receives the current invoice values.
    //
    // GSTIN is readonly in Sale Edit and is NEVER updated here.
    // =========================================================


    const partyName = Party_Name?.trim();

    if (!partyName) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Party name is required.",
      });
    }


    // =========================================================
    // IDENTIFY SPECIAL CASH SALE PARTY
    // =========================================================

    const isCashSaleParty =
      partyName.toLowerCase() === "cash sale";


    // =========================================================
    // FIND PARTY
    // =========================================================

    const [partyRows] = await connection.query(
      `SELECT *
   FROM add_party
   WHERE TRIM(Party_Name) = TRIM(?)
   LIMIT 1`,
      [partyName]
    );

    let Party_Id;


    // =========================================================
    // CASE 1: PARTY DOES NOT EXIST
    // =========================================================

    if (partyRows.length === 0) {

      // =======================================================
      // A. SPECIAL CASH SALE PARTY DOESN'T EXIST
      // =======================================================
      //
      // Normally Cash Sale should already exist.
      //
      // If somehow missing, recreate ONLY the system party.
      // Customer details still do NOT belong in its master.
      // =======================================================

      if (isCashSaleParty) {

        const [partyResult] = await connection.execute(
          `INSERT INTO add_party
       (
         Party_Name,
         created_at,
         updated_at
       )
       VALUES (?, NOW(), NOW())`,
          [partyName]
        );

        const partyIdNumber = partyResult.insertId;

        Party_Id =
          "PTY" +
          partyIdNumber.toString().padStart(3, "0");

        await connection.execute(
          `UPDATE add_party
       SET Party_Id = ?
       WHERE id = ?`,
          [
            Party_Id,
            partyIdNumber,
          ]
        );
      }


      // =======================================================
      // B. BRAND-NEW NORMAL PARTY
      // =======================================================

      else {

        const [partyResult] = await connection.execute(
          `INSERT INTO add_party
       (
         Party_Name,
         Billing_Name,
         Phone_Number,
         created_at,
         updated_at
       )
       VALUES (?, ?, ?, NOW(), NOW())`,
          [
            partyName,
            cleanValue(Billing_Name),
            cleanValue(Phone_Number),
          ]
        );

        const partyIdNumber = partyResult.insertId;

        Party_Id =
          "PTY" +
          partyIdNumber.toString().padStart(3, "0");

        await connection.execute(
          `UPDATE add_party
       SET Party_Id = ?
       WHERE id = ?`,
          [
            Party_Id,
            partyIdNumber,
          ]
        );


        // =====================================================
        // FIRST BILLING ADDRESS -> DEFAULT
        // =====================================================

        if (Billing_Address?.trim()) {

          await connection.execute(
            `INSERT INTO add_party_addresses
         (
           Party_Id,
           Address_Type,
           Address_Text,
           Is_Default,
           created_at,
           updated_at
         )
         VALUES (?, 'Billing', ?, 1, NOW(), NOW())`,
            [
              Party_Id,
              cleanValue(Billing_Address),
            ]
          );
        }
      }
    }


    // =========================================================
    // CASE 2: PARTY ALREADY EXISTS
    // =========================================================

    else {

      const existingParty = partyRows[0];

      Party_Id = existingParty.Party_Id;


      // =======================================================
      // A. SPECIAL CASH SALE PARTY
      // =======================================================
      //
      // DO ABSOLUTELY NOTHING TO MASTER.
      //
      // Cash Sale represents many different walk-in customers.
      //
      // Billing_Name / Phone / Address entered on this invoice
      // belong ONLY to add_sale.
      // =======================================================

      if (isCashSaleParty) {

        // Intentionally empty.
      }


      // =======================================================
      // B. NORMAL EXISTING PARTY
      // =======================================================

      else {

        // =====================================================
        // 1. BILLING NAME
        //
        // Initialize master only when blank.
        // =====================================================

        if (
          !existingParty.Billing_Name?.trim() &&
          Billing_Name?.trim()
        ) {

          await connection.execute(
            `UPDATE add_party
         SET
           Billing_Name = ?,
           updated_at = NOW()
         WHERE Party_Id = ?`,
            [
              cleanValue(Billing_Name),
              Party_Id,
            ]
          );
        }


        // =====================================================
        // 2. PHONE NUMBER
        //
        // Initialize master only when blank.
        // =====================================================

        if (
          !existingParty.Phone_Number?.trim() &&
          Phone_Number?.trim()
        ) {

          await connection.execute(
            `UPDATE add_party
         SET
           Phone_Number = ?,
           updated_at = NOW()
         WHERE Party_Id = ?`,
            [
              //Phone_Number.trim(),
              cleanValue(Phone_Number),
              Party_Id,
            ]
          );
        }


        // =====================================================
        // 3. BILLING ADDRESS
        //
        // Add first address only if no Billing address exists.
        // =====================================================

        if (Billing_Address?.trim()) {

          const [[addressCount]] =
            await connection.query(
              `SELECT COUNT(*) AS total
           FROM add_party_addresses
           WHERE Party_Id = ?
             AND Address_Type = 'Billing'`,
              [Party_Id]
            );

          if (Number(addressCount.total) === 0) {

            await connection.execute(
              `INSERT INTO add_party_addresses
           (
             Party_Id,
             Address_Type,
             Address_Text,
             Is_Default,
             created_at,
             updated_at
           )
           VALUES (?, 'Billing', ?, 1, NOW(), NOW())`,
              [
                Party_Id,
                //Billing_Address.trim(),
                cleanValue(Billing_Address)
              ]
            );
          }
        }


        // =====================================================
        // GSTIN
        // =====================================================
        //
        // GSTIN is readonly in Sale Edit.
        // NEVER update add_party.GSTIN from here.
      }
    }


    // =========================================================
    // UPDATE INVOICE SNAPSHOT
    // =========================================================
    //
    // IMPORTANT:
    //
    // These values describe THIS invoice.
    //
    // NORMAL PARTY:
    //   → current UI values overwrite this bill.
    //
    // CASH SALE:
    //   → current UI values also belong only to this bill.
    //
    // Therefore we DON'T need finalBillingName /
    // finalPhoneNumber / finalBillingAddress anymore.
    //
    // Whatever Edit Sale UI sends is saved on THIS invoice.
    // =========================================================
    const transactionDiscountPercentage =
      normalizeNumber(Transaction_Discount_Percentage);

    const transactionDiscountAmount =
      normalizeNumber(Transaction_Discount_Amount);
    if (
      transactionDiscountPercentage !== null &&
      transactionDiscountPercentage > 100
    ) {
      return res.status(400).json({
        success: false,
        message: "Transaction discount percentage cannot be greater than 100%",
      });
    }
    const cleanTransactionDiscountPercentage =
      transactionDiscountPercentage > 0
        ? transactionDiscountPercentage
        : null;

    const cleanTransactionDiscountAmount =
      transactionDiscountAmount > 0
        ? transactionDiscountAmount
        : null;



    // ---------------------------------------------------------
    // Get OLD invoice number before updating the sale
    // ---------------------------------------------------------

    const [oldSaleRows] = await connection.execute(
      `
  SELECT
    Invoice_Number,
    Invoice_Number_Prefix,
    Invoice_Number_Value
  FROM add_sale
  WHERE Sale_Id = ?
  LIMIT 1
  FOR UPDATE
  `,
      [saleId]
    );

    // const oldInvoiceNumber = String(
    //   oldSaleRows[0]?.Invoice_Number || ""
    // ).trim();

    const oldInvoicePrefix =
      String(
        oldSaleRows[0]?.Invoice_Number_Prefix ?? ""
      ).trim() || "None";

    const oldInvoiceValue =
      oldSaleRows[0]?.Invoice_Number_Value === null ||
        oldSaleRows[0]?.Invoice_Number_Value === undefined
        ? ""
        : String(oldSaleRows[0].Invoice_Number_Value).trim();


    // ---------------------------------------------------------
    // Current invoice prefix
    // ---------------------------------------------------------

    const invoicePrefix =
      String(Invoice_Number_Prefix ?? "").trim() || "None";


    // ---------------------------------------------------------
    // Current invoice number value
    // ---------------------------------------------------------

    const invoiceValueString =
      String(Invoice_Number_Value ?? "").trim();


    // ---------------------------------------------------------
    // Validate invoice number value
    // ---------------------------------------------------------

    if (
      invoiceValueString !== "" &&
      !/^\d+$/.test(invoiceValueString)
    ) {
      await connection.rollback();

      return res.status(400).json({
        success: false,
        message: "Invoice number must contain only digits.",
      });
    }


    // ---------------------------------------------------------
    // Convert invoice value
    //
    // Empty = no invoice number
    // 0 / 00 = no invoice number
    // ---------------------------------------------------------

    const invoiceNumberValue =
      invoiceValueString === ""
        ? null
        : Number(invoiceValueString);


    // ---------------------------------------------------------
    // Build legacy Invoice_Number
    //
    // None + 5000 -> "5000"
    // SAL + 5000  -> "SAL5000"
    // None + 0    -> NULL
    // SAL + 0     -> NULL
    // ---------------------------------------------------------

    const invoiceNumber = buildLegacyInvoiceNumber(
      invoicePrefix,
      invoiceNumberValue
    );


    // ---------------------------------------------------------
    // Handle invoice prefix sequence
    // ---------------------------------------------------------

    if (invoiceNumberValue !== null) {

      // -------------------------------------------------------
      // If old invoice used a different prefix/value,
      // release old prefix sequence when old number was latest.
      // -------------------------------------------------------

      const invoicePrefixChanged =
        oldInvoicePrefix !== invoicePrefix;


      if (
        invoicePrefixChanged &&
        oldInvoiceValue !== "" &&
        Number(oldInvoiceValue) !== 0
      ) {

        const oldNumber = Number(oldInvoiceValue);

        const [oldPrefixRows] = await connection.execute(
          `
      SELECT
        id,
        last_number
      FROM transactions_prefixes
      WHERE transaction_type = 'sale'
        AND prefix_name = ?
      LIMIT 1
      FOR UPDATE
      `,
          [oldInvoicePrefix]
        );


        if (oldPrefixRows.length > 0) {

          const oldPrefixRow = oldPrefixRows[0];

          const oldLastNumber =
            Number(oldPrefixRow.last_number) || 0;


          // ---------------------------------------------------
          // Only release if old invoice was the latest number
          // ---------------------------------------------------

          if (oldNumber === oldLastNumber) {

            await connection.execute(
              `
          UPDATE transactions_prefixes
          SET last_number = ?
          WHERE id = ?
          `,
              [
                Math.max(0, oldLastNumber - 1),
                oldPrefixRow.id,
              ]
            );
          }
        }
      }


      // -------------------------------------------------------
      // Find + LOCK NEW prefix row
      // -------------------------------------------------------

      const [prefixRows] = await connection.execute(
        `
    SELECT
      id,
      transaction_type,
      prefix_name,
      last_number,
      is_active
    FROM transactions_prefixes
    WHERE transaction_type = 'sale'
      AND prefix_name = ?
    LIMIT 1
    FOR UPDATE
    `,
        [invoicePrefix]
      );


      // -------------------------------------------------------
      // Prefix must exist
      // -------------------------------------------------------

      if (prefixRows.length === 0) {
        await connection.rollback();

        return res.status(400).json({
          success: false,
          message: `Invoice prefix "${invoicePrefix}" does not exist.`,
        });
      }


      const prefixRow = prefixRows[0];

      const currentLastNumber =
        Number(prefixRow.last_number) || 0;


      // -------------------------------------------------------
      // Update NEW prefix sequence if necessary
      // -------------------------------------------------------

      if (invoiceNumberValue > currentLastNumber) {

        await connection.execute(
          `
      UPDATE transactions_prefixes
      SET last_number = ?
      WHERE id = ?
      `,
          [
            invoiceNumberValue,
            prefixRow.id,
          ]
        );
      }
    }


    // ---------------------------------------------------------
    // Check duplicate invoice number
    // ---------------------------------------------------------

    if (invoiceNumber !== null) {

      const [duplicateRows] = await connection.execute(
        `
    SELECT Sale_Id
    FROM add_sale
    WHERE Invoice_Number = ?
      AND Sale_Id <> ?
    LIMIT 1
    FOR UPDATE
    `,
        [
          invoiceNumber,
          saleId,
        ]
      );


      if (duplicateRows.length > 0) {

        await connection.rollback();

        return res.status(400).json({
          success: false,
          message: `Invoice number "${invoiceNumber}" already exists.`,
        });
      }
    }
    await connection.query(
      `UPDATE add_sale 
   SET
      Party_Id = ?,

      Billing_Name = ?,
      Phone_Number = ?,
      Billing_Address = ?,

      Invoice_Number = ?,
      Invoice_Number_Prefix = ?,
      Invoice_Number_Value = ?,

      Invoice_Date = ?,
      State_Of_Supply = ?,

      Transaction_Discount_Percentage = ?,
      Transaction_Discount_Amount = ?,

      Total_Amount = ?,
      Round_Off = ?,
      Total_Received = ?,
      Balance_Due = ?,

      Terms_Conditions_Id = ?,
      Terms_Conditions_Description = ?,

      updated_at = NOW()

   WHERE Sale_Id = ?`,
      [
        Party_Id,

        // Invoice-specific snapshots
        cleanValue(Billing_Name),
        cleanValue(Phone_Number),
        cleanValue(Billing_Address),

        // Invoice number
        invoiceNumber,
        invoicePrefix,
        invoiceNumberValue,

        Invoice_Date,
        cleanValue(State_Of_Supply),

        cleanTransactionDiscountPercentage,
        cleanTransactionDiscountAmount,

        totalAmount,
        roundOffValue,
        totalReceived,
        balanceDue,

        // Terms & Conditions
        termsId,
        termsDescription,

        saleId,
      ]
    );

    await connection.query(
      `UPDATE sale_return
   SET
      Invoice_Number = ?,
      Invoice_Date = ?,
      updated_at = NOW()
   WHERE Sale_Id = ?`,
      [
        invoiceNumber,
        //Invoice_Number,
        Invoice_Date,
        saleId,
      ]
    );

    // 🔹 wipe old splits + ledger rows, re-insert fresh ones
    await deletePaymentSplits({
      connection,
      sourceType: "Sale",
      sourceId: saleIdNumber,
    });

    if (validSplits.length > 0) {
      await insertPaymentSplits({
        connection,
        sourceType: "Sale",
        sourceId: saleIdNumber,
        partyName: Party_Name,
        txnDate: Invoice_Date,
        splits: validSplits,
      });
    }
    const partyChanged =
      oldPartyId &&
      Party_Id &&
      oldPartyId !== Party_Id;


    // ─────────────────────────────────────────────
    // 1. REMOVE SALE FROM OLD PARTY
    // ─────────────────────────────────────────────
    if (partyChanged) {
      await reversePartyLedger({
        connection,

        // OLD PARTY
        partyId: oldPartyId,

        txnType: "Sale",

        // Same numeric Source_Id used when
        // original ledger row was created
        referenceId: saleIdNumber,
      });
    }


    // ─────────────────────────────────────────────
    // 2. ADD / UPDATE SALE FOR CURRENT PARTY
    // ─────────────────────────────────────────────
    await recordPartyLedger({
      connection,

      // NEW/CURRENT PARTY
      partyId: Party_Id,

      txnType: "Sale",

      referenceId: saleIdNumber,

      amount: totalAmount,

      txnDate: Invoice_Date,

      //docNumber: Invoice_Number,
      docNumber: invoiceNumber,

      balanceDue: balanceDue,
    });


    // =========================================================
    // OLD SALE ITEMS
    // =========================================================

    const [oldItems] = await connection.query(
      `SELECT *
   FROM add_sale_items
   WHERE Sale_Id = ?`,
      [saleId]
    );


    // =========================================================
    // STEP 1: RESOLVE ALL NEW SALE LINES
    // =========================================================

    const resolvedLines = [];

    for (const item of items) {

      // -------------------------------------------------------
      // EMPTY ROW
      // -------------------------------------------------------

      if (!item.Item_Name?.trim()) {

        if ((normalizeNumber(item.Amount) ?? 0) > 0) {
          await connection.rollback();

          return res.status(400).json({
            success: false,
            message: "Please enter an item name for the row.",
          });
        }

        continue;
      }


      // =======================================================
      // TRANSACTION SELECTED UNIT
      //
      // Frontend Item_Unit = selected transaction unit
      // add_item.Item_Unit is legacy and remains ""
      // =======================================================

      const Selected_Unit = item.Item_Unit?.trim() || null;
      const cleanFreeQuantity = Number(item.Free_Quantity) > 0
        ? Number(item.Free_Quantity)
        : null;

      let Item_Id = item.Item_Id || null;

      let dbItemRow = null;


      // =======================================================
      // FIND ITEM MASTER
      // =======================================================

      if (Item_Id) {

        const [rows] = await connection.query(
          `
        SELECT *
        FROM add_item
        WHERE Item_Id = ?
        LIMIT 1
      `,
          [Item_Id]
        );

        dbItemRow = rows[0] || null;

      } else {

        const [rows] = await connection.query(
          `
        SELECT *
        FROM add_item
        WHERE TRIM(Item_Name) = TRIM(?)
        LIMIT 1
      `,
          [item.Item_Name]
        );

        dbItemRow = rows[0] || null;

        Item_Id = dbItemRow?.Item_Id || null;
      }


      // These are what THIS sale row will save
      let stockDelta = 0;

      const normalQuantity = normalizeNumber(item.Quantity) ?? 0;

      //const freeQuantity =normalizeNumber(item.Free_Quantity) ?? 0;
      const freeQuantity = cleanFreeQuantity ?? 0;
      const totalQuantity =
        normalQuantity + freeQuantity;
      let snapshot = {
        Primary_Unit_Snapshot: null,
        Secondary_Unit_Snapshot: null,
      };
      let resolvedSelectedUnit =
        Selected_Unit;


      // =======================================================
      // CASE 1: BRAND-NEW ITEM
      // =======================================================

      if (!dbItemRow) {

        const [maxRow] = await connection.query(
          `
        SELECT
          MAX(
            CAST(
              SUBSTRING(Item_Id, 4)
              AS UNSIGNED
            )
          ) AS maxId
        FROM add_item
        WHERE Item_Id LIKE 'ITM%'
      `
        );

        const autoId =
          (maxRow[0]?.maxId || 0) + 1;

        Item_Id =
          "ITM" +
          autoId.toString().padStart(3, "0");


        // -----------------------------------------------------
        // FIRST SELECTED UNIT BECOMES PRIMARY
        //
        // New item + Kgs:
        //
        // Primary = Kgs
        // Secondary = NULL
        //
        // New item + NONE:
        //
        // Primary = NULL
        // -----------------------------------------------------

        const firstPrimaryUnit =
          Selected_Unit || null;


        //stockDelta =normalizeNumber(item.Quantity) ?? 0;
        stockDelta = totalQuantity;


        snapshot = {
          Primary_Unit_Snapshot:
            firstPrimaryUnit,

          Secondary_Unit_Snapshot:
            null,
        };


        await connection.execute(
          `
        INSERT INTO add_item
        (
          Item_Id,
          Item_Name,
          Item_Category,
          Item_HSN,

          Item_Unit,
           
          Primary_Unit,
          Secondary_Unit,
          Conversion_Rate,
           Sale_Price,

          Stock_Quantity,

          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?, NOW(), NOW())
      `,
          [
            Item_Id,

            item.Item_Name.trim(),
            item.Item_Category || "",
            cleanValue(item.Item_HSN),

            // legacy field
            "",

            firstPrimaryUnit,
            null,
            null,
            normalizeNumber(item.Sale_Price) ?? null,
            // SALE = stock OUT
            -stockDelta,
          ]
        );


        dbItemRow = {
          Item_Id,

          Item_HSN:
            item.Item_HSN,

          Item_Category:
            item.Item_Category || "",

          Primary_Unit:
            firstPrimaryUnit,

          Secondary_Unit:
            null,

          Conversion_Rate:
            null,
        };
      }


      // =======================================================
      // CASE 2: EXISTING ITEM
      // =======================================================

      else {
        let firstUnitAssigned = false;
        // =====================================================
        // ⭐ IMPORTANT CASE:
        // EXISTING MASTER HAS NO PRIMARY YET
        //
        // Master:
        // Primary = NULL
        //
        // User edits sale and selects Kgs
        //
        // => Kgs becomes FIRST PRIMARY UNIT
        // =====================================================

        if (
          !dbItemRow.Primary_Unit &&
          Selected_Unit
        ) {

          await connection.query(
            `
          UPDATE add_item
          SET
            Primary_Unit = ?,
            Secondary_Unit = NULL,
            Conversion_Rate = NULL,
            Item_Unit = '',
            updated_at = NOW()
          WHERE Item_Id = ?
        `,
            [
              Selected_Unit,
              Item_Id,
            ]
          );


          // IMPORTANT:
          // Keep our in-memory master synchronized

          dbItemRow.Primary_Unit = Selected_Unit;

          dbItemRow.Secondary_Unit = null;

          dbItemRow.Conversion_Rate = null;
          firstUnitAssigned = true;


        }


        // =====================================================
        // FIND THIS ITEM'S OLD SALE LINE
        // =====================================================

        const oldSaleLine =
          oldItems.find(
            (old) =>
              String(old.Item_Id) ===
              String(Item_Id)
          );


        const oldPrimary =
          oldSaleLine?.Primary_Unit_Snapshot ||
          null;

        const oldSecondary =
          oldSaleLine?.Secondary_Unit_Snapshot ||
          null;

        const oldSelected =
          oldSaleLine?.Selected_Unit ||
          null;


        // =====================================================
        // OLD TRANSACTION ACTUALLY USED OLD SECONDARY?
        // =====================================================

        const oldUsedSecondary =
          !!(
            oldSaleLine &&
            oldSecondary &&
            oldSelected === oldSecondary
          );


        // =====================================================
        // UNIT RESOLUTION
        // =====================================================
        if (firstUnitAssigned) {

          //stockDelta =normalizeNumber(item.Quantity) ?? 0;
          stockDelta = totalQuantity;
          snapshot = {
            Primary_Unit_Snapshot:
              dbItemRow.Primary_Unit,

            Secondary_Unit_Snapshot:
              dbItemRow.Secondary_Unit,
          };

          resolvedSelectedUnit =
            dbItemRow.Primary_Unit;
        }
        else if (oldUsedSecondary) {

          // ---------------------------------------------------
          // Historical secondary transaction
          //
          // Example:
          //
          // Old:
          // KG / GM
          // Selected GM
          //
          // Master now:
          // KG / BOX
          //
          // Keep transaction KG / GM
          // ---------------------------------------------------

          // snapshot = {
          //   Primary_Unit:
          //     oldPrimary,

          //   Secondary_Unit:
          //     oldSecondary,
          // };
          snapshot = {
            Primary_Unit_Snapshot:
              oldPrimary,

            Secondary_Unit_Snapshot:
              oldSecondary,
          };


          resolvedSelectedUnit =
            Selected_Unit ||
            oldSelected;


          //const quantity =normalizeNumber(item.Quantity) ?? 0;
          const quantity = totalQuantity;

          // ---------------------------------------------------
          // Need conversion corresponding to old unit pair.
          // ---------------------------------------------------

          if (
            resolvedSelectedUnit ===
            oldSecondary
          ) {

            // const [[conversion]] =
            //   await connection.query(
            //     `
            //   SELECT Conversion_Rate
            //   FROM item_unit_conversions
            //   WHERE  Primary_Unit = ?
            //     AND Secondary_Unit = ?
            //   ORDER BY id DESC
            //   LIMIT 1
            // `,
            //     [

            //       oldPrimary,
            //       oldSecondary,
            //     ]
            //   );


            // const conversionRate =
            //   Number(
            //     conversion?.Conversion_Rate
            //   );


            // if (
            //   !Number.isFinite(conversionRate) ||
            //   conversionRate <= 0
            // ) {

            //   await connection.rollback();

            //   return res.status(400).json({
            //     success: false,
            //     message:
            //       `Conversion rate not found for ` +
            //       `"${oldPrimary}" to "${oldSecondary}" ` +
            //       `for item "${item.Item_Name}".`,
            //   });
            // }
            const conversionRate =
              Number(dbItemRow?.Conversion_Rate) || 0;

            if (conversionRate <= 0) {
              await connection.rollback();

              return res.status(400).json({
                success: false,
                message:
                  `Conversion rate not found for ` +
                  `"${oldPrimary}" to "${oldSecondary}" ` +
                  `for item "${item.Item_Name}".`,
              });
            }


            stockDelta = quantity / conversionRate;

          } else {

            // Selected primary
            stockDelta =
              quantity;
          }
        }


        // =====================================================
        // NORMAL CASE:
        // USE CURRENT ITEM MASTER
        // =====================================================

        else {

          const resolved =
            resolveUnitAndStockDelta({
              dbItemRow,

              Selected_Unit:
                Selected_Unit,

              //Quantity:item.Quantity,
              Quantity: totalQuantity,
            });


          stockDelta =
            resolved.stockDelta;

          snapshot =
            resolved.snapshot;

          resolvedSelectedUnit =
            resolved.resolvedSelectedUnit;
        }


        // =====================================================
        // UPDATE SAFE ITEM MASTER FIELDS
        // =====================================================

        const updates = [];
        const params = [];


        if (
          item.Item_HSN &&
          item.Item_HSN !==
          dbItemRow.Item_HSN
        ) {

          updates.push(
            "Item_HSN = ?"
          );

          params.push(
            item.Item_HSN
          );
        }


        if (
          item.Item_Category !== undefined &&
          item.Item_Category !==
          dbItemRow.Item_Category
        ) {

          updates.push(
            "Item_Category = ?"
          );

          params.push(
            item.Item_Category || ""
          );
        }
        updates.push("Sale_Price = ?");
        params.push(
          normalizeNumber(item.Sale_Price) ?? null
        );


        if (updates.length > 0) {

          params.push(Item_Id);

          await connection.query(
            `
          UPDATE add_item
          SET
            ${updates.join(", ")},
            updated_at = NOW()
          WHERE Item_Id = ?
        `,
            params
          );
        }
      }


      // =======================================================
      // STORE RESOLVED TRANSACTION LINE
      // =======================================================

      resolvedLines.push({
        ...item,

        Item_Id,

        Stock_Delta: Number(stockDelta),

        snapshot,

        resolvedSelectedUnit,
      });
    }


    // =========================================================
    // STEP 2:
    // CALCULATE OLD BASE QUANTITY PER ITEM
    //
    // IMPORTANT:
    // Raw sale Quantity cannot be compared anymore.
    //
    // 500 gm != 500 Kg
    //
    // We need normalized/base quantities.
    // =========================================================

    const oldBaseQtyByItem = new Map();


    // =========================================================
    // STEP 2:
    // GET OLD BASE QUANTITY PER ITEM
    //
    // Priority:
    // 1. item_ledger.Base_Qty  ← preferred / exact value
    // 2. Snapshot + conversion  ← fallback for old/missing ledger
    // =========================================================

    for (const old of oldItems) {

      // =======================================================
      // HISTORICAL UNIT SNAPSHOT
      // =======================================================

      const oldPrimary = old.Primary_Unit_Snapshot || null;

      const oldSecondary = old.Secondary_Unit_Snapshot || null;

      const oldSelected = old.Selected_Unit || null;


      // =======================================================
      // FIRST: TRY ITEM LEDGER
      // =======================================================

      const [[ledgerRow]] = await connection.query(
        `
    SELECT Base_Qty
    FROM item_ledger
    WHERE Item_Id = ?
      AND Txn_Type = 'Sale'
      AND Source_Id = ?
    LIMIT 1
    `,
        [
          old.Item_Id,
          old.id,
        ]
      );


      let oldBaseQty;


      // =======================================================
      // CASE 1:
      // LEDGER EXISTS
      //
      // Use the exact Base_Qty that was originally applied
      // to add_item.Stock_Quantity.
      // =======================================================

      if (ledgerRow) {

        oldBaseQty =
          Number(ledgerRow.Base_Qty) || 0;
      }


      // =======================================================
      // CASE 2:
      // LEDGER DOES NOT EXIST
      //
      // Fallback using historical snapshot + conversion.
      // =======================================================

      else {

        // const rawQty =
        //   Number(old.Quantity) || 0;

        // oldBaseQty = rawQty;
        const normalQty =
          Number(old.Quantity) || 0;

        const freeQty =
          Number(old.Free_Quantity) || 0;

        const rawQty =
          normalQty + freeQty;

        oldBaseQty = rawQty;


        // -------------------------------------------------------
        // If the old transaction used the secondary unit,
        // convert it into the primary unit.
        //
        // Example:
        //
        // Primary   = Kg
        // Secondary = Gm
        // Quantity  = 500
        //
        // Base_Qty = 500 / 1000 = 0.5 Kg
        // -------------------------------------------------------

        if (
          oldPrimary &&
          oldSecondary &&
          oldSelected === oldSecondary
        ) {


          const [[itemMaster]] =
            await connection.query(
              `
    SELECT Conversion_Rate
    FROM add_item
    WHERE Item_Id = ?
    LIMIT 1
    `,
              [old.Item_Id]
            );

          // const conversionRate =
          //   Number(
          //     conversion?.Conversion_Rate
          //   );
          const conversionRate =
            Number(itemMaster?.Conversion_Rate) || 0;


          if (
            Number.isFinite(conversionRate) &&
            conversionRate > 0
          ) {

            oldBaseQty =
              rawQty / conversionRate;
          }

          // If conversion is missing/invalid,
          // keep rawQty as fallback instead of throwing.
        }
      }


      // =======================================================
      // ACCUMULATE BY ITEM
      //
      // Same item can occur multiple times in one sale.
      // =======================================================

      oldBaseQtyByItem.set(
        old.Item_Id,

        (
          oldBaseQtyByItem.get(
            old.Item_Id
          ) || 0
        ) + oldBaseQty
      );
    }

    // =========================================================
    // NEW BASE QUANTITY PER ITEM
    // =========================================================

    const newBaseQtyByItem = new Map();


    for (const line of resolvedLines) {

      newBaseQtyByItem.set(
        line.Item_Id,

        (
          newBaseQtyByItem.get(
            line.Item_Id
          ) || 0
        ) +
        Number(line.Stock_Delta || 0)
      );
    }


    // =========================================================
    // STEP 3:
    // APPLY NET STOCK DIFFERENCE
    //
    // Sale = OUT
    //
    // More sold => subtract more
    // Less sold => restore stock
    // =========================================================

    const allItemIds =
      new Set([
        ...newBaseQtyByItem.keys(),
        ...oldBaseQtyByItem.keys(),
      ]);


    for (const itemId of allItemIds) {

      const newQty =
        newBaseQtyByItem.get(itemId) || 0;

      const oldQty =
        oldBaseQtyByItem.get(itemId) || 0;


      const diff =
        newQty - oldQty;


      if (diff !== 0) {

        await connection.query(
          `
        UPDATE add_item
        SET
          Stock_Quantity =
            Stock_Quantity - ?,

          updated_at = NOW()

        WHERE Item_Id = ?
      `,
          [
            diff,
            itemId,
          ]
        );
      }
    }


    // =========================================================
    // STEP 4:
    // REVERSE OLD ITEM LEDGER ROWS
    // =========================================================

    for (const old of oldItems) {

      await reverseItemLedger({
        connection,

        itemId:
          old.Item_Id,

        txnType:
          "Sale",

        referenceId:
          old.id,
      });
    }


    // =========================================================
    // STEP 5:
    // DELETE OLD SALE ITEMS
    // =========================================================

    await connection.query(
      `
    DELETE FROM add_sale_items
    WHERE Sale_Id = ?
  `,
      [saleId]
    );


    // =========================================================
    // STEP 6:
    // INSERT FRESH SALE ITEMS
    // =========================================================

    for (const line of resolvedLines) {

      const [saleTax] =
        await connection.query(
          `
        SELECT Tax_Type
        FROM add_sale_items
        WHERE Item_Id = ?
        ORDER BY id DESC
        LIMIT 1
      `,
          [line.Item_Id]
        );


      const safeTaxType =
        line.Tax_Type ||
        saleTax[0]?.Tax_Type ||
        "None";


      const [insertRes] =
        await connection.execute(
          `
        INSERT INTO add_sale_items
        (
          Sale_Id,
          Item_Id,

          Quantity,
          Free_Quantity,

          Primary_Unit_Snapshot,
          Secondary_Unit_Snapshot,
          Selected_Unit,
          MRP,
          Discount_On_MRP_For_Sale_Percentage,

          Sale_Price,

          Discount_On_Sale_Price,
          Discount_Type_On_Sale_Price,

          Tax_Type,
          Tax_Amount,
          Amount,

          created_at,
          updated_at
        )
        VALUES (
          ?, ?,
          ?,?,
          ?, ?, ?,
          ?,
          ?, ?,
          ?, ?, ?,?,?,
          NOW(), NOW()
        )
      `,
          [
            saleId,
            line.Item_Id,

            normalizeNumber(
              line.Quantity
            ) ?? 0,

            line.Free_Quantity > 0 ? Number(line.Free_Quantity) : null,
            //normalizeNumber(line.Free_Quantity) ?? null,
            line.snapshot.Primary_Unit_Snapshot,
            line.snapshot.Secondary_Unit_Snapshot,
            line.resolvedSelectedUnit,
            // line.Primary_Unit_Snapshot,
            // line.Secondary_Unit_Snapshot,
            // line.Selected_Unit,
            normalizeNumber(
              line.MRP
            ),
            normalizeNumber(
              line.Discount_On_MRP_For_Sale_Percentage),

            normalizeNumber(
              line.Sale_Price
            ) ?? 0,

            cleanDiscount(
              line.Discount_On_Sale_Price
            ),

            cleanValue(
              line.Discount_Type_On_Sale_Price
            ),

            cleanValue(
              safeTaxType
            ),

            normalizeNumber(
              line.Tax_Amount
            ) ?? 0,

            normalizeNumber(
              line.Amount
            ) ?? 0,
          ]
        );


      const id =
        insertRes.insertId;

      const newId =
        "SIT" +
        id.toString().padStart(3, "0");


      await connection.execute(
        `
      UPDATE add_sale_items
      SET Sale_Items_Id = ?
      WHERE id = ?
    `,
        [
          newId,
          id,
        ]
      );
      await connection.execute(
        `
  UPDATE add_item
  SET
    Item_Unit = ?,
    Primary_Unit = ?,
    Secondary_Unit = ?
  WHERE Item_Id = ?
  `,
        [
          line.resolvedSelectedUnit || null,
          line.snapshot.Primary_Unit_Snapshot || null,
          line.snapshot.Secondary_Unit_Snapshot || null,
          line.Item_Id,
        ]
      );
      await syncUnitIdsForItem(connection, line.Item_Id);

      await syncUnitIdsForSaleItem(connection, {
        saleItemRowId: id,
        Primary_Unit_Snapshot: line.snapshot.Primary_Unit_Snapshot,
        Secondary_Unit_Snapshot: line.snapshot.Secondary_Unit_Snapshot,
        Selected_Unit: line.resolvedSelectedUnit,
      });

      // =====================================================
      // ITEM LEDGER
      //
      // Use BASE quantity, not transaction quantity.
      //
      // 500 gm => Stock_Delta 0.5 Kg
      // =====================================================


      await recordItemLedger({
        connection,
        itemId: line.Item_Id,
        txnType: "Sale",
        referenceId: id,
        billId: saleId,
        //billNumber: Invoice_Number,
        billNumber: invoiceNumber,
        partyName: Party_Name,
        quantity: normalizeNumber(line.Quantity) ?? 0,    // user-entered: e.g. 500
        freeQuantity: line.Free_Quantity > 0 ? Number(line.Free_Quantity) : null,
        //freeQuantity: normalizeNumber(line.Free_Quantity) ?? null,
        selectedUnit: line.resolvedSelectedUnit,               // 🔹 e.g. "Gm"
        baseQty: line.Stock_Delta,                         // 🔹 normalized: e.g. 0.5
        rate: normalizeNumber(line.Sale_Price) ?? null,
        txnDate: Invoice_Date,
      })
    }

    await connection.commit();

    return res.json({ success: true, message: "Sale updated successfully" });
  } catch (err) {
    if (connection) await connection.rollback();
    next(err);
  } finally {
    if (connection) connection.release();
  }
};
//DELETE


const deleteSale = async (req, res, next) => {
  let connection;

  try {
    const { Sale_Id: saleId } = req.params;

    if (!saleId) {
      return res.status(400).json({
        success: false,
        message: "Sale ID is required.",
      });
    }

    connection = await db.getConnection();

    await connection.beginTransaction();

    // =========================================================
    // 1. GET SALE HEADER
    // =========================================================

    const [[sale]] = await connection.query(
      `
      SELECT
        id,
        Sale_Id,
        Party_Id,
        Invoice_Number,
        Invoice_Date
      FROM add_sale
      WHERE Sale_Id = ?
      LIMIT 1
      `,
      [saleId]
    );

    if (!sale) {
      await connection.rollback();

      return res.status(404).json({
        success: false,
        message: "Sale not found.",
      });
    }

    // Numeric add_sale.id
    //
    // Used by:
    // - party_ledger.Source_Id
    // - payment_splits.Source_Id
    const saleDbId = sale.id;

    // =========================================================
    // 2. CHECK SALE RETURNS
    //
    // Do not allow deleting Sale while a Sale Return exists.
    // =========================================================

    // const [[saleReturn]] = await connection.query(
    //   `
    //   SELECT id
    //   FROM sale_return
    //   WHERE Sale_Id = ?
    //   LIMIT 1
    //   `,
    //   [saleId]
    // );

    // if (saleReturn) {
    //   await connection.rollback();

    //   return res.status(400).json({
    //     success: false,
    //     message:
    //       "This sale cannot be deleted because a sale return exists for it. Delete the sale return first.",
    //   });
    // }

    // =========================================================
    // 3. GET ALL SALE ITEMS
    //
    // item_ledger.Source_Id = add_sale_items.id
    // =========================================================

    const [saleItems] = await connection.query(
      `
      SELECT
        id,
        Item_Id
      FROM add_sale_items
      WHERE Sale_Id = ?
      `,
      [saleId]
    );

    // =========================================================
    // 4. REVERSE STOCK + ITEM LEDGER
    //
    // Sale = OUT
    //
    // Original Sale:
    //     Stock - Base_Qty
    //
    // Delete Sale:
    //     Stock + Base_Qty
    // =========================================================

    for (const saleItem of saleItems) {

      // -------------------------------------------------------
      // Find corresponding Sale ledger row.
      //
      // Source_Id = add_sale_items.id
      // -------------------------------------------------------

      const [[ledgerRow]] = await connection.query(
        `
        SELECT
          Base_Qty,
          Quantity
        FROM item_ledger
        WHERE Item_Id = ?
          AND Txn_Type = 'Sale'
          AND Source_Id = ?
        LIMIT 1
        `,
        [
          saleItem.Item_Id,
          saleItem.id,
        ]
      );

      if (!ledgerRow) {
        // No ledger row.
        // Nothing to reverse for this item.
        continue;
      }

      // Always prefer normalized Base_Qty.
      //
      // Example:
      // 500 Gm = 0.5 Kg Base_Qty
      const baseQty =
        Number(
          ledgerRow.Base_Qty ??
          ledgerRow.Quantity
        ) || 0;

      // -------------------------------------------------------
      // Sale was OUT.
      //
      // Deleting Sale means putting the stock back.
      // -------------------------------------------------------

      if (baseQty !== 0) {
        await connection.query(
          `
          UPDATE add_item
          SET
            Stock_Quantity = Stock_Quantity + ?,
            updated_at = NOW()
          WHERE Item_Id = ?
          `,
          [
            baseQty,
            saleItem.Item_Id,
          ]
        );
      }

      // -------------------------------------------------------
      // Remove Sale ledger row.
      //
      // reverseItemLedger() also fixes Running_Stock of all
      // subsequent ledger rows.
      // -------------------------------------------------------

      await reverseItemLedger({
        connection,
        itemId: saleItem.Item_Id,
        txnType: "Sale",
        referenceId: saleItem.id,
      });
    }

    // =========================================================
    // 5. DELETE PAYMENT SPLITS
    //
    // payment_splits.Source_Id = add_sale.id
    // =========================================================

    await deletePaymentSplits({
      connection,
      sourceType: "Sale",
      sourceId: saleDbId,
    });

    // =========================================================
    // 6. REVERSE PARTY LEDGER
    //
    // party_ledger.Source_Id = add_sale.id
    //
    // Opening Balance is NOT touched.
    // =========================================================

    await reversePartyLedger({
      connection,
      partyId: sale.Party_Id,
      txnType: "Sale",
      referenceId: saleDbId,
    });

    // =========================================================
    // 7. DELETE SALE ITEMS
    // =========================================================

    await connection.query(
      `
      DELETE FROM add_sale_items
      WHERE Sale_Id = ?
      `,
      [saleId]
    );

    // =========================================================
    // 8. DELETE SALE HEADER
    // =========================================================

    await connection.query(
      `
      DELETE FROM add_sale
      WHERE Sale_Id = ?
      `,
      [saleId]
    );

    // =========================================================
    // 9. COMMIT
    // =========================================================

    await connection.commit();

    return res.status(200).json({
      success: true,
      message: "Sale deleted successfully.",
      Sale_Id: saleId,
    });

  } catch (err) {

    if (connection) {
      await connection.rollback();
    }

    console.error(
      "❌ Error deleting sale:",
      err
    );

    next(err);

  } finally {

    if (connection) {
      connection.release();
    }
  }
};

;
// const getLatestInvoiceNumber = async (req, res, next) => {
//   let connection;
//   try {
//     connection = await db.getConnection();

//     // 1️⃣ Fetch invoice prefix
//     const [invoiceSettings] = await connection.query(
//       `SELECT Invoice_Name FROM add_invoice LIMIT 1`
//     );

//     if (!invoiceSettings.length || !invoiceSettings[0].Invoice_Name) {
//       return res.status(400).json({
//         success: false,
//         message: "Invoice prefix not set ,please set it first.",
//       });
//     }

//     const prefix = invoiceSettings[0].Invoice_Name.trim();

//     // 2️⃣ Get ACTIVE financial year
//     const [fy] = await connection.query(
//       `SELECT Financial_Year 
//        FROM financial_year 
//        WHERE Current_Financial_Year = 1
//        LIMIT 1`
//     );

//     if (!fy.length) {
//       return res.status(400).json({
//         success: false,
//         message: "No active financial year found.",
//       });
//     }

//     const activeFY = fy[0].Financial_Year;

//     // 3️⃣ Fetch latest invoice **ONLY inside this financial year**
//     const [rows] = await connection.query(
//       `
//       SELECT Invoice_Number 
//       FROM add_sale
//       WHERE Invoice_Number LIKE '${prefix}%'
//       AND Financial_Year = ?
//       ORDER BY 
//         CAST(SUBSTRING(Invoice_Number, LENGTH(?) + 1) AS UNSIGNED) DESC
//       LIMIT 1
//       `,
//       [activeFY, prefix]
//     );

//     // 4️⃣ default new invoice number
//     let newInvoiceNumber = `${prefix}0001`;

//     // If an invoice already exists in this FY → increment
//     if (rows.length > 0) {
//       const last = rows[0].Invoice_Number;
//       const numPart = last.replace(prefix, "");
//       const nextNum = parseInt(numPart) + 1;
//       newInvoiceNumber = prefix + nextNum.toString().padStart(4, "0");
//     }

//     return res.status(200).json({
//       success: true,
//       financialYear: activeFY,
//       newInvoiceNumber,
//     });
//   } catch (err) {
//     console.error("❌ Error:", err);
//     next(err);
//   } finally {
//     if (connection) connection.release();
//   }
// };
const getLatestInvoiceNumber = async (req, res, next) => {
  let connection;

  try {
    const { prefix: requestedPrefix } = req.query;

    // =========================================================
    // 1. VALIDATE PREFIX
    // =========================================================

    if (!requestedPrefix) {
      return res.status(400).json({
        success: false,
        message: "Invoice prefix is required.",
      });
    }

    const requestedPrefixName = String(requestedPrefix).trim();

    connection = await db.getConnection();

    // =========================================================
    // 2. GET PREFIX + LAST NUMBER
    // =========================================================

    const [prefixRows] = await connection.query(
      `
            SELECT
                id,
                transaction_type,
                prefix_name,
                last_number,
                is_active
            FROM transactions_prefixes
            WHERE transaction_type = 'sale'
              AND prefix_name = ?
            LIMIT 1
            `,
      [requestedPrefixName]
    );

    if (prefixRows.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid Sale invoice prefix.",
      });
    }

    const prefixRow = prefixRows[0];

    // =========================================================
    // 3. GET LAST NUMBER
    //
    // Example:
    //
    // SAL -> 1000
    // INV -> 50
    // None -> 20
    //
    // If NULL, treat it as 0.
    // =========================================================

    const lastNumber = Number(prefixRow.last_number) || 0;

    const nextNumber = lastNumber + 1;

    // =========================================================
    // 4. FORMAT NEXT NUMBER
    // =========================================================

    let newInvoiceNumber;

    // ---------------------------------------------------------
    // NONE PREFIX
    //
    // None:
    // 1
    // 2
    // 3
    // 1001
    // ---------------------------------------------------------

    if (
      requestedPrefixName.toLowerCase() === "none"
    ) {
      newInvoiceNumber = String(nextNumber);
    }

    // ---------------------------------------------------------
    // AEPL-2627-
    //
    // Old special format:
    //
    // 0086
    // 0087
    // 0088
    // ---------------------------------------------------------

    // else if (
    //     requestedPrefixName.toUpperCase() === "AEPL-2627-"
    // ) {
    //     newInvoiceNumber = String(nextNumber).padStart(4, "0");
    // }

    // ---------------------------------------------------------
    // ALL OTHER PREFIXES
    //
    // SAL1
    // SAL2
    // SAL3
    //
    // API returns only:
    // 1
    // 2
    // 3
    //
    // Frontend combines it with selected prefix.
    // ---------------------------------------------------------

    else {
      newInvoiceNumber = String(nextNumber);
    }

    // =========================================================
    // 5. GET CURRENT FINANCIAL YEAR
    // =========================================================

    const [fyRows] = await connection.query(
      `
            SELECT Financial_Year
            FROM financial_year
            WHERE Current_Financial_Year = 1
            LIMIT 1
            `
    );

    if (fyRows.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No active financial year found.",
      });
    }

    const activeFY = fyRows[0].Financial_Year;

    // =========================================================
    // 6. RETURN NEXT NUMBER
    // =========================================================

    return res.status(200).json({
      success: true,
      prefix: requestedPrefixName,
      financialYear: activeFY,
      newInvoiceNumber,
    });

  } catch (err) {
    console.error(
      "❌ Error getting latest invoice number:",
      err
    );

    next(err);

  } finally {
    if (connection) {
      connection.release();
    }
  }
};
// const getLatestInvoiceNumber = async (req, res, next) => {
//     let connection;

//     try {
//         const { prefix: requestedPrefix } = req.query;

//         // =========================================================
//         // 1. VALIDATE PREFIX
//         // =========================================================

//         if (!requestedPrefix) {
//             return res.status(400).json({
//                 success: false,
//                 message: "Invoice prefix is required.",
//             });
//         }

//         const requestedPrefixName = String(
//             requestedPrefix
//         ).trim();

//         connection = await db.getConnection();

//         // =========================================================
//         // 2. VERIFY PREFIX EXISTS FOR SALE
//         // =========================================================

//         const [prefixRows] = await connection.query(
//             `
//             SELECT
//                 id,
//                 transaction_type,
//                 prefix_name,
//                 is_active
//             FROM transactions_prefixes
//             WHERE transaction_type = 'sale'
//               AND prefix_name = ?
//             LIMIT 1
//             `,
//             [requestedPrefixName]
//         );

//         if (prefixRows.length === 0) {
//             return res.status(400).json({
//                 success: false,
//                 message: "Invalid Sale invoice prefix.",
//             });
//         }

//         // =========================================================
//         // 3. GET CURRENT FINANCIAL YEAR
//         // =========================================================

//         const [fyRows] = await connection.query(
//             `
//             SELECT Financial_Year
//             FROM financial_year
//             WHERE Current_Financial_Year = 1
//             LIMIT 1
//             `
//         );

//         if (fyRows.length === 0) {
//             return res.status(400).json({
//                 success: false,
//                 message: "No active financial year found.",
//             });
//         }

//         const activeFY = fyRows[0].Financial_Year;

//         // =========================================================
//         // 4. NONE PREFIX
//         //
//         // None:
//         //
//         // 0001 -> 2
//         // 0002 -> 3
//         // 10   -> 11
//         //
//         // No invoice -> 1
//         // =========================================================

//         if (
//             requestedPrefixName.toLowerCase() === "none"
//         ) {
//             const [rows] = await connection.query(
//                 `
//                 SELECT Invoice_Number
//                 FROM add_sale
//                 WHERE Financial_Year = ?
//                   AND TRIM(Invoice_Number) REGEXP '^[0-9]+$'
//                 ORDER BY
//                     CAST(TRIM(Invoice_Number) AS UNSIGNED) DESC
//                 LIMIT 1
//                 `,
//                 [activeFY]
//             );

//             let newInvoiceNumber = "1";

//             if (rows.length > 0) {
//                 const lastInvoiceNumber = String(
//                     rows[0].Invoice_Number
//                 ).trim();

//                 const lastNumber = parseInt(
//                     lastInvoiceNumber,
//                     10
//                 );

//                 if (!Number.isNaN(lastNumber)) {
//                     newInvoiceNumber = String(
//                         lastNumber + 1
//                     );
//                 }
//             }

//             return res.status(200).json({
//                 success: true,
//                 prefix: requestedPrefixName,
//                 financialYear: activeFY,
//                 newInvoiceNumber,
//             });
//         }

//         // =========================================================
//         // 5. PREFIXED INVOICE
//         //
//         // Normally:
//         //
//         // SAL1  -> 2
//         // SAL2  -> 3
//         // ABC1  -> 2
//         //
//         // SPECIAL CASE:
//         //
//         // AEPL-2627-0086 -> 0087
//         // AEPL-2627-0087 -> 0088
//         //
//         // Only AEPL-2627- uses 4 digit numbering.
//         // =========================================================

//         const prefix = requestedPrefixName;

//         const [rows] = await connection.query(
//             `
//             SELECT Invoice_Number
//             FROM add_sale
//             WHERE Financial_Year = ?
//               AND TRIM(Invoice_Number) LIKE CONCAT(?, '%')
//               AND SUBSTRING(
//                     TRIM(Invoice_Number),
//                     CHAR_LENGTH(?) + 1
//                   ) REGEXP '^[0-9]+$'
//             ORDER BY
//                 CAST(
//                     SUBSTRING(
//                         TRIM(Invoice_Number),
//                         CHAR_LENGTH(?) + 1
//                     ) AS UNSIGNED
//                 ) DESC
//             LIMIT 1
//             `,
//             [
//                 activeFY,
//                 prefix,
//                 prefix,
//                 prefix,
//             ]
//         );

//         // =========================================================
//         // 6. NEW PREFIX STARTS FROM 1
//         // =========================================================

//         let newInvoiceNumber = "1";

//         if (rows.length > 0) {
//             const lastInvoiceNumber = String(
//                 rows[0].Invoice_Number
//             ).trim();

//             const numericPart = lastInvoiceNumber.substring(
//                 prefix.length
//             );

//             const lastNumber = parseInt(
//                 numericPart,
//                 10
//             );

//             if (!Number.isNaN(lastNumber)) {
//                 const nextNumber = lastNumber + 1;

//                 // =================================================
//                 // AEPL-2627- IS THE OLD SPECIAL FORMAT
//                 // =================================================

//                 if (
//                     prefix.toUpperCase() === "AEPL-2627-"
//                 ) {
//                     newInvoiceNumber = String(
//                         nextNumber
//                     ).padStart(4, "0");
//                 } else {
//                     // =================================================
//                     // ALL OTHER PREFIXES
//                     //
//                     // SAL1 -> 2
//                     // SAL2 -> 3
//                     // ABC1 -> 2
//                     // =================================================

//                     newInvoiceNumber = String(
//                         nextNumber
//                     );
//                 }
//             }
//         }

//         // =========================================================
//         // 7. RETURN NUMBER ONLY
//         // =========================================================

//         return res.status(200).json({
//             success: true,
//             prefix: requestedPrefixName,
//             financialYear: activeFY,
//             newInvoiceNumber,
//         });

//     } catch (err) {
//         console.error(
//             "❌ Error getting latest invoice number:",
//             err
//         );

//         next(err);

//     } finally {
//         if (connection) {
//             connection.release();
//         }
//     }
// };
const getNewSaleLatestInvoiceNumber = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();
    // 1️⃣ Fetch user-defined invoice prefix
    const [invoiceSettings] = await db.query(`SELECT Invoice_Name FROM add_new_sale_invoice LIMIT 1`);

    if (!invoiceSettings || invoiceSettings.length === 0 || !invoiceSettings[0].Invoice_Name) {

      return res.status(400).json({

        success: false,
        message:
          "Invoice prefix not set. Please configure an invoice prefix in settings before generating invoices.",
      });
    }

    const prefix = invoiceSettings[0].Invoice_Name.trim();

    // 2️⃣ Fetch latest invoice based on numeric part of invoice number
    const [rows] = await db.query(`
      SELECT 
        Invoice_Number AS latestInvoice,
        created_at AS createdAt
      FROM add_new_sale
      WHERE Invoice_Number LIKE '${prefix}%'
      ORDER BY 
        CAST(SUBSTRING(Invoice_Number, LENGTH('${prefix}') + 1) AS UNSIGNED) DESC
      LIMIT 1
    `);

    // 3️⃣ Default new invoice number
    let newInvoiceNumber = `${prefix}0001`;
    let latestInvoiceInfo = null;

    // 4️⃣ Increment if previous invoices exist
    if (rows.length > 0 && rows[0].latestInvoice) {
      const lastInvoice = rows[0].latestInvoice;

      // Extract numeric part safely
      const numericPart = lastInvoice.replace(prefix, "").trim();
      const num = isNaN(parseInt(numericPart)) ? 1 : parseInt(numericPart) + 1;

      // Generate next invoice number
      newInvoiceNumber = `${prefix}${num.toString().padStart(4, "0")}`;

      latestInvoiceInfo = {
        lastInvoiceNumber: lastInvoice,
        createdAt: rows[0].createdAt,
      };
    }

    // 5️⃣ Return clean response
    return res.status(200).json({
      success: true,
      newInvoiceNumber,
      latestInvoiceInfo,
    });
  } catch (err) {
    if (connection) connection.release();
    console.error("❌ Error getting latest invoice number:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};



const getTotalSalesEachDay = async (req, res, next) => {
  let connection;
  try {
    connection = await db.getConnection();

    // 1️⃣ Get sales count per day for all records
    const [rows] = await connection.query(
      `
      SELECT 
        DATE_FORMAT(Invoice_Date, '%Y-%m-%d') AS sale_date,
        COUNT(*) AS total_sales
      FROM add_sale
      GROUP BY DATE_FORMAT(Invoice_Date, '%Y-%m-%d')
      ORDER BY sale_date ASC;
      `
    );

    // 2️⃣ Format output
    const result = rows.map((r) => ({
      date: r.sale_date,
      total_sales: r.total_sales,
    }));

    return res.status(200).json({
      success: true,
      financialYear: null, // kept key so frontend won't break
      data: result,
    });
  } catch (err) {
    console.error("❌ Error getting total sales each day:", err);
    next(err);
  } finally {
    if (connection) connection.release();
  }
};
// const getSalesPrintReport = async (req, res) => {
//   let connection;

//   try {
//     connection = await db.getConnection();

//     const {
//       search = "",
//       fromDate,
//       toDate,
//     } = req.query;

//     let whereClause = "WHERE 1=1";
//     const params = [];

//     if (search) {
//       whereClause += `
//         AND (
//           s.Invoice_Number LIKE ?
//           OR p.Party_Name LIKE ? OR
//            CAST(s.Total_Amount AS CHAR) LIKE ? OR
//         CAST(s.Balance_Due  AS CHAR) LIKE ?
//         )
//       `;

//       params.push(
//         `%${search}%`,
//         `%${search}%`,
//          `%${search}%`,
//         `%${search}%`
//       );
//     }

//     if (fromDate) {
//       whereClause += ` AND DATE(s.Invoice_Date) >= ?`;
//       params.push(fromDate);
//     }

//     if (toDate) {
//       whereClause += ` AND DATE(s.Invoice_Date) <= ?`;
//       params.push(toDate);
//     }

//     // ====================================
//     // SALES HEADER
//     // ====================================

//     const [sales] = await connection.query(
//       `
//       SELECT
//         s.id,
//         s.Sale_Id,
//         s.Phone_Number,
//         s.Billing_Name,
//         s.Billing_Address,
//         s.Invoice_Number,
//         s.Invoice_Date,
//         s.State_Of_Supply,
//         s.Total_Amount,
//         s.Total_Received,
//         s.Balance_Due,
//         s.Party_Id,

//         s.Terms_Conditions_Id,
//         s.Terms_Conditions_Description,

//         p.Party_Name,
//         p.GSTIN,


//         tc.Title AS Terms_Conditions_Title

//       FROM add_sale s

//       LEFT JOIN add_party p
//         ON s.Party_Id = p.Party_Id

//       LEFT JOIN terms_conditions tc
//         ON s.Terms_Conditions_Id = tc.id

//       ${whereClause}

//       ORDER BY s.Invoice_Date ASC
//       `,
//       params
//     );

//     if (!sales.length) {
//       return res.status(200).json({
//         success: true,
//         totalInvoices: 0,
//         invoices: [],
//       });
//     }

//     const saleIds = sales.map((s) => s.Sale_Id);
//     const numericIds = sales.map((s) => s.id);

//     const salePlaceholders =
//       saleIds.map(() => "?").join(",");

//     const idPlaceholders =
//       numericIds.map(() => "?").join(",");

//     // ====================================
//     // ITEMS
//     // ====================================

//     const [items] = await connection.query(
//       `
//       SELECT
//         si.*,

//         i.Item_Name,
//         i.Item_HSN,
//         i.Item_Unit,
//         i.Item_Category,

//         i.Primary_Unit,
//         i.Secondary_Unit,
//         i.Conversion_Rate

//       FROM add_sale_items si

//       LEFT JOIN add_item i
//         ON si.Item_Id = i.Item_Id

//       WHERE si.Sale_Id IN (${salePlaceholders})

//       ORDER BY si.created_at ASC
//       `,
//       saleIds
//     );

//     // ====================================
//     // PAYMENT SPLITS
//     // Source_Id = add_sale.id
//     // ====================================

//     const [splits] = await connection.query(
//       `
//       SELECT
//         ps.*,
//         ba.Account_Display_Name

//       FROM payment_splits ps

//       LEFT JOIN bank_accounts ba
//         ON ba.id = ps.Bank_Account_Id

//       WHERE ps.Source_Type = 'Sale'
//       AND ps.Source_Id IN (${idPlaceholders})

//       ORDER BY ps.id ASC
//       `,
//       numericIds
//     );

//     // ====================================
//     // GROUP ITEMS
//     // ====================================

//     const itemMap = {};

//     // items.forEach((item) => {
//     //   if (!itemMap[item.Sale_Id]) {
//     //     itemMap[item.Sale_Id] = [];
//     //   }

//     //   itemMap[item.Sale_Id].push(item);
//     // });
//     items.forEach((item) => {
//       const price = Number(item.Sale_Price || item.Purchase_Price || 0);

//       let discountAmount = 0;

//       if (
//         Number(item.Discount_On_Sale_Price || 0) > 0
//       ) {
//         if (
//           item.Discount_Type_On_Sale_Price === "Percentage"
//         ) {
//           discountAmount =
//             (price *
//               Number(item.Discount_On_Sale_Price)) /
//             100;
//         } else {
//           discountAmount = Number(
//             item.Discount_On_Sale_Price
//           );
//         }
//       }

//       item.Discount_Amount = Number(
//         discountAmount.toFixed(2)
//       );

//       if (!itemMap[item.Sale_Id]) {
//         itemMap[item.Sale_Id] = [];
//       }

//       itemMap[item.Sale_Id].push(item);
//     });

//     // ====================================
//     // GROUP SPLITS
//     // keyed by numeric sale id
//     // ====================================

//     const splitMap = {};

//     splits.forEach((split) => {
//       if (!splitMap[split.Source_Id]) {
//         splitMap[split.Source_Id] = [];
//       }

//       splitMap[split.Source_Id].push({
//         Id: split.id,
//         Payment_Type: split.Payment_Type,
//         Bank_Account_Id:
//           split.Bank_Account_Id,
//         Account_Display_Name:
//           split.Account_Display_Name,
//         Reference_Number:
//           split.Reference_Number,
//         Amount: split.Amount,
//       });
//     });

//     // ====================================
//     // FINAL REPORT
//     // SAME STRUCTURE AS getSingleSale
//     // ====================================

//     const invoices = sales.map((sale) => {
//       const saleSplits =
//         splitMap[sale.id] || [];

//       const splitLabels =
//         saleSplits.map((s) =>
//           s.Payment_Type === "Bank"
//             ? s.Account_Display_Name
//             : s.Payment_Type
//         );

//       const counts = {};

//       splitLabels.forEach((label) => {
//         counts[label] =
//           (counts[label] || 0) + 1;
//       });

//       const Payment_Type_Display =
//         Object.entries(counts)
//           .map(([label, count]) =>
//             count > 1
//               ? `${label} (x${count})`
//               : label
//           )
//           .join(" + ");

//       return {
//         invoicePartyDetails: {
//           Sale_Id: sale.Sale_Id,
//           Party_Name: sale.Party_Name,
//           Billing_Name: sale.Billing_Name,
//           Phone_Number: sale.Phone_Number,
//           Billing_Address:
//             sale.Billing_Address,
//           GSTIN: sale.GSTIN,
//           State_Of_Supply:
//             sale.State_Of_Supply,
//           State: sale.State,

//           Invoice_Number:
//             sale.Invoice_Number,
//           Invoice_Date:
//             sale.Invoice_Date,

//           Total_Amount:
//             sale.Total_Amount,
//           Total_Received:
//             sale.Total_Received,
//           Balance_Due:
//             sale.Balance_Due,

//           Terms_Conditions_Id:
//             sale.Terms_Conditions_Id,

//           Terms_Conditions_Description:
//             sale.Terms_Conditions_Description,

//           Terms_Conditions_Title:
//             sale.Terms_Conditions_Title,

//           Payment_Type_Display,
//         },

//         splits: saleSplits,

//         items:
//           itemMap[sale.Sale_Id] || [],
//       };
//     });
//     const grandTotalAmount = invoices.reduce(
//       (sum, inv) => sum + Number(inv.invoicePartyDetails.Total_Amount || 0),
//       0
//     );

//     const grandTotalReceived = invoices.reduce(
//       (sum, inv) => sum + Number(inv.invoicePartyDetails.Total_Received || 0),
//       0
//     );

//     const grandTotalBalanceDue = invoices.reduce(
//       (sum, inv) => sum + Number(inv.invoicePartyDetails.Balance_Due || 0),
//       0
//     );

//     return res.status(200).json({
//       success: true,
//       totalInvoices: invoices.length,

//       invoices,
//       summary: {
//         totalAmount: grandTotalAmount,
//         totalReceived: grandTotalReceived,
//         totalBalanceDue: grandTotalBalanceDue,
//       },
//     });

//   } catch (error) {
//     console.error(
//       "Sales Print Report Error:",
//       error
//     );

//     return res.status(500).json({
//       success: false,
//       message:
//         "Failed to generate sales print report",
//       error: error.message,
//     });
//   } finally {
//     if (connection) {
//       connection.release();
//     }
//   }
// };
const getSalesPrintReport = async (req, res, next) => {
  let connection;

  try {
    connection = await db.getConnection();

    const {
      search = "",
      fromDate,
      toDate,
    } = req.query;

    let whereClause = "WHERE 1=1";
    const params = [];

    if (search) {
      whereClause += `
        AND (
          s.Invoice_Number LIKE ?
          OR p.Party_Name LIKE ? OR
           CAST(s.Total_Amount AS CHAR) LIKE ? OR
        CAST(s.Balance_Due  AS CHAR) LIKE ?
        )
      `;

      params.push(
        `%${search}%`,
        `%${search}%`,
        `%${search}%`,
        `%${search}%`
      );
    }

    if (fromDate) {
      whereClause += ` AND DATE(s.Invoice_Date) >= ?`;
      params.push(fromDate);
    }

    if (toDate) {
      whereClause += ` AND DATE(s.Invoice_Date) <= ?`;
      params.push(toDate);
    }


    const {
      invoices,
      summary,
    } = await getSalesForPrint(
      connection,
      whereClause,
      params
    );

    return res.status(200).json({
      success: true,
      totalInvoices: invoices.length,
      invoices,
      summary,
    });
  } catch (error) {
    console.error(
      "Sales Print Report Error:",
      error
    );
    next(error);

    // return res.status(500).json({
    //   success: false,
    //   message:
    //     "Failed to generate sales print report",
    //   error: error.message,
    // });
  } finally {
    if (connection) {
      connection.release();
    }
  }
};
export {
  addSale, getAllSales, exportAllSalesReportToExcel, getSingleSale, getLatestInvoiceNumber,
  addInvoice, updateInvoice, getSingleInvoice, getNewSaleLatestInvoiceNumber,
  printSaleBill, editSale, deleteSale, getTotalSalesEachDay, getSalesPrintReport
};

